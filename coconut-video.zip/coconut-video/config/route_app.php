<?php
// +----------------------------------------------------------------------
// | Description: 基础框架路由配置文件
// +----------------------------------------------------------------------
// | Author: liguoguo <641785852@qq.com>
// +----------------------------------------------------------------------

return [
    'test'  => ['index/Index/test', ['method' => 'get']],
    '[app]' => [

        /**********************登录注册**************************/

        // 登录
        'login'                          => ['index/Index/login', ['method' => 'post']],
        // 注册
        'register'                       => ['index/Index/register', ['method' => 'post']],
        // 忘记密码
        'forgetPassword'                 => ['index/Index/forgetPassword', ['method' => 'post']],
        // 获取图形验证码
        'getVerify/:verify_key'          => ['index/Index/getVerify', ['method' => 'get']],
        // 获取短信验证码
        'getSms/:phone'                  => ['index/Index/getSms', ['method' => 'get']],
        // 短信验证码校验
        'checkSms'                       => ['index/Index/checkSms', ['method' => 'post']],
        // 校验手机号是否已存在
        'eheckPhoneExist/:phone'         => ['index/Index/phoneUnique', ['method' => 'get']],
        // 校验用户名是否已存在
        'eheckUsernameExist/:username'   => ['index/Index/usernameUnique', ['method' => 'get']],
        // 获取APP最新版本号
        'getLatestVer'                   => ['index/Index/getLatestVer', ['method' => 'get']],

        /********************** 行情 **************************/

        // 获取系统支持的币种列表
        'getSupportSymbol'               => ['index/Market/getSupportSymbol', ['method' => 'get']],
        // 获取最新行情数据
        'refreshMarket/:symbol'          => ['index/Market/refreshMarket', ['method' => 'get']],
        // 更新火币交易所最新行情(系统支持的10个币种和btc,eth,usdt的交易对，其他的交易对已过滤掉)
        'updateHuobiMarket'              => ['index/Market/updateHuobiMarket', ['method' => 'get']],
        // 更新Gateio交易所最新行情
        'updateGateioMarket'             => ['index/Market/updateGateioMarket', ['method' => 'get']],
        // 更新Binance交易所最新行情
        'updateBinanceMarket'            => ['index/Market/updateBinanceMarket', ['method' => 'get']],
        // 更新Cex交易所最新行情
        'updateCexMarket'                => ['index/Market/updateCexMarket', ['method' => 'get']],
        // 更新Bitz交易所最新行情
        'updateBitzMarket'               => ['index/Market/updateBitzMarket', ['method' => 'get']],
        // 更新Bcex交易所最新行情
        'updateBcexMarket'               => ['index/Market/updateBcexMarket', ['method' => 'get']],
        // 更新Bitforex交易所最新行情
        'updateBitforexMarket'           => ['index/Market/updateBitforexMarket', ['method' => 'get']],
        // 更新LBank交易所最新行情
        'updateLbankMarket'              => ['index/Market/updateLbankMarket', ['method' => 'get']],
        // 更新Okcoin交易所最新行情
        'updateOkcoinMarket'             => ['index/Market/updateOkcoinMarket', ['method' => 'get']],
        // 更新Bhex交易所最新行情
        'updateBhexMarket'               => ['index/Market/updateBhexMarket', ['method' => 'get']],

        // 更新Gateio交易所最新人民币信息(系统支持的10个币种)
        'updateGateioCny'                => ['index/Market/updateGateioCny', ['method' => 'get']],
        // 更新平台账户虚拟币充提记录
        'updateDepositWithdraw'          => ['index/Market/updateDepositWithdraw', ['method' => 'get']],
        // 计算托管订单每日收益
        'calcIncome'                     => ['index/Market/calcIncome', ['method' => 'get']],

        /********************** 资产 **************************/

        // 获取我的资产概览
        'getCapitalProfile'              => ['index/Coin/getCapitalProfile', ['method' => 'get']],
        // 获取币种简介
        'getSymboProfile/:symbol'        => ['index/Coin/getSymboProfile', ['method' => 'get']],
        // 获取充值提示信息
        'getDepositTips/:symbol'         => ['index/Coin/getDepositTips', ['method' => 'get']],
        // 获取提币提示信息
        'getWithdrawTips/:symbol'        => ['index/Coin/getWithdrawTips', ['method' => 'get']],
        // 获取转换提示信息
        'getTransTips/:symbol/:trans_to' => ['index/Coin/getTransTips', ['method' => 'get']],
        // 获取托管说明信息
        'getTrusteeTips/:symbol'         => ['index/Coin/getTrusteeTips', ['method' => 'get']],
        // 转换
        'translate'                      => ['index/Coin/translate', ['method' => 'post']],
        // 提币
        'withdraw'                       => ['index/Coin/withdraw', ['method' => 'post']],
        // 托管
        'trustee'                        => ['index/Coin/trustee', ['method' => 'post']],
        // 取消托管
        'cancelTrustee/:id'              => ['index/Coin/cancelTrustee', ['method' => 'get']],
        // 获取托管记录
        'getTrustees/'                   => ['index/Coin/getTrustees', ['method' => 'get']],
        // 获取托管详情
        'getTrusteeDetail/:id'           => ['index/Coin/getTrusteeDetail', ['method' => 'get']],
        // 取消自动续托
        'disableAutoRenewal/:id'         => ['index/Coin/disableAutoRenewal', ['method' => 'get']],
        // 获取充值记录
        'getDeposits'                    => ['index/Coin/getDeposits', ['method' => 'get']],
        // 获取充值详情
        'getDepositDetail/:id'           => ['index/Coin/getDepositDetail', ['method' => 'get']],
        // 获取提币记录
        'getWithdraws/:symbol'           => ['index/Coin/getWithdraws', ['method' => 'get']],
        // 获取充值详情
        'getWithdrawDetail/:id'          => ['index/Coin/getWithdrawDetail', ['method' => 'get']],
        // 获取转换记录
        'getTranslates/:symbol'          => ['index/Coin/getTranslates', ['method' => 'get']],
        // 获取充值详情
        'getTranslateDetail/:id'         => ['index/Coin/getTranslateDetail', ['method' => 'get']],
        // 获取到账收益记录
        'getIncomes/:symbol'             => ['index/Coin/getIncomes', ['method' => 'get']],
        // 获取到账收益详情
        'getIncomeDetail/:id'            => ['index/Coin/getIncomeDetail', ['method' => 'get']],
        // 获取在途收益记录
        'getPendIncomes/:symbol'         => ['index/Coin/getPendIncomes', ['method' => 'get']],
        // 获取在途收益详情
        'getPendIncomeDetail/:id'        => ['index/Coin/getPendIncomeDetail', ['method' => 'get']],

        /********************** 资讯 **************************/

        // 添加资讯
        'refreshInformation'             => ['index/News/refresh', ['method' => 'get']],
        // 消息列表
        'getInformations'                => ['index/News/getInformations', ['method' => 'get']],
        // 读取消息详情
        'getInformationDetail/:id'       => ['index/News/getInformationDetail', ['method' => 'get']],

        /******************** 个人中心 *************************/

        // 获取个人资料
        'getUserProfile'                 => ['index/Home/profile', ['method' => 'get']],
        // 获取个人邀请码
        'getInviteCode'                  => ['index/Home/getInviteCode', ['method' => 'get']],
        // 设置用户头像
        'setHead'                        => ['index/Home/setHead', ['method' => 'post']],
        // 设置手势密码
        'setGesture'                     => ['index/Home/setGesture', ['method' => 'post']],
        // 设置交易密码
        'setTrader'                      => ['index/Home/setTrader', ['method' => 'post']],
        // 修改登录密码
        'setPassword'                    => ['index/Home/setPassword', ['method' => 'post']],
        // 实名认证
        'certificate'                    => ['index/Home/certificate', ['method' => 'post']],
        // 未读消息提醒
        'getMessageNotice'               => ['index/Home/getMessageNotice', ['method' => 'get']],
        // 消息列表
        'getMessages'                    => ['index/Home/getMessages', ['method' => 'get']],
        // 读取消息详情
        'readMessage/:id'                => ['index/Home/readMessage', ['method' => 'get']],
        // 图片上传
        'uploadImage'                    => ['index/Home/upimg', ['method' => 'post']],
        // 核对充币记录
        'confirmDeposit'                 => ['index/Home/confirmDeposit', ['method' => 'post']],
        // 获取邀请返佣信息
        'getInviteCounting'              => ['index/Home/getInviteCounting', ['method' => 'get']],
        // 分页获取邀请返佣列表
        'getInviteIncomes'               => ['index/Home/getInviteIncomes', ['method' => 'get']],
        // 校验交易密码
        'checkTrader'                    => ['index/Home/checkTrader', ['method' => 'post']],
        // 校验登录密码
        'checkPassword'                  => ['index/Home/checkPassword', ['method' => 'post']],
        // 提交工单
        'addFeedback'                    => ['index/Home/addFeedback', ['method' => 'post']],
        // 工单留言
        'replyFeedback'                  => ['index/Home/replyFeedback', ['method' => 'post']],
        // 工单列表
        'getFeedbacks'                   => ['index/Home/getFeedbacks', ['method' => 'get']],
        // 工单详情
        'getFeedbackDetail/:id'          => ['index/Home/getFeedbackDetail', ['method' => 'get']],
    ],
    '[admin]' => [
        // 分页查询充币记录
        'deposit/getList'                => ['admin/Deposit/getList', ['method' => 'get']],
        // 查询充币详情
        'deposit/getDetail/:id'          => ['admin/Deposit/getDetail', ['method' => 'get']],
        // 分页查询提币记录
        'withdraw/getList'               => ['admin/Withdraw/getList', ['method' => 'get']],
        // 查询提币详情
        'withdraw/getDetail/:id'         => ['admin/Withdraw/getDetail', ['method' => 'get']],
        // 分页查询划转记录
        'translate/getList'              => ['admin/Translate/getList', ['method' => 'get']],
        // 查询划转详情
        'translate/getDetail/:id'        => ['admin/Translate/getDetail', ['method' => 'get']],
        // 分页查询托管记录
        'trustee/getList'                => ['admin/Trustee/getList', ['method' => 'get']],
        // 查询托管详情
        'trustee/getDetail/:id'          => ['admin/Trustee/getDetail', ['method' => 'get']],
        // 分页查询用户邀请收益概览列表
        'income/getList'                 => ['admin/Income/getList', ['method' => 'get']],
        // 设置邀请人数和收益
        'income/setFakeCounting'         => ['admin/Income/setFakeCounting', ['method' => 'post']],
        // 设置邀请返佣记录
        'income/setFakeRecord'           => ['admin/Income/setFakeRecord', ['method' => 'post']],
        // 分页查询用户收益明细列表
        'income/getDetailList'           => ['admin/Income/getDetailList', ['method' => 'get']],
        // 获取滚动消息提醒
        'notice/getRolling'              => ['admin/Index/getRollingNotice', ['method' => 'get']],
    ],
];
