<?php
// +----------------------------------------------------------------------
// | Description: 基础框架路由配置文件
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honghaiweb.com>
// +----------------------------------------------------------------------

return [
    // 定义资源路由
    '__rest__'=>[
        'admin/rules'		   =>'admin/rules',
        'admin/groups'		   =>'admin/groups',
        'admin/users'		   =>'admin/users',
        'admin/menus'		   =>'admin/menus',
        'admin/structures'	   =>'admin/structures',
        'admin/posts'          =>'admin/posts',
    ],

    'index/market/huobi' => ['index/market/getHuobiMarket'],
	// 【基础】登录
	'admin/base/login' => ['admin/base/login', ['method' => 'POST']],
	// 【基础】记住登录
	'admin/base/relogin'	=> ['admin/base/relogin', ['method' => 'POST']],
	// 【基础】修改密码
	'admin/index/setInfo' => ['admin/index/setInfo', ['method' => 'POST']],
	// 【基础】退出登录
	'admin/base/logout' => ['admin/base/logout', ['method' => 'POST']],
	// 【基础】获取配置
	'admin/base/getConfigs' => ['admin/base/getConfigs', ['method' => 'POST']],
	// 【基础】获取验证码
	'admin/base/getVerify' => ['admin/base/getVerify', ['method' => 'GET']],
	// 【基础】上传图片
	'admin/upload' => ['admin/upload/index', ['method' => 'POST']],
    // 【token管理】刷新token
    'admin/index/refreshToken/:token' => ['admin/index/refreshToken', ['method' => 'GET']],
    // 【菜单管理】查询用户菜单
    'admin/index/getMenuList' => ['admin/index/getMenuList', ['method' => 'GET']],
    // 【菜单管理】查询用户菜单,树形结构
    'admin/index/getMenuTreeList' => ['admin/index/getMenuTreeList', ['method' => 'GET']],
    // 【会员管理】查询会员信息，分页
    'admin/user/index' => ['admin/users/index', ['method' => 'POST']],
    // 【会员管理】查询会员信息，分页
    'admin/user/userCards' => ['admin/users/userCards', ['method' => 'POST']],
    // 【币种管理】查询数字货币信息
    'admin/coin/index' => ['admin/coin/index', ['method' => 'GET']],
    // 【币种管理】修改数字货币信息
    'admin/coin/update' => ['admin/coin/update', ['method' => 'POST']],
    // 【会员管理】会员状态修改
    'admin/user/disabled/:userId' => ['admin/users/disabled', ['method' => 'GET']],
    // 【会员管理】会员状态修改
    'admin/user/userRecharge' => ['admin/users/userRecharge', ['method' => 'POST']],
    // 【托管收益配置管理】托管收益配置列表
    'admin/trustee/config' => ['admin/trustee/config', ['method' => 'GET']],
    // 【托管收益配置管理】修改托管收益信息
    'admin/trustee/update' => ['admin/trustee/update', ['method' => 'POST']],
    // 【资讯管理】发布资讯
    'admin/news/publish' => ['admin/news/publish', ['method' => 'POST']],
    'admin/news/update' => ['admin/news/update', ['method' => 'POST']],
    'admin/news/getArticles' => ['admin/news/getArticles', ['method' => 'POST']],
    'admin/news/getArticle/:id' => ['admin/news/getArticle', ['method' => 'GET']],
    'admin/news/modifyNewsStatus/:id' => ['admin/news/modifyNewsStatus', ['method' => 'GET']],
    'admin/news/getFeedbacks' => ['admin/news/getFeedbacks', ['method' => 'GET']],
    'admin/news/getFeedbackDetail/:id' => ['admin/news/getFeedbackDetail', ['method' => 'GET']],
    'admin/news/replyFeedback' => ['admin/news/replyFeedback', ['method' => 'POST']],

	// 保存系统配置
	'admin/systemConfigs' => ['admin/systemConfigs/save', ['method' => 'POST']],
	// 【规则】批量删除
	'admin/rules/deletes' => ['admin/rules/deletes', ['method' => 'POST']],
	// 【规则】批量启用/禁用
	'admin/rules/enables' => ['admin/rules/enables', ['method' => 'POST']],
	// 【用户组】批量删除
	'admin/groups/deletes' => ['admin/groups/deletes', ['method' => 'POST']],
	// 【用户组】批量启用/禁用
	'admin/groups/enables' => ['admin/groups/enables', ['method' => 'POST']],
	// 【用户】批量删除
	'admin/users/deletes' => ['admin/users/deletes', ['method' => 'POST']],
	// 【用户】批量启用/禁用
	'admin/users/enables' => ['admin/users/enables', ['method' => 'POST']],
	// 【菜单】批量删除
	'admin/menus/deletes' => ['admin/menus/deletes', ['method' => 'POST']],
	// 【菜单】批量启用/禁用
	'admin/menus/enables' => ['admin/menus/enables', ['method' => 'POST']],
	// 【组织架构】批量删除
	'admin/structures/deletes' => ['admin/structures/deletes', ['method' => 'POST']],
	// 【组织架构】批量启用/禁用
	'admin/structures/enables' => ['admin/structures/enables', ['method' => 'POST']],
	// 【部门】批量删除
	'admin/posts/deletes' => ['admin/posts/deletes', ['method' => 'POST']],
	// 【部门】批量启用/禁用
	'admin/posts/enables' => ['admin/posts/enables', ['method' => 'POST']],


	//登录
	'api/base/login' => ['api/base/login', ['method' => 'POST']],
	//注册
	'api/base/register' => ['api/base/register', ['method' => 'POST']],
	//获取验证码
	'api/base/getVerify/:id' => ['api/base/getVerify', ['method' => 'GET']],
	//找回密码
	'api/base/getbackpassword' => ['api/base/getbackpassword', ['method' => 'POST']],
	//发送验证码
	'api/base/sendcode' => ['api/base/sendcode', ['method' => 'POST']],
    //发送验证码
    'api/base/checkPhoneCode' => ['api/base/checkPhoneCode', ['method' => 'POST']],
	//设置修改交易密码
	'api/base/setup' => ['api/base/sendcode', ['method' => 'POST']],
	//设置收款方式
	'api/user/setpayway' => ['api/users/setpayway', ['method' => 'POST']],
	//设置交易密码
	'api/user/setpaytrader' => ['api/users/setpaytrader', ['method' => 'POST']],
    //修改交易密码
    'api/user/modifyTrader' => ['api/users/modifyTrader', ['method' => 'POST']],
	//修改登录密码
	'api/user/changeloginpassword' => ['api/users/changeloginpassword', ['method' => 'POST']],
	//转让排单币
	'api/index/attompaicoin' => ['api/index/attompaicoin', ['method' => 'POST']],
	//转让激活码
	'api/index/attomactivationcode' => ['api/index/attomactivationcode', ['method' => 'POST']],
	//激活码用户
	'api/index/activationuser' => ['api/index/activationuser', ['method' => 'POST']],
	//点击抽奖
	'api/index/lotterydraw' => ['api/index/lotterydraw', ['method' => 'POST']],
	//获取抽奖列表
	'api/index/drawlist' => ['api/index/drawlist', ['method' => 'POST']],
	//我的钱包
	'api/index/mywallet' => ['api/index/mywallet', ['method' => 'POST']],
	//我的团队
	'api/index/myteam' => ['api/index/myteam', ['method' => 'POST']],
	//我的团队账号
	'api/index/allmyteam' => ['api/index/allmyteam', ['method' => 'POST']],
	//问题留言
	'api/index/askquestion' => ['api/index/askquestion', ['method' => 'POST']],
	//提供帮助
	// 'api/index/offerhelp' => ['api/index/offerhelp', ['method' => 'POST']],
	'api/index/offer' => ['api/index/offer', ['method' => 'POST']],
	//帮助记录
	'api/index/offerhelpnotes' => ['api/index/offerhelpnotes', ['method' => 'POST']],
	//帮助详情
	'api/index/offerhelpinfo' => ['api/index/offerhelpinfo', ['method' => 'POST']],
    //接受帮助详情
    'api/index/acceptHelpInfo' => ['api/index/acceptHelpInfo', ['method' => 'POST']],
	//接受帮助
	'api/index/accept' => ['api/index/accept', ['method' => 'POST']],
	//交易匹配
	'api/index/trade' => ['api/index/trade', ['method' => 'POST']],
	//上传图片
	'api/upload' => ['api/upload/index', ['method' => 'POST']],
	//上传交易凭证
	'api/index/uploadeimg' => ['api/index/uploadeimg', ['method' => 'POST']],
	'api/index/sysUpLoadeImg' => ['api/index/sysUpLoadeImg', ['method' => 'POST']],
	//待帮助确认收款
	'api/index/accept_gather' => ['api/index/accept_gather', ['method' => 'POST']],
	'api/index/sys_accept_gather' => ['api/index/sys_accept_gather', ['method' => 'POST']],
	//后台确认匹配成立
	'api/index/confirm_notes' => ['api/index/confirm_notes', ['method' => 'POST']],
	//获取上一代，和上三代
	'api/index/getfatheruser' => ['api/index/getfatheruser', ['method' => 'POST']],
	//获取用户的信息
	'api/users/getUserInfo' => ['api/users/getUserInfo', ['method' => 'POST']],
	//判断当前是否存在正在排单
	'api/index/offer_state' => ['api/index/offer_state', ['method' => 'POST']],
	//我的帮助
	'api/index/myhelplist' => ['api/index/myhelplist', ['method' => 'POST']],
	//我的帮助
	'api/index/myacceptlist' => ['api/index/myacceptlist', ['method' => 'POST']],
	//静态钱包
	'api/index/jing_wallet' => ['api/index/jing_wallet', ['method' => 'POST']],
	//生成二维码
	'api/index/create_qrcode' => ['api/index/create_qrcode', ['method' => 'POST']],
	//动态钱包
	'api/index/dong_wallet' => ['api/index/dong_wallet', ['method' => 'POST']],
	//绿色通道
	'api/index/green_channel' => ['api/index/green_channel', ['method' => 'POST']],
	//接受帮助状态判断
	'api/index/accept_state' => ['api/index/accept_state', ['method' => 'POST']],
    //拒绝收款
    'api/index/refuse_accept' => ['api/index/refuse_accept', ['method' => 'POST']],
    //超时收款
    'api/index/overtime_accept' => ['api/index/overtime_accept', ['method' => 'POST']],
    //绿色通道状态
    'api/index/green_channel_state' => ['api/index/green_channel_state', ['method' => 'POST']],
    //绿色通道列表
    'api/index/green_channel_list' => ['api/index/green_channel_list', ['method' => 'POST']],
    //绿色通道 提现
    'api/index/green_channel_cash' => ['api/index/green_channel_cash', ['method' => 'POST']],
    //绿色通道 提现
    'api/index/green_channel_gather' => ['api/index/green_channel_gather', ['method' => 'POST']],
    //绿色通道 提现记录
    'api/index/green_channel_accept' => ['api/index/green_channel_accept', ['method' => 'POST']],
    //绿色通道 帮助详情
    'api/index/green_channel_offer' => ['api/index/green_channel_offer', ['method' => 'POST']],
    //绿色通道 接受详情
    'api/index/green_channel_accepthelp' => ['api/index/green_channel_accepthelp', ['method' => 'POST']],
    //绿色通道 帮助记录
    'api/index/green_channel_helplist' => ['api/index/green_channel_helplist', ['method' => 'POST']],
    //静态收益账单
    'api/index/jing_wallet_list' => ['api/index/jing_wallet_list', ['method' => 'POST']],
    //匹配结果列表
    'api/index/getallnotes' => ['api/index/getallnotes', ['method' => 'POST']],
    //进场出场人数
    'api/index/getallnums' => ['api/index/getallnums', ['method' => 'POST']],
    //后台确认订单
    'api/index/confirm_status' => ['api/index/confirm_status', ['method' => 'POST']],
    //修改提供帮助时间
    'api/index/change_offer_time' => ['api/index/change_offer_time', ['method' => 'POST']],
    //修改接受帮助时间
    'api/index/change_accept_time' => ['api/index/change_accept_time', ['method' => 'POST']],
    //修改绿色通道时间
    'api/index/change_green_time' => ['api/index/change_green_time', ['method' => 'POST']],
    'api/index/getSystemNum' => ['api/index/getSystemNum', ['method' => 'POST']],
    'api/index/updateSystemNum' => ['api/index/updateSystemNum', ['method' => 'POST']],
    'api/index/offerList' => ['api/index/offerList', ['method' => 'POST']],
    'api/index/greenList' => ['api/index/greenList', ['method' => 'POST']],
    'api/index/acceptList' => ['api/index/acceptList', ['method' => 'POST']],



    /**
     * 山东后台管理系统
     */
    //index
    'api/orders/index' => ['api/orders/index', ['method' => 'POST']],
    //添加模板>>搜索部件
    'api/orders/search_parts' => ['api/orders/search_parts', ['method' => 'POST']],
    //添加模板
    'api/orders/add_template' => ['api/orders/add_template', ['method' => 'POST']],
    //添加订单
    'api/orders/add_orders' => ['api/orders/add_orders', ['method' => 'POST']],
    //模板搜索
    'api/orders/search_template' => ['api/orders/search_template', ['method' => 'POST']],
    //添加原材料库存
    'api/orders/add_material' => ['api/orders/add_material', ['method' => 'POST']],
    //原材料入库出库  del_material
    'api/orders/material_stock' => ['api/orders/material_stock', ['method' => 'POST']],
    //原材料删除  
    'api/orders/del_material' => ['api/orders/del_material', ['method' => 'POST']],
    //模板列表  
    'api/orders/template_list' => ['api/orders/template_list', ['method' => 'POST']],
    //模板删除  
    'api/orders/del_template' => ['api/orders/del_template', ['method' => 'POST']],
    //订单列表  
    'api/orders/order_list' => ['api/orders/order_list', ['method' => 'POST']],
    //订单删除  
    'api/orders/del_order' => ['api/orders/del_order', ['method' => 'POST']],
    //发货  
    'api/orders/delivery' => ['api/orders/delivery', ['method' => 'POST']],
    //显示订单信息（单个订单）  
    'api/orders/show_order' => ['api/orders/show_order', ['method' => 'POST']],
    //订单编辑
    'api/orders/change_order' => ['api/orders/change_order', ['method' => 'POST']],
    //置顶
	'api/orders/operate_top' => ['api/orders/operate_top', ['method' => 'POST']],
	//总排产计划
	'api/orders/schedule_order' => ['api/orders/schedule_order', ['method' => 'POST']],
	//排产
	'api/orders/schedule' => ['api/orders/schedule', ['method' => 'POST']],
	//车间排产计划
	'api/orders/workshop_order' => ['api/orders/workshop_order', ['method' => 'POST']],
	//产品入库出库
	'api/orders/product_stock' => ['api/orders/product_stock', ['method' => 'POST']],
	// 【基础】登录
	'admin/base/setInfo' => ['admin/base/setInfo', ['method' => 'POST']],
	// 获取配件信息（单个订单）
	'api/orders/getoneorderparts' => ['api/orders/getoneorderparts', ['method' => 'POST']],
	// 模板信息获取（单个）
	'api/orders/getOneTemplate' => ['api/orders/getOneTemplate', ['method' => 'POST']],
	// 编辑模板
	'api/orders/changeTemplate' => ['api/orders/changeTemplate', ['method' => 'POST']],
	// 获取工作车间列表
	'api/orders/getWorkshopOneOrder' => ['api/orders/getWorkshopOneOrder', ['method' => 'POST']],
	// 获取所有的原材料库存
	'api/orders/getAllMaterial' => ['api/orders/getAllMaterial', ['method' => 'POST']],
	// 获取所有的产品库存
	'api/orders/getAllProduct' => ['api/orders/getAllProduct', ['method' => 'POST']],
	// 添加产品库存
	'api/orders/addProductStock' => ['api/orders/addProductStock', ['method' => 'POST']],
	// 入库申请
	'api/orders/aplyStock' => ['api/orders/aplyStock', ['method' => 'POST']],
	// 入库审核列表
	'api/orders/getWorkshopAply' => ['api/orders/getWorkshopAply', ['method' => 'POST']],
	// 审核入库申请
	'api/orders/reviewAply' => ['api/orders/reviewAply', ['method' => 'POST']],
	//发货  
	'api/orders/sendEditNumm' => ['api/orders/sendEditNumm', ['method' => 'POST']],
	//经纬度
	'api/orders/getlnglat' => ['api/orders/getlnglat', ['method' => 'POST']],

	// MISS路由
	'__miss__'  => 'admin/base/miss',
];