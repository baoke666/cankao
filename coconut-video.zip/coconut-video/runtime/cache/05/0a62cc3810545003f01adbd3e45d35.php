<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"9dd533e0-8f9a-4656-89fc-fd9f68274146";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}