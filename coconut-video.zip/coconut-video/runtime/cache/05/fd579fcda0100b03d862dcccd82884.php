<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"3a3161ce-ab8b-462a-9f00-fae77270ebfb";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}