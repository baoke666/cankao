<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"25ec38e2-bc33-4565-bde6-cdca486e9015";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}