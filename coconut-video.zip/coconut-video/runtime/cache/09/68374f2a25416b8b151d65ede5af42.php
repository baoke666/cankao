<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"47506c7a-bdb6-4727-90f5-947c6fa43474";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}