<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f612521f-714f-44c7-a7b8-f5c0a2f71978";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}