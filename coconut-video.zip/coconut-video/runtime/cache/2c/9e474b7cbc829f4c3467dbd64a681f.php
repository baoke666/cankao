<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"b70ce8a7-c619-40b2-8159-5595f71861fd";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}