<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"16248d66-f617-4b8e-9ba6-30e920773fde";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}