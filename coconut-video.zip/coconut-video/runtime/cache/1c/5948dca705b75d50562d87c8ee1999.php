<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"9286ea83-1da0-4f16-9b14-0cf7f0415f51";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}