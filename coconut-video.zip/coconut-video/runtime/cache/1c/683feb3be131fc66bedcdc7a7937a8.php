<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2bd83b52-231c-47d6-af12-04cf8bd11583";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}