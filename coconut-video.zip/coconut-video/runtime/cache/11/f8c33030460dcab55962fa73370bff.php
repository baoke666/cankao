<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"bd95800d-89e1-4e43-9a04-01d5688cf09a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}