<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cce6b493-ad31-49d9-b9f8-875e42d4c0a4";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}