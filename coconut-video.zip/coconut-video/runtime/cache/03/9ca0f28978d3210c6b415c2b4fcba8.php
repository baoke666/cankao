<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8000220e-ac43-4640-b1a2-63a3719ba8ad";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}