<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"665c98db-4193-459e-bc0d-9d60aa0d0d0b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}