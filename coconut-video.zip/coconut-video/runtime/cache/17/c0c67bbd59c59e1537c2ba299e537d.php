<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5dd0a482-58f6-4ebd-b14c-567e7533febf";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}