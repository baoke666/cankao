<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cfc9860a-ae0c-44af-bfb9-c76d18f68dfb";s:7:"user_id";i:63;s:6:"expire";s:4:"3600";}