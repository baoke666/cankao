<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2b8d46ae-17c5-4736-9d05-b95c6df945e9";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}