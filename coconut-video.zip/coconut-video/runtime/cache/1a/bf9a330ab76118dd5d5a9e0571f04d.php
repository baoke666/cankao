<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cfcb0bbd-ddd6-4cdf-b5a2-dbfb1fba42cc";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}