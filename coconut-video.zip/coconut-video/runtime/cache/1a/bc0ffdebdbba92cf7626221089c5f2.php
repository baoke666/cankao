<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cfbf59cc-57d3-4dbf-99a0-37509d4dfd7f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}