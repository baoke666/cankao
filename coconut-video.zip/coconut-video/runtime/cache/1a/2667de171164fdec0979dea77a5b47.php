<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"835d84b2-c216-4e6f-af4b-5d4b3b043383";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}