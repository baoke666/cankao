<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"17d975d4-8b02-440f-9fcd-a67361ac2b88";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}