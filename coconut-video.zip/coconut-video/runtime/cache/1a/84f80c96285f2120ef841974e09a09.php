<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"6374bc76-7a33-4eb9-9847-a06d65fcca0c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}