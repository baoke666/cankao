<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e20b4c78-d54c-40f5-bc1f-6940bc0f1c3a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}