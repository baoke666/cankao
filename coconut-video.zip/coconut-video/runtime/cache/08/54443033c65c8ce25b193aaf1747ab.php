<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"48ac7854-9b9b-458c-a86e-38326c58b937";s:7:"user_id";i:3;s:6:"expire";s:4:"3600";}