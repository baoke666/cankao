<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"fcf09abe-18ea-468e-ab18-3ae0bc6392b6";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}