<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"d25eb20c-ea09-4466-8073-c405bc94486f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}