<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5257f466-df1f-4acd-ba7f-eb3b0487da04";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}