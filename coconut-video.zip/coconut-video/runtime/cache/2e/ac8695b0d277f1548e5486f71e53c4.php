<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"076af639-a771-4ccb-bfea-c8e456d856a1";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}