<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"6a6ef339-f7cb-407b-ab2a-f18533abe8eb";s:7:"user_id";i:71;s:6:"expire";s:4:"3600";}