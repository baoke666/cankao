<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"00384f6c-27d4-4ab6-bbc1-bd69bb85a2fb";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}