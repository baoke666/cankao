<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"93039309-ee0a-4e59-8cdf-093822b23ede";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}