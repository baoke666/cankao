<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"6d1797cb-3c92-4ca3-9f3c-2dde03ffdb8b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}