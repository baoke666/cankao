<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"0cda16d6-4466-4fee-ad9e-468f50ac8be3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}