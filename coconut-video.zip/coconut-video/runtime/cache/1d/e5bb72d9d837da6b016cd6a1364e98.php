<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1b6a3e50-d6e4-42f2-bf73-ee9778d4a6e4";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}