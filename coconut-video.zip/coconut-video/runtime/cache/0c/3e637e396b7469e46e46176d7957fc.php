<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cbf8e351-65f3-4bb4-82ec-d928c98aa262";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}