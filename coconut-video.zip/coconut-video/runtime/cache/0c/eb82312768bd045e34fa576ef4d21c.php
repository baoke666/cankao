<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"743fdfe8-3f7f-40f3-a099-5e5d693e87fd";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}