<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e3ab5ed3-1ae8-4bb9-9ea2-c8587a5d926c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}