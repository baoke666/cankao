<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"fb753db3-6819-4149-ac18-e23cb3c9bac1";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}