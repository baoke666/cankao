<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ad11a007-3bd8-428f-a2e1-2f94484b8eb1";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}