<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"a236771a-f51f-4c88-ab32-7b53c89239f0";s:7:"user_id";i:63;s:6:"expire";s:4:"3600";}