<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e398fcde-cb69-4b96-95ce-160a200f2e83";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}