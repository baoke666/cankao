<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f064ff1c-088f-403c-a660-2579f1526dcc";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}