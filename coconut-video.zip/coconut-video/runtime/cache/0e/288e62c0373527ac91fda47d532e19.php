<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"c436095f-fac6-4cd5-8a3f-c5f7d43d2731";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}