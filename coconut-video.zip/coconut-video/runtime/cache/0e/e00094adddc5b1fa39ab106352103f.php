<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"c6f2f0d2-13d3-4711-b7ba-6837c5435aff";s:7:"user_id";i:13;s:6:"expire";s:4:"3600";}