<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"3b8d4fdf-5c05-4233-9a97-c976ff5334d3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}