<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"61b95b78-29f2-4ede-904c-d2a21f12e56b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}