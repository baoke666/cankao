<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"29b30fcd-5e03-49dc-814c-4caf1831041a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}