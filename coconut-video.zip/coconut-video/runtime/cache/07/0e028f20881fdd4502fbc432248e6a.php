<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1bb25117-8a5e-49d4-acf0-0965e63d0eb0";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}