<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"97e89119-d9be-493b-9e1e-95fc5a88c696";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}