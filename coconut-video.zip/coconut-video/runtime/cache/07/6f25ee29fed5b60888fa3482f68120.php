<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8592718b-8d80-44fa-895e-2712ca4e30dd";s:7:"user_id";i:63;s:6:"expire";s:4:"3600";}