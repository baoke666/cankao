<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e7b44c68-48e4-4ae6-8437-ccd3782d000d";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}