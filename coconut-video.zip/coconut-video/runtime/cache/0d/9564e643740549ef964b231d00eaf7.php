<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e6774407-ca9e-4ddf-9879-e638e72a49b0";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}