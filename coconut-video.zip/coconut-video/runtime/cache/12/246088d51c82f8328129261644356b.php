<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"254a26db-cc8d-4b0f-8ecc-fa4b2559b12d";s:7:"user_id";i:75;s:6:"expire";s:4:"3600";}