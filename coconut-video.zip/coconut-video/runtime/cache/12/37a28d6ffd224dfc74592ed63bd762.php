<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e15ff212-ecf6-44be-bbf7-dd9b1cc25705";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}