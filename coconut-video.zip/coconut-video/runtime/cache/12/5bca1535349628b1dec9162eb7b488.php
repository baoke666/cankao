<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"cf33d6cd-d068-4661-8597-0c25dc5e926b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}