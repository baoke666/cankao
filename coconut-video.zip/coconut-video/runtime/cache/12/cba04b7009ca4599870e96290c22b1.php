<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1bac6a73-fcda-4b7a-b43f-d4c99227d310";s:7:"user_id";i:63;s:6:"expire";s:4:"3600";}