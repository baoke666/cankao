<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"626d3db3-fb8d-473e-8ed5-c1749f9d6046";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}