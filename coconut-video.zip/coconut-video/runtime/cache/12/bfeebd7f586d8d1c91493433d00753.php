<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5c29bb78-20dc-4767-91c3-1e5e6f9e09b3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}