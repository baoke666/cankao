<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"012a6178-987a-48d1-b25a-81d47bf41d18";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}