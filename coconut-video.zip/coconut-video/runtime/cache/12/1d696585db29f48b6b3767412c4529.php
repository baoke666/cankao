<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ad925446-b1f1-44dd-a79c-f099a47590b8";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}