<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"08b28a2d-af54-4808-8e9b-8bd83c3888e6";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}