<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"0b29c99b-9e67-49f3-a0be-2123f4956027";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}