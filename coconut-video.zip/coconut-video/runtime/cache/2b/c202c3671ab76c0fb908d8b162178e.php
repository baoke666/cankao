<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"284832e0-c425-41c5-92b0-a57e7c6b4a35";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}