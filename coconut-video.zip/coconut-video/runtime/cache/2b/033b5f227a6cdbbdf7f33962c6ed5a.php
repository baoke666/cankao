<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2e01cd96-8ecc-4ffd-9d83-316de730567b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}