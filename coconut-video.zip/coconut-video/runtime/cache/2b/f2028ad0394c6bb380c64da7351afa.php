<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ab7e43dc-0d76-479d-bc66-9d28f208e5ff";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}