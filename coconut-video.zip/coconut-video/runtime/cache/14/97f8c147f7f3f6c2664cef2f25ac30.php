<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8d727af0-6c5f-4d0b-852f-fb4e70491dcb";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}