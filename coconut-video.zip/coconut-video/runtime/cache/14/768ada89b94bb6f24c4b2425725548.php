<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e4ad6876-b2f8-48ff-a128-15256c66dde1";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}