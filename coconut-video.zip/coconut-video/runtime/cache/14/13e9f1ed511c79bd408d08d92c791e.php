<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"74226ed6-e380-4af6-872a-85c9a9340b24";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}