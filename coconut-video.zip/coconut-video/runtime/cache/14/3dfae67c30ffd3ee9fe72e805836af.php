<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"98a2df98-ca6d-42f5-83e5-e286b6e11361";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}