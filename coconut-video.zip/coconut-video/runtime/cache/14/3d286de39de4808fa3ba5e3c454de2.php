<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e1e72982-711d-46f2-9edb-a4dbeec08004";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}