<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"3687beb8-cb32-4247-9000-2a46b511e35c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}