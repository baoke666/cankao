<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ab81aaea-6a25-43df-aac0-cf094d6a1b3f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}