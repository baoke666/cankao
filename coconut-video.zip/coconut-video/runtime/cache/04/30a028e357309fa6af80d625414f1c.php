<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"426e47f2-b4cf-47e9-a64c-873616b78fcf";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}