<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"147ad5c9-bf46-446a-ad48-6159aea95b5f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}