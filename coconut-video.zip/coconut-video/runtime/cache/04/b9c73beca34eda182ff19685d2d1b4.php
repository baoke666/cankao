<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"33fa42ef-513d-4162-b9b3-cc48255acc48";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}