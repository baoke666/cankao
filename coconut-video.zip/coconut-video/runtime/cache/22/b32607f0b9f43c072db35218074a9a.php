<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"acdfe26c-0d1a-49ac-b90d-a87050af8ce1";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}