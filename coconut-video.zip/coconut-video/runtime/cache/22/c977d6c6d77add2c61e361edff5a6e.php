<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"765abc2e-bdd4-4f93-b366-b9e473d0b8c3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}