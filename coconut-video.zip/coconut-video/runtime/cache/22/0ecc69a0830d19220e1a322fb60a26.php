<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"a91e5070-21c3-48cf-91f9-075d561b1d17";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}