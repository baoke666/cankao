<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e7bc5241-32e6-485f-a2a0-e08952f1609d";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}