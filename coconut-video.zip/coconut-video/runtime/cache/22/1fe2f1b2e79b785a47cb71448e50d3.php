<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"3b536486-9bd1-4885-b24c-6fc17f0bb10f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}