<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8f2e55d6-0576-4795-b1f9-f06c627f0bb9";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}