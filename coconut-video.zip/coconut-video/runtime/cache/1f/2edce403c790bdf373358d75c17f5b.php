<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"db4726e4-763f-41f3-815b-89238aae2f2b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}