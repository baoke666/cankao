<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2f96993f-2cb0-4e69-a2a6-26fe3eb3ba66";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}