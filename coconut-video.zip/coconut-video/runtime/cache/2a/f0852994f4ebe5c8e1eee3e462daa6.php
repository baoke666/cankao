<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"07c3962e-cc2f-4249-b16f-aba1b22fb9e1";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}