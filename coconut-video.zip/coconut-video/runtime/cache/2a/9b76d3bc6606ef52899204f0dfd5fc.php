<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"9f7e8e69-0c93-4ded-979c-feb9da98882e";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}