<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e50468d9-7185-49f6-a624-1db69c16ed91";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}