<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f8210a81-0148-4aea-bf7e-a7b62f9c5436";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}