<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5775e62b-2809-4a31-995b-be24159ca3e8";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}