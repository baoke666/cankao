<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"dd9528d4-0c51-4b99-b28a-7aed3f02780b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}