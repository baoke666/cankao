<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"b72e3143-03bd-4379-a65f-7ea59eccb1b5";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}