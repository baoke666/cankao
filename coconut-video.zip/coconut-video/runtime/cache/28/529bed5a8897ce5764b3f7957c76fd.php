<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"9b44f9a1-bc17-4d60-8735-005cc26c93f8";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}