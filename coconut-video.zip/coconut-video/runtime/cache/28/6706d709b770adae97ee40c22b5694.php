<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"230d296c-aa22-451f-ab7c-a80bb9db06aa";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}