<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"6c6ca42e-af67-4df7-926c-8da9fffe6cf5";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}