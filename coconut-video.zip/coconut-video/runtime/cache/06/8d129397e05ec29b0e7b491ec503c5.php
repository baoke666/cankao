<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"0138b995-b1b4-4e9c-90de-228025fa1504";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}