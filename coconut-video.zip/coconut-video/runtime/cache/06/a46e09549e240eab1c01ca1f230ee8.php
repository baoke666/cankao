<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"17c01a44-889a-40f0-a0eb-9dafb554c19a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}