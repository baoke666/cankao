<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"bdb21247-4264-483f-9990-f1b50fc87a8f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}