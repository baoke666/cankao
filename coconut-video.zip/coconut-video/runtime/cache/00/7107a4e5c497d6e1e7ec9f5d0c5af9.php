<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"df4b6185-ffa3-4934-a23e-02edba168dbe";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}