<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"b02d23ba-c07b-4676-923b-3991487e844e";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}