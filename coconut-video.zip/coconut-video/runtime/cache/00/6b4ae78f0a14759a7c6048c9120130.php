<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5a5b7a25-a8e7-45de-9c9d-35805ce5175d";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}