<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"929f53f3-280a-4efc-8636-02e3f767be34";s:7:"user_id";i:67;s:6:"expire";s:4:"3600";}