<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2d3f64fd-2eea-4e46-9427-b80b9e6ff49c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}