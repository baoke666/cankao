<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"149d7afd-73c5-407b-aef2-76d63c6f31ca";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}