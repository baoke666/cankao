<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"a86ace58-0e92-4948-82ee-9fde38d0d1e5";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}