<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"75632aff-d853-49b0-a9cf-a76b483bf216";s:7:"user_id";i:67;s:6:"expire";s:4:"3600";}