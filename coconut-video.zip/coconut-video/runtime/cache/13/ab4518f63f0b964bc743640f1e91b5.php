<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ad160bbe-85f4-4cc0-9e3e-f871b254ca9c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}