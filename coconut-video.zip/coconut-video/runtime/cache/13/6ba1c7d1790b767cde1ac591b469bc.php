<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"682ca239-6fd0-4635-b2f0-e3fc93d11c56";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}