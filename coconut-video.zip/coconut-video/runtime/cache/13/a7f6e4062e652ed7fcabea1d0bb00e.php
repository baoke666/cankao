<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"df6fde59-6ade-4978-a24c-c9ab4e3cee04";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}