<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"646a216c-1ac7-496d-b8c3-77d2416eccee";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}