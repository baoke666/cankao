<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"91c4e9f1-a220-4614-96a7-e48d91d88f4c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}