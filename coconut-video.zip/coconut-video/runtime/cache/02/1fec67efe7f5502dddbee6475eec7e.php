<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f4c1fa7d-70a4-40a8-b9bf-a2c013d08d7b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}