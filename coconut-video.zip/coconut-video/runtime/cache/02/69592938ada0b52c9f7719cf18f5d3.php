<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8552f357-b6c7-4088-acf1-52a9cb843fa4";s:7:"user_id";i:3;s:6:"expire";s:4:"3600";}