<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"aad6d38c-67b6-4bee-b693-14a216830fac";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}