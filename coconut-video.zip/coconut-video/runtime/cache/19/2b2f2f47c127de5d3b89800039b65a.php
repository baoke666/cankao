<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"d104ff16-3f5e-4cd4-bf7f-250e6d810b90";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}