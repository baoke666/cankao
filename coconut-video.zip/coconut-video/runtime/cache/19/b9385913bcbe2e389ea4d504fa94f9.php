<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"92b5d9f9-a39a-4106-a277-64d0a51e84c3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}