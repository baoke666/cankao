<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"d5c10db0-3da2-4c5c-adb0-6da019d21a41";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}