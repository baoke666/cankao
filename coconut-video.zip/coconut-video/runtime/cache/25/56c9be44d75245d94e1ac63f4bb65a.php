<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e9ccfe6f-ef62-498c-ae3f-06efd3acfc2a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}