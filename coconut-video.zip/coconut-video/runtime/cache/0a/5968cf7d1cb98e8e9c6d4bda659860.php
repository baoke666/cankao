<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"813e8c6c-6632-46f7-b655-c8fbbf8f5115";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}