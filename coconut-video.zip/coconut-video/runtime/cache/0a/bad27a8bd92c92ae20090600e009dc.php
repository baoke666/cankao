<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1c9f4cca-9ebf-491d-bd38-4d64f2a0b506";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}