<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1bcb9589-b548-44e1-90f7-8e043539a18a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}