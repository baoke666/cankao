<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ab45f7ae-c567-4807-906a-f7446c5b4a3c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}