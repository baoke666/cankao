<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"70f52627-787a-43c1-8d79-e4c2bc932edd";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}