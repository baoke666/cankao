<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ea2a4cec-0e3e-46c0-a146-91edef0d19e6";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}