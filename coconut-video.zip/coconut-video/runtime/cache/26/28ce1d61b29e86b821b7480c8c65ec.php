<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"79f474ff-6e87-4bf6-a4f7-f07176473703";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}