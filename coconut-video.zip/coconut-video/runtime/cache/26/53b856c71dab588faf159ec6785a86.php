<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"be45dba9-489e-439e-bae8-1161fe38197c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}