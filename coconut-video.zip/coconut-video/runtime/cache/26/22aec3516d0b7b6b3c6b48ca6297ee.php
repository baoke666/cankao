<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"aea340f4-b40d-4d68-92c3-2c88dc93da42";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}