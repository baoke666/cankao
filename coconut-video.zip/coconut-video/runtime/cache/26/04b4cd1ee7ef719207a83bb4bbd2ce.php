<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"5f1c01d9-5dce-43d0-b000-a64bcc447e65";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}