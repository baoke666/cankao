<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1ac9e3aa-78d9-422c-b034-37768eca34ec";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}