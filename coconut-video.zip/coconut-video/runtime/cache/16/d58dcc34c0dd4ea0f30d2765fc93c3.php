<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2e24a981-2cdb-4e9d-a9d4-7172928ecc90";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}