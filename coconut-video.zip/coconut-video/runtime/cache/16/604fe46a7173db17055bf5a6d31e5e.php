<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f4d9a40d-f269-43ee-8df1-e65cd6ca5703";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}