<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f0f21dc9-40fd-438f-a7b8-6ba85fc66619";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}