<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"ff734a5e-5958-4bff-b940-8595259a1ab3";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}