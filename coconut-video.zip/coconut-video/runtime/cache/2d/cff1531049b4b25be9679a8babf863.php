<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"2eedc284-09e5-40e9-8ab6-43cae2f8c3c0";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}