<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f56eaa0d-44dc-46f6-bd2d-d2712ff0ddbb";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}