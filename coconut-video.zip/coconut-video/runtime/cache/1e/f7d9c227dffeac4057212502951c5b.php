<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e3e29b56-2e18-436c-a1a1-8c5db0c2a664";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}