<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"be093474-5229-4023-8c65-0aa1ac0437fa";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}