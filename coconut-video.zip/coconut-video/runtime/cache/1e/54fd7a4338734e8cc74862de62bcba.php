<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f5e04cc2-928d-49e5-8d38-3bebd09abcd4";s:7:"user_id";i:13;s:6:"expire";s:4:"3600";}