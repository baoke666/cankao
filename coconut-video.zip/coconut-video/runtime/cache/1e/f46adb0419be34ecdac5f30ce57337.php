<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"9ee783ce-5aec-466f-91c1-944b0dd91a8f";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}