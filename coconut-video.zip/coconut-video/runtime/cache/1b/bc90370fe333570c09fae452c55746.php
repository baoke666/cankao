<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"70607bdd-dd8a-44a7-8aaa-eb59bd5e08ac";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}