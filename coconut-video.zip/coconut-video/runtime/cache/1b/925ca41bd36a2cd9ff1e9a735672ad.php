<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"e6124fbc-9c73-4bcb-bbc3-b90ea2c99149";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}