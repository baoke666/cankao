<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"8902f91f-bbfb-4b5a-a53d-5ddc3415e14d";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}