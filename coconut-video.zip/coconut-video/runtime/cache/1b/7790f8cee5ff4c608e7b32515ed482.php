<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"f235a6b9-968d-4921-a899-de30ea78485c";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}