<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"d0d90b9f-53f7-4f5c-a53e-d7e0a7872ea9";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}