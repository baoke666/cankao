<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"63766a0d-08a2-4148-bf0e-e0bcde95fe63";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}