<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"bce30c85-42e3-48e7-b59e-c26200429d2a";s:7:"user_id";i:75;s:6:"expire";s:4:"3600";}