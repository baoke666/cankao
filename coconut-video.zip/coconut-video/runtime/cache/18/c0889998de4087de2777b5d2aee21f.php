<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"84792c96-0ca5-4f07-b15b-d69456181cfe";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}