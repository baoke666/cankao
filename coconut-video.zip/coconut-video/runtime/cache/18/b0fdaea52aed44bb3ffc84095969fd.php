<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"476d0580-ba54-4fd8-918b-4310444a5eab";s:7:"user_id";i:13;s:6:"expire";s:4:"3600";}