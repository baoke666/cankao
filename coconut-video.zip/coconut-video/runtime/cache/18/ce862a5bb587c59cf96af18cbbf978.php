<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1fc36ba3-4a13-4ed3-b8c8-3609fe8b57cb";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}