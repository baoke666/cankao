<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"a177ec5b-b92c-4b80-8908-376d177d551e";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}