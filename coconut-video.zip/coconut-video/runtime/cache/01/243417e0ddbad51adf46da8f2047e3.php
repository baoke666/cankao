<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"df56d54e-637f-493a-bea6-304f39a78f81";s:7:"user_id";i:15;s:6:"expire";s:4:"3600";}