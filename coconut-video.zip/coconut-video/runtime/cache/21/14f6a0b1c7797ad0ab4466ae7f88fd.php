<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"48aeefdc-e618-458d-9e84-e0b6ef216784";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}