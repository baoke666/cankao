<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"1a4829dd-baef-4bb0-956e-8fd4a1250c50";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}