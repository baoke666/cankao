<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"4dcd1be7-3702-4e93-b10c-c34f1c56614a";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}