<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"16697460-e0be-4e6b-9159-b5c2a898169b";s:7:"user_id";i:2;s:6:"expire";s:4:"3600";}