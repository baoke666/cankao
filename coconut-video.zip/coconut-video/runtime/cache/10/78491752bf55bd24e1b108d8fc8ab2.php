<?php
//000000003600
 exit();?>
a:3:{s:5:"token";s:36:"bbb34fa9-8642-463e-80ff-502b6d81777b";s:7:"user_id";i:1;s:6:"expire";s:4:"3600";}