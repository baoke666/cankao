<?php
namespace app\api\controller;

use app\api\model\User;
use com\verify\HonrayVerify;

class Index
{
	/**
	 * 用户名，密码登录
	 */
	public function login(){
		$data=input('post.');
		$username=$data["username"];
		$password=$data["password"];
		$data=User::getuserinfo($username,$password);
		return json($data);
	}
	/**
	 * 用户注册  用户名 图形验证码 推荐人手机号 密码 确认密码
	 */
	public function register(){
		$params = input('param.');
		return $params;die;
		$captcha = new HonrayVerify(config('captcha'));
        return $captcha->entry($id);

	}
}