<?php
// +----------------------------------------------------------------------
// | Description: 系统用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\api\controller;

use think\Db;


class Users extends ApiCommon
{

    /**
     * 修改登录密码
     */
    public function changeloginpassword(){

        $user = model('user');
        return $user->changeloginpassword(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 交易密码设置
     */
    public function setpaytrader(){

        $user = model('user');
        return $user->setpaytrader(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 交易密码修改
     */
    public function modifyTrader(){

        $user = model('user');
        return $user->setpaytrader(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 收款方式
     */
    public function setpayway(){
        $user = model("User");
        return $user->setpayway(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 获取用户信息
     */
    public function getUserInfo(){
        $user = model("User");
        return $user->getUserInfo(array_merge($this->param, ['userid' => $this->getUserId()]));
    }



    /**
     * 冻结/解冻用户
     * @return array
     */
    public function disabled()
    {
        $param = $this->param;
        $user_id = $param['userId'];

        $user = Db::name('user')->where('id', $user_id)->find();
        if (empty($user))
            return resultArray(['error' => '用户不存在']);

        if ($user['status'] == 1)
            $status = 0;
        else if ($user['status'] == 0)
            $status = 1;
        else
            $status = $user['status'];

        Db::name('user')->where('id', $user_id)->update(['status' => $status]);
        return resultArray(['data' => ['status' => $status , 'desc' => '更新用户状态成功']]);
    }

    public function userCards(){
        $param = $this->param;
        $name = $param['name'];
        $phone = $param['phone'];
        $type = $param['type'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? $this->pageSize : $param['limit'];

        $where = [];
        if (!empty($name))
            $where['a.realname'] = $name;
        if (!empty($phone))
            $where['b.phone'] = $phone;
        if (!empty($type)) {
            $where['a.status'] = $type;
        }

        $count = Db::name('user_certificate')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id', 'inner')
            ->where($where)
            ->order('a.create_time desc')
            ->count();

        $cardList = Db::name('user_certificate')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id', 'inner')
            ->field('a.*, b.phone')
            ->where($where)
            ->page($page, $limit)
            ->select();
        return resultArray(['data' => ['cardList' => $cardList, 'count' => $count]]);
    }

    public function verifyUserCard() {
        $param = $this->param;
        $id = $param['id'];
        $type = $param['type'];
        $remark = $param['remark'];

        if (empty($id) || empty($type)) {
            return resultArray(['error' => '缺少参数']);
        }

        if ($type == 'success')
            $remark = '';

        Db::name('user_certificate')->where('id', $id)->update(['status' => $type, 'remark' => $remark, 'update_time' => time()]);
        return resultArray(['data' => ['status' => $type , 'remark' => $remark , 'desc' => '更新用户状态成功']]);
    }

    public function save()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->createData($param);
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '添加成功']);
    }

    public function update()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->updateDataById($param, $param['id']);
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '编辑成功']);
    }

    public function delete()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->delDataById($param['id']);       
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '删除成功']);    
    }

    public function deletes()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->delDatas($param['ids']);  
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '删除成功']); 
    }

    public function enables()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->enableDatas($param['ids'], $param['status']);  
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '操作成功']);         
    }
    
}
 