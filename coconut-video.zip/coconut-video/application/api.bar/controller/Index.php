<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/4 0004
 * Time: 下午 10:59
 */

namespace app\api\controller;

use think\Db;
use app\common\library\Token;
use com\verify\HonrayVerify;
use app\common\controller\Common;
use think\Config;
use think\Request;

class Index extends Common
{
    /**
     * 获取新的token
     */
    public function refreshToken(){
        $old = $this->param['token'];
        if (empty($old))
            return resultArray(['error' => "用户未登录"]);
        if (!Token::check($old))
            return resultArray(['error' => "用户登录已失效"]);
        return resultArray(['data' => Token::refresh($old)]);
    }

    /**
     * 获取菜单导航和菜单权限，树形结构
     */
    public function getMenuTreeList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId(), "tree")]);
    }

    /**
     * 获取菜单导航和菜单权限，列表结构
     */
    public function getMenuList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId())]);
    }

    /**修改管理员密码
     * @return array
     */
    public function setInfo()
    {
        $adminModel = model('Admin');
        $param = $this->param;
        $old_pwd = $param['oldPaw'];
        $new_pwd = $param['newPaw'];

        $data = $adminModel->setInfo($this->getUserId(), $old_pwd, $new_pwd);
        if (!$data) {
            return resultArray(['error' => $adminModel->getError()]);
        }
        return resultArray(['data' => $data]);
    }

    /**获取滚动消息
     * @return array
     */
    public function getRollingNotice()
    {
        $data = array();
        $newC = Db::name('user_certificate')
            ->where(['status' => 'pend'])
            ->count();
        if ($newC) {
            array_push($data, ['type' => 'certificate', 'content' => '有新的实名认证申请']);
        }
        $newF = Db::name('feedback')
            ->where('type', '=', '1')
            ->where('status', '=', '0')
            ->count();
        if ($newF) {
            array_push($data, ['type' => 'feedback', 'content' => '有新的用户工单']);
        }
        return resultArray(['data' => $data]);
    }
    /**
     * 转让排单币
     */
    public function attompaicoin(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->attompaicoin($param);
        return $data;
    }
    /**
     * 转让激活码
     */
    public function attomactivationcode(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->attomactivationcode($param);
        return $data;
    }
    /**
     * 激活用户
     */
    public function activationuser(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->activationuser($param);
        return $data;
    }
    /**
     * 点击抽奖
     */
    public function lotterydraw(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->lotterydraw($param);
        return $data;
    }
    /**
     * 抽奖列表
     */
    public function drawlist(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->drawlist($param);
        return $data;
    }
    /**
     * 我的钱包
     */
    public function mywallet(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->mywallet($param);
        return $data;
    }
    /**
     * 我的团队
     */
    public function myteam(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->myteam($param);
        return $data;
    }
    /**
     * 激活账号
     */
    public function allmyteam(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->allmyteam($param);
        return $data;
    }
    /**
     * 问题留言
     */
    public function askquestion(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->askquestion($param);
        return $data;
    }
    //提供帮助
    public function offerhelp(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->offerhelp($param);
        return $data;
    }
    //帮助记录
    public function offerhelpnotes(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->offerhelpnotes($param);
        return $data;
    }
    //帮助详情
    public function offerhelpinfo(){
        $adminModel=model("Admin");
        $param= $this->param;
        $data=$adminModel->offerhelpinfo($param);
        return $data;
    }
    /**
     * 
     */
    public function create_table(){
        
    }
}