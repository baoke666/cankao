<?php
// +----------------------------------------------------------------------
// | Description: 用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\api\model;

use app\common\library\Token;
use think\Cache;
use think\Config;
use think\Db;
use app\api\model\Common;
use com\verify\HonrayVerify;

class Admin extends Common
{

    /**
     * 为了数据库的整洁，同时又不影响Model和Controller的名称
     * 我们约定每个模块的数据表都加上相同的前缀，比如微信模块用weixin作为数据表前缀
     */
    protected $createtime = 'createtime';
    protected $updateTime = 'updatetime';
	protected $autoWriteTimestamp = true;
	protected $insert = [
		'status' => 1,
	];
	/**
	 * 获取用户所属所有用户组
	 * @param  array   $param  [description]
	 */
    public function groups()
    {
        return $this->belongsToMany('group', '__ADMIN_ACCESS__', 'group_id', 'user_id');
    }

    /**
     * [getDataList 列表]
     * @AuthorHTL
     * @DateTime  2017-02-10T22:19:57+0800
     * @param     [string]                   $keywords [关键字]
     * @param     [number]                   $page     [当前页数]
     * @param     [number]                   $limit    [t每页数量]
     * @return    [array]                             [description]
     */
	public function getDataList($keywords, $page, $limit)
	{
		$map = [];
		if ($keywords) {
			$map['username|realname'] = ['like', '%'.$keywords.'%'];
		}

		// 默认除去超级管理员
		$map['user.id'] = array('neq', 1);
		$dataCount = $this->alias('user')->where($map)->count('id');

		$list = $this
				->where($map)
				->alias('user')
				->join('__ADMIN_STRUCTURE__ structure', 'structure.id=user.structure_id', 'LEFT')
				->join('__ADMIN_POST__ post', 'post.id=user.post_id', 'LEFT');

		// 若有分页
		if ($page && $limit) {
			$list = $list->page($page, $limit);
		}

		$list = $list
				->field('user.*,structure.name as s_name, post.name as p_name')
				->select();

		$data['list'] = $list;
		$data['dataCount'] = $dataCount;

		return $data;
	}

	/**
	 * [getDataById 根据主键获取详情]
	 * @linchuangbin
	 * @DateTime  2017-02-10T21:16:34+0800
	 * @param     string                   $id [主键]
	 * @return    [array]
	 */
	public function getDataById($id = '')
	{
		$data = $this->get($id);
		if (!$data) {
			$this->error = '暂无此数据';
			return false;
		}
		$data['groups'] = $this->get($id)->groups;
		return $data;
	}
	/**
	 * 创建用户
	 * @param  array   $param  [description]
	 */
	public function createData($param)
	{
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}

		// 验证
		$validate = validate($this->name);
		if (!$validate->check($param)) {
			$this->error = $validate->getError();
			return false;
		}

		$this->startTrans();
		try {
			$param['password'] = user_md5($param['password']);
			$this->data($param)->allowField(true)->save();

			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $this->id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);

			$this->commit();
			return true;
		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '添加失败';
			return false;
		}
	}

	/**
	 * 通过id修改用户
	 * @param  array   $param  [description]
	 */
	public function updateDataById($param, $id)
	{
		// 不能操作超级管理员
		if ($id == 1) {
			$this->error = '非法操作';
			return false;
		}
		$checkData = $this->get($id);
		if (!$checkData) {
			$this->error = '暂无此数据';
			return false;
		}
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}
		$this->startTrans();

		try {
			Db::name('admin_access')->where('user_id', $id)->delete();
			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);

			if (!empty($param['password'])) {
				$param['password'] = user_md5($param['password']);
			}
			 $this->allowField(true)->save($param, ['id' => $id]);
			 $this->commit();
			 return true;

		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '编辑失败';
			return false;
		}
	}


    /**
     * @param $username
     * @param $password
     * @param string $verifyCode
     * @param string $codeId 验证码编号
     * @param bool $isRemember
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
	public function login($username, $password, $verifyCode, $codeId, $isRemember = false)
	{
        if (!$username) {
			$this->error = '帐号不能为空';
			return false;
		}
		if (!$password){
			$this->error = '密码不能为空';
			return false;
		}
        if (!$verifyCode) {
            $this->error = '验证码不能为空';
            //return false;
        }
        $captcha = new HonrayVerify(config('captcha'));
        if (!$captcha->check($verifyCode, $codeId)) {
            $this->error = '验证码错误';
            //return false;
        }

		$map['username'] = $username;
		$userInfo = $this->where($map)->find();
    	if (!$userInfo) {
			$this->error = '帐号不存在';
			return false;
    	}
//    	if ($userInfo['loginfailure'] >= 3){
//            $this->error = '密码错误已经达到3次，账户将被锁定2个小时';
//            return false;
//        }
    	if (user_md5($password.$userInfo['salt']) !== $userInfo['password']) {
            $userInfo['loginfailure'] = $userInfo['loginfailure'] + 1;
            $userInfo['logintime'] = time();
            $userInfo->save();
			$this->error = '密码错误';
			return false;
    	}
    	if ($userInfo['status'] === 'closed') {
			$this->error = '帐号已被禁用';
			return false;
    	}
//        // 获取菜单和权限
//        $dataList = $this->getMenuAndRule($userInfo['id']);
//
//        if (!$dataList['menusList']) {
//			$this->error = '没有权限';
//			return false;
//        }

        if ($isRemember) {
        	$secret['username'] = $username;
        	$secret['password'] = $password;
            $data['rememberKey'] = encrypt($secret);
        }

//        // 保存缓存
//        session_start();
//        $info['userInfo'] = $userInfo;
//        $info['sessionId'] = session_id();
//        $authKey = user_md5($userInfo['username'].$userInfo['password'].$info['sessionId']);
//        $info['_AUTH_LIST_'] = $dataList['rulesList'];
//        $info['authKey'] = $authKey;
//        cache('Auth_'.$authKey, null);
//        cache('Auth_'.$authKey, $info, config('LOGIN_SESSION_VALID'));
//        // 返回信息
//        $data['authKey']		= $authKey;
//        $data['sessionId']		= $info['sessionId'];
//        $data['userInfo']		= $userInfo;
//        $data['authList']		= $dataList['rulesList'];
//        $data['menusList']		= $dataList['menusList'];
        return Token::create($userInfo['id']);

    }

	/**
	 * 修改密码
	 * @param  array   $param  [description]
	 */
    public function setInfo($id, $old_pwd, $new_pwd)
    {
        if (!$old_pwd) {
			$this->error = '请输入旧密码';
			return false;
        }
        if (!$new_pwd) {
            $this->error = '请输入新密码';
			return false;
        }
        if ($new_pwd == $old_pwd) {
            $this->error = '新旧密码不能一致';
			return false;
        }

        $userInfo = $this->where('id', $id)->find();
        if (user_md5($old_pwd.$userInfo['salt']) != $userInfo['password']) {
            $this->error = '原密码错误';
			return false;
        }
        if (user_md5($new_pwd) == $userInfo['password']) {
            $this->error = '密码没改变';
			return false;
        }
        if ($this->where('id', $id)->setField('password', user_md5($new_pwd.$userInfo['salt']))) {
            return true;
        }
        $this->error = '修改失败';
		return false;
    }

	/**
	 * 获取菜单和权限
	 * @param  array   $param  [description]
	 */
    protected function getMenuAndRule($u_id)
    {
    	if ($u_id === 1) {
            $map['status'] = 1;
    		$menusList = Db::name('admin_menu')->where($map)->order('sort asc')->select();
    	} else {
    		$groups = $this->get($u_id)->groups;
            $ruleIds = [];
    		foreach($groups as $k => $v) {
    			$ruleIds = array_unique(array_merge($ruleIds, explode(',', $v['rules'])));
    		}

            $ruleMap['id'] = array('in', $ruleIds);
            $ruleMap['status'] = 1;
            // 重新设置ruleIds，除去部分已删除或禁用的权限。
            $rules =Db::name('admin_rule')->where($ruleMap)->select();
            foreach ($rules as $k => $v) {
            	$ruleIds[] = $v['id'];
            	$rules[$k]['name'] = strtolower($v['name']);
            }
            empty($ruleIds)&&$ruleIds = '';
    		$menuMap['status'] = 1;
            $menuMap['rule_id'] = array('in',$ruleIds);
            $menusList = Db::name('admin_menu')->where($menuMap)->order('sort asc')->select();
        }
        if (!$menusList) {
            return null;
        }
        //处理菜单成树状
        $tree = new \com\Tree();
        $ret['menusList'] = $tree->list_to_tree($menusList, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['menusList'] = memuLevelClear($ret['menusList']);
        // 处理规则成树状
        $ret['rulesList'] = $tree->list_to_tree($rules, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['rulesList'] = rulesDeal($ret['rulesList']);

        return $ret;
    }
    /**
     * 验证是否存在账户手机号为我的下级
     */
    public function isexitelowuser($userid="",$phone=""){
    	//查询一代
    	$phoneinfo=Db::name("user")->where("phone=$phone")->find();
    	$inviteid=$phoneinfo['inviter_id'];
    	if($inviteid==$userid){
    		return true;
    	}else{
    		$inviteinfo=Db::name("user")->where("id=$inviteid")->find();
    		if($inviteinfo['inviter_id']==$userid){
    			return true;
    		}else{
    			return false;
    		}
    	}
    }
    /**
     * 转让排单币
     */
    public function attompaicoin($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$phone=$param['phone'];
    	$paicoinnum=$param['paicoinnum'];
    	$isexitelowuser=$this->isexitelowuser($userid,$phone);
    	if(!$isexitelowuser){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改user数据
    	$result1=Db::name("user")->where("id=$userid")->find();
    	$paicoin1=$result1['paicoin']-$paicoinnum;
    	if($paicoin1<0){
    		return $this->error("2007","排单币余额不足，转让失败",array());
    	}
    	$result2=Db::name("user")->where("phone=$phone")->find();
    	$paicoin2=$result2['paicoin']+$paicoinnum;
    	$res1=Db::name("user")->where("id=$userid")->update(array("paicoin"=>$paicoin1));
    	$res2=Db::name("user")->where("phone=$phone")->update(array("paicoin"=>$paicoin2));
    	if($res1 && $res2){
    		$data=array(
    			"code"=>200,
    			"message"=>"转让成功",
    			"body"=>array(
    				"id"=>$userid,
    				"paicoin"=>$paicoin1
    			)
    		);
    		return json($data);
    	}else{
    		return $this->error("2005","转让失败",array());
    	}
    	
    }
    /**
     * 转让激活码
     */
    public function attomactivationcode($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$phone=$param['phone'];
    	$activationcodenum=$param['activationcodenum'];
    	$isexitelowuser=$this->isexitelowuser($userid,$phone);
    	if(!$isexitelowuser){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改user数据
    	$result1=Db::name("user")->where("id=$userid")->find();
    	$activationcode1=$result1['activationcode']-$activationcodenum;
    	if($activationcode1<0){
    		return $this->error("2007","排单币余额不足，转让失败",array());
    	}
    	$result2=Db::name("user")->where("phone=$phone")->find();
    	$activationcode2=$result2['activationcode']+$activationcodenum;
    	$res1=Db::name("user")->where("id=$userid")->update(array("activationcode"=>$activationcode1));
    	$res2=Db::name("user")->where("phone=$phone")->update(array("activationcode"=>$activationcode2));
    	if($res1 && $res2){
    		$data=array(
    			"code"=>200,
    			"message"=>"转让成功",
    			"body"=>array(
    				"id"=>$userid,
    				"activationcode"=>$activationcode1
    			)
    		);
    		return json($data);
    	}else{
    		return $this->error("2005","转让失败",array());
    	}
    }
    /**
     * 激活用户
     */
    public function activationuser($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$activationuserid=$param["activationuserid"];
    	//获取当前用户的信息
    	$userinfo=Db::name("user")->where("id=$userid")->find();
    	if($userinfo["activationcode"]<0){
    		return $this->error("2007","当前用户的激活码为0，激活失败",array());
    	}
    	if($userinfo["activation"]==0){
    		return $this->error("2011","当前用户未激活",array());
    	}
    	//获取被激活用户的信息
    	$activationuserinfo=Db::name("user")->where("id=$activationuserid")->find();
    	$phone=$activationuserinfo['phone'];
    	if(!$this->isexitelowuser($userid,$phone)){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改用户的状态
    	$result=Db::name("user")->where("id=$activationuserid")->update(array("activation"=>1));
    	if($result){
    		//修改当前用户的激活码数目
    		$res=Db::name("user")->where("id=$userid")->update(array("activationcode"=>$userinfo["activationcode"]-1));
    		if(!$res){
    			return $this->error("2009","激活失败",array());
    		}
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=>array(
    				"id"=>$userid
    			)
    		);
    		return json($data);
    	}else{
    		return $this->error("2005","用户已激活，请刷新页面",array());
    	}
    }
    /**
     * 点击抽奖
     */
    public function lotterydraw($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param["userid"];
    	$listid=$param['listid'];
    	//查询奖品结果
    	$drawinfo=Db::name("lottery_draw")->where("list=$listid")->find();
    	//用户信息
    	$userinfo=Db::name("user")->where("id=$userid")->find();
    	$data=array(
    		"paicoin"=>$userinfo["paicoin"]+$drawinfo["paicoin_num"],
    		"activationcode"=>$userinfo["activationcode"]+$drawinfo["activationcode_num"],
    	);
    	//修改信息
    	$result=Db::name("user")->where("id=$userid")->update($data);
    	if(!$result){
    		return $this->error("2003","抽奖失败",array());
    	}else{
    		//添加抽奖流水表单
    		$info=array(
    			"userid"=>$userid,
    			"draw_list_id"=>$listid,
    			"createtime"=>time()
    		);
    		$res=Db::name("draw_list")->insert($info);
    		if(!$res){
    			return $this->error("2005","抽奖记录添加失败",array());
    		}
    		//当天抽奖次数
    		$today=strtotime(date("Y-m-d"),time());
    		$todayend=$today+60*60*24;
    		$count=Db::name("draw_list")->where("createtime between $today and $todayend")->count();
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=>array(
    				"id"=>$userid,
    				"activationcode"=>$userinfo["activationcode"]+$drawinfo["activationcode_num"],
    				"paicoin"=>$userinfo["paicoin"]+$drawinfo["paicoin_num"],
    				"count"=>$count
    			)
    		);
    		return json($data);
    	}
    }
    /**
     * 奖品列表
     */
    public function drawlist($param=""){
    	$userid=$param["userid"];
    	if(!$userid){
    		return $this->error("2001","请确认用户登录",array());
    	}
    	//获取奖品列表
    	$datalist=Db::name("lottery_draw")->field("id,list,descrition")->select();
    	if(!$datalist){
    		return $this->error("2003","获取失败",array());
    	}else{
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=>$datalist
    		);
    		return json($data);
    	}
    }
    /**
     * 我的钱包
     */
    public function mywallet($param=""){
    	$userid=$param["userid"];
    	$userinfo = Db::name('user')
			    ->alias('m')
			    ->join("t_pay_list a", 'm.id = a.userid','left')
			    ->where("m.id=$userid")
			    ->field('m.id,m.username,m.phone,m.paicoin,m.activationcode,a.money,a.jing_money,a.dong_money,a.ben_money,a.shou_money')
			    ->find();
		if(!$userinfo){
			return $this->error("2001","用户信息获取失败",array());
		}else{
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=>$userinfo
    		);
    		return json($data);
    	}
    }
    /**
     * 我的团队
     */
    public function myteam($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        if($userinfo['activation']==0){
            return $this->error("2003","当前用户未激活",array(
                "userid"=>$userinfo['id'],
                "phone"=>$userinfo['phone'],
                "activation"=>$userinfo['activation'],
            ));
        }
        //直系人数
        $directcount=Db::name('user')->where("inviter_id=$userid")->count();
        //获取用户的直系
        $directuser = Db::name('user')
                ->alias('m')
                ->join("t_pay_list a",'m.id = a.userid','left')
                ->where("m.inviter_id=$userid")
                ->field('m.id,m.username,m.phone,m.realname,m.activation,a.shou_money')
                ->select();
        //获取二代用户
        foreach ($directuser as $key => $v) {
            $arr=Db::name('user')->where("inviter_id=".$v['id'])->field("id,phone")->find();
            if($arr){
                $bibasicuser[]=$arr;
            }
        }
        //获取三代用户
        foreach ($bibasicuser as $k => $val) {
            $tertuser = Db::name('user')
                ->alias('m')
                ->join("t_pay_list a",'m.id = a.userid','left')
                ->where("m.inviter_id=".$val['id'])
                ->field('m.id,m.username,m.phone,m.realname,m.activation,a.shou_money')
                ->select();
        }
        $tertcount=count($tertuser);
        //组合数组
        $result=array(
            "directcount"=>$directcount,
            "directuser"=>$directuser,
            "tertcount"=>$tertcount,
            "tertuser"=>$tertuser,
        );
        return json($result);
    }
    /**
     * 获取三代以内的所有成员
     */
    public function allmyteam($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        if($userinfo['activation']==0){
            return $this->error("2003","当前用户未激活",array(
                "userid"=>$userinfo['id'],
                "phone"=>$userinfo['phone'],
                "activation"=>$userinfo['activation'],
            ));
        }
        //直系
        $directuser=Db::name("user")->where("inviter_id=$userid")->field("id,phone,username,realname,create_time,activation")->select();
        //二代
        foreach ($directuser as $key => $v) {
            $arr=Db::name('user')->where("inviter_id=".$v['id'])->field("id,phone,username,realname,create_time,activation")->find();
            if($arr){
                $bibasicuser[]=$arr;
            }
        }
        //三代
        foreach ($bibasicuser as $k => $val) {
            $tertuser=Db::name("user")->where("inviter_id=".$val["id"])->field("id,phone,username,realname,create_time,activation")->select();
        }
        $result=array_merge($directuser,$bibasicuser,$tertuser);
        foreach ($result as $k => $v) {
            if($v['activation']==0){
                $arr1[]=$v;
            }else{
                $arr2[]=$v;
            }
        }
        $data=array(
            "tobeactivation"=>$arr1?$arr1:array(),
            "enabledactivation"=>$arr2?$arr2:array()
        );
        return json($data);
    }
    /**
     * 问题留言
     */
    public function askquestion($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        $question=$param["question"];
        if(empty($question)){
            return $this->error("2003","问题留言不能为空",array());
        }
        //添加留言
        $data=array(
           "userid"=>$userid, 
           "question"=>$question, 
           "ask_time"=>time()
        );
        //检查是否重复添加
        $isexite=Db::name("question_answer")->where(array("userid"=>$userid,"question"=>$question))->find();
        if($isexite){
            return $this->error("2007","请不要重复添加留言",array());
        }
        $result=Db::name("question_answer")->insert($data);
        if(!$result){
            return $this->error("2005","添加失败",array());
        }else{
            $list=Db::name("question_answer")->where(array("userid"=>$userid,"question"=>$question))->find();
            $res=array(
                "code"=>200,
                "message"=>"留言添加成功",
                "body"=>array(
                    "id"=>$list['id'],
                    "userid"=>$list['userid'],
                    "question"=>$list['question']
                )
            );
            return json($res);
        }
    }
    /**
     * 提供帮助
     */
    public function offerhelp($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        $offer_money=$param['offer_money'];
        $offer_num=$param['offer_num'];
        $is_own=$param['is_own']?$param['is_own']:0;
        $is_green_channel=$param['is_green_channel']?$param['is_green_channel']:0;
        if(!$offer_money || !$offer_num){
            return $this->error("2003","输入数据不能为空",array());
        }
        //判断时间
        $today=strtotime(date("Y-m-d"),time());
        $today9=$today+60*60*9;
        $today14=$today+60*60*14+30*60;
        $time=time();
        //查询总人数
        $usernum=Db::name("offer_list")->where("$time between $today9 and $today14")->count();
        if($usernum>$offer_num){
            return $this->error("2005","今日提供帮助服务已结束",array());
        }
        $over_money=$offer_money*0.8;
        $help_money=$offer_money*0.2;
        $data=array(
            "userid"=>$userid,
            "offer_money"=>$offer_money,
            "offer_num"=>$offer_num,
            "is_own"=>$is_own,
            "create_time"=>time(),
            "is_green_channel"=>$is_green_channel,
            "over_money"=>$over_money,
            "help_money"=>$help_money,
        );
        //添加平台收取的20%
        $payment=Db::name("payment_admin")->where("is_play=1")->find();
        if(empty($payment)){
            return $this->error("2007","请先设置平台账户",array());
        }
        //添加数据库
        $res=Db::name("offer_list")->insert($data);
        $offerinfo=Db::name("offer_list")->where($data)->find();
        //添加帮助记录表单
        $arr=array( 
            "offer_userid"=>$userid,
            "accept_userid"=>"0",
            "offer_id"=>$offerinfo['id'],
            "create_time"=>time(),
            "pay_status"=>"0",
            "zfbname"=>$payment['payment'],
            "help_money"=>$offer_money*0.2
        );
        $result=Db::name("offer_accept_list")->insert($arr);
        if(!$result){
            return $this->error("2009","平台账单添加错误",array());
        }
        if(!$res){
            return $this->error("2011","数据提交失败",array());
        }else{
            //排单匹配
            $readypai=Db::name("offer_list")->where("is_apply_help=1")->select();
            foreach ($readypai as $key => $val) {
                //申请帮助信息
                $helpinfo=Db::name("accept_list")->where("is_finish=0 and userid=".$val['userid'])->find();
                if($helpinfo){
                    $money=$helpinfo['money']-$helpinfo['have_accept_money']-$over_money;
                    if($money>0){
                        $info=array(
                            "have_accept_money"=>$over_money,
                            "is_finish"=>"0"
                        );
                        $help_money=$offer_money*0.8;
                        $over_money=0;
                    }else{
                        $info=array(
                            "have_accept_money"=>$helpinfo['money']?$helpinfo['money']:"0",
                            "is_finish"=>"1"
                        );
                        $help_money=$helpinfo['money']-$helpinfo['have_accept_money']+$offer_money*0.2;
                        $over_money=$over_money-$helpinfo['money']+$helpinfo['have_accept_money'];
                    }
                    //帮助记录表单
                    $accept_userinfo=Db::name("user")->where("id=".$val["userid"])->find();
                    $arr1=array( 
                        "offer_userid"=>$userid,
                        "accept_userid"=>$val['userid'],
                        "offer_id"=>$offerinfo['id'],
                        "create_time"=>time(),
                        "pay_status"=>"0",
                        "zfbname"=>$accept_userinfo['zfbname'],
                        "help_money"=>$help_money
                    );
                    Db::name("offer_accept_list")->insert($arr1);
                    Db::name("accept_list")->where("userid=".$val['userid'])->update($info);
                    Db::name("offer_list")->where("userid=".$userid." and id=".$offerinfo['id'])->update(array("help_money"=>$help_money,"over_money"=>$over_money));
                }
            }
            //返回值    获取帮助记录
            $offer_accept_info=Db::name("offer_accept_list")->where("offer_id=".$offerinfo['id'])->select();
            $list=array();
            foreach ($offer_accept_info as $k => $v) {
                //获取接收帮助人的信息
                $accept_userinfo=Db::name("user")->where("id=".$v["accept_userid"])->find();
                $list[]=array(
                    "status"=>$v['status'],
                    "create_time"=>$v['create_time'],
                    "help_money"=>$v['help_money'],
                    "pay_status"=>$v['pay_status'],
                    "phone"=>$accept_userinfo['phone'],
                    "offer_id"=>$userid,
                    "offer_money"=>$offer_money,
                    "accept_id"=>$accept_userinfo['id']?$accept_userinfo['id']:"0",
                    "zfbname"=>$accept_userinfo['zfbname']?$accept_userinfo['zfbname']:$payment['payment']
                );
            }
            $data=array(
                "code"=>200,
                "message"=>"数据添加成功",
                "body"=>$list
            );
            return json($data);
        }
    }
    /**
     * 帮助记录
     */
    public function offerhelpnotes($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        //获取帮助记录
        $offerhelpinfo=Db::name("offer_accept_list")->where("offer_userid=$userid and offer_id != ''")->select();
        if(!$offerhelpinfo){
            return $this->error("2003","暂时没有帮助信息",array());
        }
        $res = [];
        foreach ($offerhelpinfo as $k => $v) {
            $res[$v['offer_id']][] = $v;
        }
        $data=array_values($res);
        foreach ($data as $key => $val) {
            $list[$key]['count']=count($val);
            foreach ($val as $k => $v) {
                //获取帮助信息
                $offerinfo=Db::name("offer_list")->where("id=".$v['offer_id'])->find();
            }
            $list[$key]['offer_money']=$offerinfo['offer_money'];
            $list[$key]['create_time']=$offerinfo['create_time'];
        }
        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
        return json($result);
    }
    /**
     * 帮助详情
     */
    public function offerhelpinfo($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        $offer_id=$param['offer_id'];
        if(!$offer_id){
            return $this->error("2003","请输入提供帮助信息的id",array());
        }
        //获取帮助记录
        $offernotes=Db::name('offer_accept_list')->where("offer_id=$offer_id")->select();
        foreach ($offernotes as $key => $val) {
            //提供帮助的信息
            $offerinfo=Db::name("offer_list")->where("id=".$offer_id)->find();
            //获取被帮助人的信息
            if($val['accept_id']!=0){
                $userinfo=Db::name("user")->where("id=".$val['accept_id'])->find();
                $data=array(
                    "offer_money"=>$offerinfo["offer_money"],
                    "phone"=>$userinfo["phone"],
                    "help_money"=>$val["help_money"],
                    "zfbname"=>$userinfo["zfbname"],
                    "pay_time"=>$val["pay_time"],
                );
            }else{
                $userinfo=Db::name("payment_admin")->where("is_play=1")->find();
                $data=array(
                    "offer_money"=>$offerinfo["offer_money"],
                    "phone"=>$userinfo["phone"],
                    "help_money"=>$val["help_money"],
                    "zfbname"=>$userinfo["payment"],
                    "pay_time"=>$val["pay_time"],
                );
            }
            $list[$key][]=$data;
        }
        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
        return json($result);
    }
}
