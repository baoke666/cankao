<?php
// +----------------------------------------------------------------------
// | Description: 用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\api\model;

use app\common\library\Token;
use com\easy\Random;
use think\Cache;
use think\Db;
use app\api\model\Common;
use com\verify\HonrayVerify;
use think\Session;
use think\Validate;

class User extends Common
{

    /**
     * 为了数据库的整洁，同时又不影响Model和Controller的名称
     * 我们约定每个模块的数据表都加上相同的前缀，比如微信模块用weixin作为数据表前缀
     */
	protected $name = 'admin_user';
    protected $createTime = 'create_time';
    protected $updateTime = false;
	protected $autoWriteTimestamp = true;
	protected $insert = [
		'status' => 1,
	];
	/**
	 * 获取用户所属所有用户组
	 * @param  array   $param  [description]
	 */
    public function groups()
    {
        return $this->belongsToMany('group', '__ADMIN_ACCESS__', 'group_id', 'user_id');
    }

    /**
     * [getDataList 列表]
     * @AuthorHTL
     * @DateTime  2017-02-10T22:19:57+0800
     * @param     [string]                   $keywords [关键字]
     * @param     [number]                   $page     [当前页数]
     * @param     [number]                   $limit    [t每页数量]
     * @return    [array]                             [description]
     */
	public function getDataList($keywords, $page, $limit)
	{
		$map = [];
		if ($keywords) {
			$map['username|realname'] = ['like', '%'.$keywords.'%'];
		}

		// 默认除去超级管理员
		$map['user.id'] = array('neq', 1);
		$dataCount = $this->alias('user')->where($map)->count('id');

		$list = $this
				->where($map)
				->alias('user')
				->join('__ADMIN_STRUCTURE__ structure', 'structure.id=user.structure_id', 'LEFT')
				->join('__ADMIN_POST__ post', 'post.id=user.post_id', 'LEFT');

		// 若有分页
		if ($page && $limit) {
			$list = $list->page($page, $limit);
		}

		$list = $list
				->field('user.*,structure.name as s_name, post.name as p_name')
				->select();

		$data['list'] = $list;
		$data['dataCount'] = $dataCount;

		return $data;
	}

	/**
	 * [getDataById 根据主键获取详情]
	 * @linchuangbin
	 * @DateTime  2017-02-10T21:16:34+0800
	 * @param     string                   $id [主键]
	 * @return    [array]
	 */
	public function getDataById($id = '')
	{
		$data = $this->get($id);
		if (!$data) {
			$this->error = '暂无此数据';
			return false;
		}
		$data['groups'] = $this->get($id)->groups;
		return $data;
	}
	/**
	 * 创建用户
	 * @param  array   $param  [description]
	 */
	public function createData($param)
	{
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}
		// 验证
		$validate = validate($this->name);
		if (!$validate->check($param)) {
			$this->error = $validate->getError();
			return false;
		}
		$this->startTrans();
		try {
			$param['password'] = user_md5($param['password']);
			$this->data($param)->allowField(true)->save();

			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $this->id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);
			$this->commit();
			return true;
		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '添加失败';
			return false;
		}
	}

	/**
	 * 通过id修改用户
	 * @param  array   $param  [description]
	 */
	public function updateDataById($param, $id)
	{
		// 不能操作超级管理员
		if ($id == 1) {
			$this->error = '非法操作';
			return false;
		}
		$checkData = $this->get($id);
		if (!$checkData) {
			$this->error = '暂无此数据';
			return false;
		}
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}
		$this->startTrans();

		try {
			Db::name('admin_access')->where('user_id', $id)->delete();
			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);

			if (!empty($param['password'])) {
				$param['password'] = user_md5($param['password']);
			}
			 $this->allowField(true)->save($param, ['id' => $id]);
			 $this->commit();
			 return true;

		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '编辑失败';
			return false;
		}
	}



	/**
	 * [login 登录]
	 * @AuthorHTL
	 * @DateTime  2017-02-10T22:37:49+0800
	 * @param     [string]                   $u_username [账号]
	 * @param     [string]                   $u_pwd      [密码]
	 * @param     [string]                   $verifyCode [验证码]
	 * @param     Boolean                  	 $isRemember [是否记住密码]
	 * @param     Boolean                    $type       [是否重复登录]
	 * @return    [type]                               [description]
	 */
	public function admin_login($username, $password, $verifyCode = '', $isRemember = false, $type = false)
	{
        if (!$username) {
			$this->error = '帐号不能为空';
			return false;
		}
		if (!$password){
			$this->error = '密码不能为空';
			return false;
		}
        if ( !$type) {
            if (!$verifyCode) {
				$this->error = '验证码不能为空';
				return false;
            }
            $captcha = new HonrayVerify(config('captcha'));
            if (!$captcha->check($verifyCode, '12345')) {
				$this->error = '验证码错误';
				return false;
            }
        }

		$map['username'] = $username;
		$userInfo = $this->where($map)->find();
    	if (!$userInfo) {
			$this->error = '帐号不存在';
			return false;
    	}
    	if (user_md5($password) !== $userInfo['password']) {
			$this->error = '密码错误'.user_md5($password);
			return false;
    	}
    	if ($userInfo['status'] === 0) {
			$this->error = '帐号已被禁用';
			return false;
    	}
        // 获取菜单和权限
        $dataList = $this->getMenuAndRule($userInfo['id']);

        if (!$dataList['menusList']) {
			$this->error = '没有权限';
			return false;
        }

        if ($isRemember || $type) {
        	$secret['username'] = $username;
        	$secret['password'] = $password;
            $data['rememberKey'] = encrypt($secret);
        }

        // 保存缓存
        session_start();
        $info['userInfo'] = $userInfo;
        $info['sessionId'] = session_id();
        $authKey = user_md5($userInfo['username'].$userInfo['password'].$info['sessionId']);
        $info['_AUTH_LIST_'] = $dataList['rulesList'];
        $info['authKey'] = $authKey;
        cache('Auth_'.$authKey, null);
        cache('Auth_'.$authKey, $info, config('LOGIN_SESSION_VALID'));
        // 返回信息
        $data['authKey']		= $authKey;
        $data['sessionId']		= $info['sessionId'];
        $data['userInfo']		= $userInfo;
        $data['authList']		= $dataList['rulesList'];
        $data['menusList']		= $dataList['menusList'];
        return $data;
    }

	/**
	 * 修改密码
	 * @param  array   $param  [description]
	 */
    public function setInfo($auth_key, $old_pwd, $new_pwd)
    {
        $cache = cache('Auth_'.$auth_key);
        if (!$cache) {
			$this->error = '请先进行登录';
			return false;
        }
        if (!$old_pwd) {
			$this->error = '请输入旧密码';
			return false;
        }
        if (!$new_pwd) {
            $this->error = '请输入新密码';
			return false;
        }
        if ($new_pwd == $old_pwd) {
            $this->error = '新旧密码不能一致';
			return false;
        }

        $userInfo = $cache['userInfo'];
        $password = $this->where('id', $userInfo['id'])->value('password');
        if (user_md5($old_pwd) != $password) {
            $this->error = '原密码错误';
			return false;
        }
        if (user_md5($new_pwd) == $password) {
            $this->error = '密码没改变';
			return false;
        }
        if ($this->where('id', $userInfo['id'])->setField('password', user_md5($new_pwd))) {
            $userInfo = $this->where('id', $userInfo['id'])->find();
            // 重新设置缓存
            session_start();
            $cache['userInfo'] = $userInfo;
            $cache['authKey'] = user_md5($userInfo['username'].$userInfo['password'].session_id());
            cache('Auth_'.$auth_key, null);
            cache('Auth_'.$cache['authKey'], $cache, config('LOGIN_SESSION_VALID'));
            return $cache['authKey'];//把auth_key传回给前端
        }

        $this->error = '修改失败';
		return false;
    }

	/**
	 * 获取菜单和权限
	 * @param  array   $param  [description]
	 */
    protected function getMenuAndRule($u_id)
    {
    	if ($u_id === 1) {
            $map['status'] = 1;
    		$menusList = Db::name('admin_menu')->where($map)->order('sort asc')->select();
    	} else {
    		$groups = $this->get($u_id)->groups;
            $ruleIds = [];
    		foreach($groups as $k => $v) {
    			$ruleIds = array_unique(array_merge($ruleIds, explode(',', $v['rules'])));
    		}

            $ruleMap['id'] = array('in', $ruleIds);
            $ruleMap['status'] = 1;
            // 重新设置ruleIds，除去部分已删除或禁用的权限。
            $rules =Db::name('admin_rule')->where($ruleMap)->select();
            foreach ($rules as $k => $v) {
            	$ruleIds[] = $v['id'];
            	$rules[$k]['name'] = strtolower($v['name']);
            }
            empty($ruleIds)&&$ruleIds = '';
    		$menuMap['status'] = 1;
            $menuMap['rule_id'] = array('in',$ruleIds);
            $menusList = Db::name('admin_menu')->where($menuMap)->order('sort asc')->select();
        }
        if (!$menusList) {
            return null;
        }
        //处理菜单成树状
        $tree = new \com\Tree();
        $ret['menusList'] = $tree->list_to_tree($menusList, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['menusList'] = memuLevelClear($ret['menusList']);
        // 处理规则成树状
        $ret['rulesList'] = $tree->list_to_tree($rules, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['rulesList'] = rulesDeal($ret['rulesList']);

        return $ret;
    }
    /**
     * 用户的注册
     */
    public function register($param=""){
    	$password=$param['password'];
    	$repassword=$param['repassword'];
    	$verifyCode=$param['verifyCode'];
        $verifyId=$param['verifyId'];
    	$invite_phone=$param['invite_phone'];
    	$phone=$param['phone'];
    	$phone_code=$param['phone_code'];
    	if (!$phone) {
            return $this->error("2001",'手机号不能为空',array());
		}else{
            if(!$this->checkphone($phone)){
				return $this->error("2003",'手机号格式不正确',array());
			}else{
				//查询是否已经存在
				$nameinfo = Db::name('user')->where("phone=$phone")->find();
				if($nameinfo){
					$info=array(
						"id"=>$nameinfo['id'],
						"phone"=>$nameinfo['phone'],
						"username"=>$nameinfo['username'],
					);

                    return $this->error("2005",'用户已存在',$info);
				}
			}
		}
		if (!$invite_phone) {
			return $this->error("2002","邀请人手机号不能为空",array());
		}else{
			if(!$this->checkphone($invite_phone)){
				return $this->error("2004","邀请人手机号格式不正确",array());
			}else{
				//查询是否存在推荐人
				$invite = Db::name('user')->where("phone=$invite_phone")->find();
				if(!$invite){
					return $this->error("2006","推荐人不存在",array());
				}
			}
		}
		if($phone==$invite_phone){
			return $this->error("2008","推荐人不能是自己",array());
		}
        if (!$verifyCode) {
            return $this->error("2007","验证码不能为空",array());
        }
    	//验证图片
    	$captcha = new HonrayVerify();
         if (!$captcha->check($verifyCode, $verifyId)) {
             return $this->error('2012', '验证码错误', array());
         }
        if (!$password){
			return $this->error("2009","密码不能为空",array());
		}
		if(!Validate::min($password,6) || !Validate::max($password,16)){
			return $this->error("2011","请输入6-16位长度的密码",array());
		}

        $code = \cache($phone);
		if (empty($code) || $phone_code != $code){
            return $this->error("2013","手机验证码不正确",array());
        }
		//获取推荐码
		$invite_code=$captcha->getinvitecode();
		$data=array(
			"inviter_id"=>$invite['id'],
			"invite_code"=>$invite_code,
			"phone"=>$phone,
			"username"=>'u'.$phone,
			"password"=>user_md5($password),
			"create_time"=>time(),
			"status"=>1
		);
		//添加数据库
		$result=Db::name('user')->insert($data);
		if(!$result){
			return $this->error("2013","添加失败",array());
		}

		\cache($phone, null);
		//获取新注册用户信息
		$userinfo=Db::name("user")->where("phone=$phone")->find();
		$result=array(
		    "code" => 200,
			"id"=>$userinfo['id'],
			"username"=>$userinfo['username'],
			"phone"=>$userinfo['phone'],
			"head"=>$userinfo['head'],
		);
		return json($result);
    }
    /**
     * 验证手机号
     */
    protected function checkphone($phone){
    	$rule = '/^0?(13|14|15|17|18|19)[0-9]{9}$/';
        $result = preg_match($rule, $phone);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * 登录
     */
    public function login($param=""){
    	$phone=$param['phone'];
    	$password=user_md5($param['password']);
    	if(!$this->checkphone($phone)){
    		return $this->error("2001","手机号格式错误",array());
    	}else{
    		$userinfo=Db::name("user")->where("phone=$phone")->find();
    		if(!$userinfo){
    			return $this->error("2003","当前用户不存在",array());
    		}
    	}
    	if($userinfo["password"]!=$password){
    		return $this->error("2004","密码不正确",array());
    	}
    	$data=array(
    		"id"=>$userinfo["id"],
    		"username"=>$userinfo["username"],
    		"phone"=>$userinfo["phone"],
    		"head"=>$userinfo["head"],
    	);

    	$result=array(
    		"code"=>200,
    		"message"=>"登陆成功",
    		"authKey"=> Token::create($userinfo["id"])['token'],
    		"body"=>$data
    	);
    	return json($result);
    }

    public function checkPhoneCode($data) {
        $phone = $data['phone'];
        $code = $data['code'];
        if (empty($phone) || empty($code)){
            return $this->error("2001",  "参数错误");
        }

        $_code = \cache($phone);

        if (empty($_code) || $_code != $code) {
            return $this->error("2002",  "手机验证码错误");
        }

        \cache($phone, null);

        return array(
            'code' => 200,
            'tmp_auth' => Token::create($phone)['token']
        );
    }
    /**
     * 发送验证码
     */
    public function sendphonecode($phone=""){
    	//验证手机号
    	if(!$this->checkphone($phone)){
    		return $this->error("2001","手机号格式错误",array("phone"=>$phone));
    	}
//    	else{
//    		$userinfo=Db::name("user")->where("phone=$phone")->find();
//    		if(!$userinfo){
//    			return $this->error("2003","当前用户不存在",array());
//    		}
//    	}
    	$code=rand(111111,999999);
    	header('content-type:text/html;charset=utf-8');
		$sendUrl="http://v.juhe.cn/sms/send";
		$smsConf=array(
		"key"=>"a89fffd08391cfdde0a358219b2958eb",
		"mobile"=>$phone,
		"tpl_id"=>"144038",
		"tpl_value"=>"#code#=$code"
		);
		$content=$this->juhecurl($sendUrl,$smsConf,1);
		if($content){
		$result=json_decode($content,true);
		$error_code=$result['error_code'];
		if($error_code==0){
		//状态为0，说明短信发送成功	
//			Session::set('phone_code',$code);
			// echo Session::get('phone_code');
            \cache($phone, $code, 600);
			$result=array(
				"code"=>200,
				"message"=>"短信发送成功,短信ID：".$result['result']['sid']
			);
			return json($result);
		}else{
			//状态非0，说明失败
			$msg=$result['reason'];
			$message="短信发送失败(".$error_code.")：".$msg;
			return $this->error("2005",$message,array());
		}
		}else{
			//返回内容异常，以下可根据业务逻辑自行修改
			return $this->error("2007","请求发送短信失败",array());
		}
    }
    /**
     * [juhecurl description]发送短息
     * @param  [type]  $url    [description]
     * @param  boolean $params [description]
     * @param  integer $ispost [description]
     * @return [type]          [description]
     */
    function juhecurl($url,$params=false,$ispost=0){
	$httpInfo=array();
	$ch=curl_init();
	curl_setopt($ch,CURLOPT_HTTP_VERSION,CURL_HTTP_VERSION_1_1);
	curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0(WindowsNT5.1)AppleWebKit/537.22(KHTML,likeGecko)Chrome/25.0.1364.172Safari/537.22');
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,30);
	curl_setopt($ch,CURLOPT_TIMEOUT,30);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	if($ispost){
			curl_setopt($ch,CURLOPT_POST,true);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$params);
			curl_setopt($ch,CURLOPT_URL,$url);
	}else{
	if($params){
	    ifcurl_setopt($ch,CURLOPT_URL,$url.'?'.$params);
	}else{
	    curl_setopt($ch,CURLOPT_URL,$url);
	}
	}
	$response=curl_exec($ch);
	if($response===FALSE){
	//echo"cURLError:".curl_error($ch);
	returnfalse;
	}
	$httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
	$httpInfo=array_merge($httpInfo,curl_getinfo($ch));
	curl_close($ch);
	return $response;
	}
	/**
	 * 修改密码
	 */
	public function changepassword($param=""){
		$phone=$param['phone'];
        $tmp_auth = $param['tmp_auth'];
		$password=$param['password'];
		$repassword=$param['repassword'];
		if (empty($phone) || empty($tmp_auth)){
		    return $this->error("2002",'参数错误');
        }
        if (!Token::check($tmp_auth))
            return $this->error("2002",'非法访问');

        if(!Validate::min($password,6) || !Validate::max($password,16) || !Validate::min($repassword,6) || !Validate::max($repassword,16)){
			return $this->error("2005",'请输入6-16位长度的密码',array());
		}
		if($password!=$repassword){
			return $this->error("2003",'输入的密码不正确',array());
		}
		$password=user_md5($password);
		$old_password=Db::name("user")->where("phone=$phone")->value("password");
		if($password==$old_password){
			return $this->error("2004",'输入的密码与原密码相同',array());
		}
		$data=array(
			"password"=>$password
		);
		$result=Db::name('user')->where("phone=$phone")->update($data);
		if(!$result){
			return $this->error("2001",'修改失败',array());
		}else{
			$result=array(
				"code"=>200,
				"message"=>"修改成功",
				"body"=>array()
			);
			Token::delete($tmp_auth);
			return json($result);
		}
	}
	/**
	 * 错误返回
	 */
	protected function error($errorcode,$message,$data=[]){
		$result=array(
			"code"=>$errorcode,
			"message"=>$message,
			"body"=>$data,
		);
		return json($result);
	}
	/**
	 * 设置收款方式
	 */
	public function setpayway($param=""){
		if(empty($param)){
			return $this->error("2001","请输入账号或真实姓名",array());
		}
		$userid=$param['userid'];
		$zfbname=$param['zfbname'];
		$realname=$param['realname'];
		//获取用户信息
		$userinfo=Db::name("User")->where("id=$userid")->find();
		if(!$userinfo){
			return $this->error("2003","用户不存在",array());
		}
		//查询支付宝账号绑定数
		$count=Db::name("User")->where(['zfbname'=>$zfbname])->count();
		if($count>2){
			return $this->error("2005","本账号已经绑定超过三个账号",array());
		}
		//添加realname 支付宝账号
		$result=Db::name("User")->where("id=$userid")->update(array("zfbname"=>$zfbname,"realname"=>$realname));
		if(!$result){
			return $this->error("2007","添加失败",array());
		}else{
			$result=array(
				"code"=>200,
				"message"=>"修改成功",
				"body"=>array(
						"userid"=>$userid
					)
			);
			return json($result);
		}
	}
	/**
	 * setpaytrader设置交易密码
	 */
	public function setpaytrader($param=""){

		$userid=$param['userid'];
		$trader=$param['trader'];
		$retrader=$param['retrader'];

		if (empty($trader) || empty($retrader)){
            return $this->error("2001","参数错误");
        }
		//获取用户信息
		$userinfo=Db::name("User")->where("id=$userid")->find();
		if(!$userinfo){
			return $this->error("2003","用户不存在",array());
		}

		if (!empty($userinfo['trader'])) {
            return $this->error("2002","交易密码无法设置",array());
        }
		//判断密码
		if($trader!=$retrader){
			return $this->error("2005","两次输入密码不相同",array());
		}

		$trader=user_md5($trader);

		//添加交易密码
		$result=Db::name("User")->where("id=$userid")->update(array("trader"=>$trader));
		if(!$result){
			return $this->error("2007","新旧密码相同",array());
		}else{
			$result=array(
				"code"=>200,
				"message"=>"设置成功",
				"body"=>array(
						"userid"=>$userid
					)
			);
			return json($result);
		}
	}

    /**
     * setpaytrader修改交易密码
     */
    public function modifyTrader($param){

        $userid=$param['userid'];
        $old = $param['old'];
        $trader=$param['trader'];
        $retrader=$param['retrader'];

        if (empty($old) || empty($trader) || empty($retrader)){
            return $this->error("2001","参数错误");
        }
        //获取用户信息
        $userinfo=Db::name("User")->where("id=$userid")->find();
        if(!$userinfo){
            return $this->error("2003","用户不存在",array());
        }
        //判断密码
        if($trader!=$retrader){
            return $this->error("2005","两次输入密码不相同",array());
        }

        if (user_md5($old) != $userinfo['trader']) {
            return $this->error("2006","旧交易密码不正确");
        }

        $trader=user_md5($trader);

        //添加交易密码
        $result=Db::name("User")->where("id=$userid")->update(array("trader"=>$trader));
        if(!$result){
            return $this->error("2007","新旧密码相同",array());
        }else{
            $result=array(
                "code"=>200,
                "message"=>"设置成功",
                "body"=>array(
                    "userid"=>$userid
                )
            );
            return json($result);
        }
    }
	/**
	 * 修改登录密码
	 */
	public function changeloginpassword($param=""){

		$userid=$param['userid'];
		$oldpassword=$param['oldpassword'];
		$newpassword=$param['newpassword'];
		$renewpassword=$param['renewpassword'];

		if (empty($userid) || empty($oldpassword) || empty($newpassword) || empty($renewpassword)) {
            return $this->error("2001","参数错误",array());
        }
		//获取用户信息
		$userinfo=Db::name("User")->where("id=$userid")->find();
		if(!$userinfo){
			return $this->error("2003","用户不存在",array());
		}
		if($oldpassword==$newpassword){
			return $this->error("2009","新旧密码相同",array());
		}
		$oldpassword=user_md5($oldpassword);
		if($oldpassword!=$userinfo['password']){
			return $this->error("2005","原密码不正确",array());
		}
		if($newpassword!=$renewpassword){
			return $this->error("2007","新密码不一致",array());
		}
		//修改密码
		$data=array(
			"password"=>user_md5($newpassword)
		);
		$result=Db::name("user")->where("id=$userid")->update($data);
		if(!$result){
			return $this->error("2011","修改失败",array());
		}else{
			$result=array(
				"code"=>200,
				"message"=>"设置成功",
				"body"=>array(
						"userid"=>$userid
					)
			);
			return json($result);
		}
	}

	/**
     * 获取用户信息
     */
	public function getUserInfo($param){

        $res = Db::name('user')
            ->alias('a')
            ->join('t_user b', 'a.inviter_id=b.id')
            ->where('a.id', $param['userid'])
            ->field('a.realname,a.phone,b.realname as ivt_realname,b.phone as ivt_phone,a.activation,a.status,a.trader,a.zfbname,a.status')
            ->find();

        if (empty($res))
            return $this->error('2001', '用户信息错误');

        if (empty($res['realname']) || empty($res['zfbname']))
            $res['payment'] = 'no';
        else
            $res['payment'] = 'yes';

        if (empty($res['trader']))
            $res['trader_status'] = 'no';
        else
            $res['trader_status'] = 'yes';

        $res['code'] = 200;
        return $res;
    }
}
