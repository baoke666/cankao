<?php 
namespace app\api\model;

use think\Model;
use think\Db;

class User extends Model{
	public function getuserinfo($username="",$password=""){
		if(empty($username)){
			return "用户名不能为空";
		}
		if(empty($password)){
			return "密码不能为空";
		}
		$data=array(
			"username"=>$username,
			"password"=>$password,
		);
		//查询用户信息
		$userinfo=Db::name('user')->where($data)->find();
		return $userinfo;
	}
}