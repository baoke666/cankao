<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/4 0004
 * Time: 下午 10:59
 */

namespace app\api\controller;

use think\Db;
use app\common\library\Token;
use com\verify\HonrayVerify;
use app\common\controller\Common;
use think\Config;
use think\Request;

class Index extends ApiCommon
{
    /**
     * 获取新的token
     */
    public function refreshToken(){
        $old = $this->param['token'];
        if (empty($old))
            return resultArray(['error' => "用户未登录"]);
        if (!Token::check($old))
            return resultArray(['error' => "用户登录已失效"]);
        return resultArray(['data' => Token::refresh($old)]);
    }

    /**
     * 获取菜单导航和菜单权限，树形结构
     */
    public function getMenuTreeList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId(), "tree")]);
    }

    /**
     * 获取菜单导航和菜单权限，列表结构
     */
    public function getMenuList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId())]);
    }

    /**修改管理员密码
     * @return array
     */
    public function setInfo()
    {
        $adminModel = model('Admin');
        $param = $this->param;
        $old_pwd = $param['oldPaw'];
        $new_pwd = $param['newPaw'];

        $data = $adminModel->setInfo($this->getUserId(), $old_pwd, $new_pwd);
        if (!$data) {
            return resultArray(['error' => $adminModel->getError()]);
        }
        return resultArray(['data' => $data]);
    }

    /**获取滚动消息
     * @return array
     */
    public function getRollingNotice()
    {
        $data = array();
        $newC = Db::name('user_certificate')
            ->where(['status' => 'pend'])
            ->count();
        if ($newC) {
            array_push($data, ['type' => 'certificate', 'content' => '有新的实名认证申请']);
        }
        $newF = Db::name('feedback')
            ->where('type', '=', '1')
            ->where('status', '=', '0')
            ->count();
        if ($newF) {
            array_push($data, ['type' => 'feedback', 'content' => '有新的用户工单']);
        }
        return resultArray(['data' => $data]);
    }
    /**
     * 转让排单币
     */
    public function attompaicoin(){
        $user = model("Admin");
        return $user->attompaicoin(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 转让激活码
     */
    public function attomactivationcode(){
        $user = model("Admin");
        return $user->attomactivationcode(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 激活用户
     */
    public function activationuser(){
        $user = model("Admin");
        return $user->activationuser(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 用户今日抽奖数量
     */
    public function lotteryCount(){
        $user = model("Admin");
        return $user->lotteryCount(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 点击抽奖
     */
    public function lotterydraw(){
        $user = model("Admin");
        return $user->lotterydraw(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 抽奖列表
     */
    public function drawlist(){
        $user = model("Admin");
        return $user->drawlist(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 我的钱包
     */
    public function mywallet(){
        $user = model("Admin");
        return $user->mywallet(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 我的团队
     */
    public function myteam(){
        $user = model("Admin");
        return $user->myteam(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 我的团队
     */
    public function teamCount(){
        $user = model("Admin");
        return $user->teamCount(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 激活账号
     */
    public function allmyteam(){
        $user = model("Admin");
        return $user->allmyteam(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 问题留言
     */
    public function askquestion(){
        $user = model("Admin");
        return $user->askquestion(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 提供帮助
     * @return [type] [description]
     */
    public function offer(){
        $user = model("Admin");
        return $user->offer(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 接受帮助
     * @return [type] [description]
     */
    public function accept(){
        $user = model("Admin");
        return $user->accept(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 交易匹配
     * @return [type] [description]
     */
    public function trade(){
        $user = model("Admin");
        return $user->trade(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    /**
     * 帮助记录
     * @return [type] [description]
     */
    public function offerhelpnotes(){
        $user = model("Admin");
        return $user->offerhelpnotes(array_merge($this->param, ['userid' => $this->getUserId()]));
    }
    //帮助详情
    public function offerhelpinfo(){
        $user = model("Admin");
        return $user->offerhelpinfo(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    //帮助详情
    public function acceptHelpInfo()
    {
        $user = model("Admin");
        return $user->acceptHelpInfo(array_merge($this->param, ['userid' => $this->getUserId()]));
    }

    /**
     * 上传支付凭证
     */
    public function uploadeimg(){
        $user = model("Admin");
        $data = $user->uploadeimg(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 上传支付凭证
     */
    public function sysUpLoadeImg(){
        $user = model("Admin");
        $data = $user->sysUpLoadeImg(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 待帮助确认收款
     */
    public function accept_gather(){
        $user = model("Admin");
        $data = $user->accept_gather(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 待帮助确认收款
     */
    public function sys_accept_gather(){
        $user = model("Admin");
        $data = $user->sys_accept_gather(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 后台确认匹配成立
     */
    public function confirm_notes(){
        $user = model("Admin");
        $data = $user->confirm_notes(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 判断当前是否存在正在排单
     */
    public function offer_state(){
        $user = model("Admin");
        $data = $user->offer_state(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 我的帮助
     */
    public function myhelplist(){
        $user = model("Admin");
        $data = $user->myhelplist(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 我的接受帮助
     */
    public function myacceptlist(){
        $user = model("Admin");
        $data = $user->myacceptlist(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 获取用户的一代，三代父级userID
     * @return [type] [description]
     */
    public function getfatheruser(){
        $user = model("Admin");
        $data = $user->getfatheruser(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 静态钱包
     */
    public function jing_wallet(){
        $user = model("Admin");
        $data = $user->jing_wallet(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 生成二维码
     */
    public function create_qrcode(){
        $user = model("Admin");
        $data = $user->create_qrcode(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 动态钱包
     */
    public function dong_wallet(){
        $user = model("Admin");
        $data = $user->dong_wallet(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道
     */
    public function green_channel(){
        $user = model("Admin");
        $data = $user->green_channel(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 接受帮助状态判断
     */
    public function accept_state(){
        $user = model("Admin");
        $data = $user->accept_state(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 拒绝收款
     */
    public function refuse_accept(){
        $user = model("Admin");
        $data = $user->refuse_accept(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 超时收款
     */
    public function overtime_accept(){
        $user = model("Admin");
        $data = $user->overtime_accept(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道状态
     */
    public function green_channel_state(){
        $user = model("Admin");
        $data = $user->green_channel_state(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道状态
     */
    public function green_channel_list(){
        $user = model("Admin");
        $data = $user->green_channel_list(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 提现
     */
    public function green_channel_cash(){
        $user = model("Admin");
        $data = $user->green_channel_cash(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 确认收款
     */
    public function green_channel_gather(){
        $user = model("Admin");
        $data = $user->green_channel_gather(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 提现记录
     */
    public function green_channel_accept(){
        $user = model("Admin");
        $data = $user->green_channel_accept(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 帮助详情
     */
    public function green_channel_offer(){
        $user = model("Admin");
        $data = $user->green_channel_offer(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 接受详情
     */
    public function green_channel_accepthelp(){
        $user = model("Admin");
        $data = $user->green_channel_accepthelp(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 绿色通道 帮助记录
     */
    public function green_channel_helplist(){
        $user = model("Admin");
        $data = $user->green_channel_helplist(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 静态收益账单
     */
    public function jing_wallet_list(){
        $user = model("Admin");
        $data = $user->jing_wallet_list(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 匹配结果列表
     */
    public function getallnotes(){
        $user = model("Admin");
        $data = $user->getallnotes(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 进场出场人数
     */
    public function getallnums(){
        $user = model("Admin");
        $data = $user->getallnums(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 后台确认订单
     */
    public function confirm_status(){
        $user = model("Admin");
        $data = $user->confirm_status(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 修改提供帮助时间
     */
    public function change_offer_time(){
        $user = model("Admin");
        $data = $user->change_offer_time(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 修改接受帮助时间
     */
    public function change_accept_time(){
        $user = model("Admin");
        $data = $user->change_accept_time(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }
    /**
     * 修改绿色通道时间
     */
    public function change_green_time(){
        $user = model("Admin");
        $data = $user->change_green_time(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }

    public function getSystemNum(){
        $user = model("Admin");
        $data = $user->getSystemNum(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }

    public function updateSystemNum(){
        $user = model("Admin");
        $data = $user->updateSystemNum(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
    }

    public function offerList(){
        $param = $this->param;
        $phone = $param['phone'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? $this->pageSize : $param['limit'];

        $where = [];
        if (!empty($phone))
            $where['b.phone'] = $phone;
        $where['a.status'] = 0;

        $count = Db::name('offer')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->where($where)
            ->count();

        $offerList = Db::name('offer')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->field('a.id, a.offer_money, a.auto, a.status, a.pay_status, a.help_money,a.create_time, b.phone, b.realname')
            ->where($where)
            ->order('a.create_time asc')
            ->page($page, $limit)
            ->select();

        return resultArray(['data' => ['list' => $offerList, 'count' => $count]]);
    }

    public function greenList(){
        $param = $this->param;
        $phone = $param['phone'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? $this->pageSize : $param['limit'];

        $where = [];
        if (!empty($phone))
            $where['b.phone'] = $phone;
        $where['a.is_finish'] = ['<', '2'];

        $count = Db::name('green_channel')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->where($where)
            ->order('a.id desc')
            ->count();

        $greenList = Db::name('green_channel')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->field('a.id, a.offer_money, a.is_finish, a.help_money,a.create_time, b.phone, b.realname')
            ->where($where)
            ->order('a.id desc')
            ->page($page, $limit)
            ->select();

        return resultArray(['data' => ['list' => $greenList, 'count' => $count]]);
    }

    public function acceptList(){
        $param = $this->param;
        $phone = $param['phone'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? $this->pageSize : $param['limit'];

        $where = [];
        if (!empty($phone))
            $where['b.phone'] = $phone;
        $where['a.is_finish'] = 0;

        $count = Db::name('accept_list')
            ->alias('a')
            ->join('t_user b', 'a.userid = b.id')
            ->where($where)
            ->order('a.id desc')
            ->count();

        $greenList = Db::name('accept_list')
            ->alias('a')
            ->join('t_user b', 'a.userid = b.id')
            ->field('a.id, a.money, a.have_accept_money,a.type,a.create_time, b.phone, b.realname')
            ->where($where)
            ->order('a.id desc')
            ->page($page, $limit)
            ->select();

        return resultArray(['data' => ['list' => $greenList, 'count' => $count]]);
    }


}