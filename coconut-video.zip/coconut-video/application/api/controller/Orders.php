<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/4 0004
 * Time: 下午 10:59
 */

namespace app\api\controller;

use think\Db;
use app\common\library\Token;
use com\verify\HonrayVerify;
use app\common\controller\Common;
use think\Config;
use think\Request;

class Orders extends ApiCommon
{
	public function index(){
		$user = model("Order");
        $data = $user->index(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}
	/**
	 * 添加模板
	 * @return [type] [description]
	 */
	public function add_template(){
		$user = model("Order");
        $data = $user->add_template(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 添加模板>>搜索部件
	 */
	public function search_parts(){
		$user = model("Order");
        $data = $user->search_parts(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 添加订单
	 */
	public function add_orders(){
		$user = model("Order");
        $data = $user->add_orders(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 模板搜索
	 */
	public function search_template(){
		$user = model("Order");
        $data = $user->search_template(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 添加原材料库存
	 */
	public function add_material(){
		$user = model("Order");
        $data = $user->add_material(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 原材料入库出库
	 */
	public function material_stock(){
		$user = model("Order");
        $data = $user->material_stock(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 原材料删除
	 */
	public function del_material(){
		$user = model("Order");
        $data = $user->del_material(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 模板列表
	 */
	public function template_list(){
		$user = model("Order");
        $data = $user->template_list(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 模板删除
	 */
	public function del_template(){
		$user = model("Order");
        $data = $user->del_template(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 订单列表
	 */
	public function order_list(){
		$user = model("Order");
        $data = $user->order_list(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}
	
	/**
	 * 总订单删除
	 */
	public function del_order(){
		$user = model("Order");
        $data = $user->del_order(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 发货
	 */
	public function delivery(){
		$user = model("Order");
        $data = $user->delivery(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 显示订单信息（单个订单）
	 */
	public function show_order(){
		$user = model("Order");
        $data = $user->show_order(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 订单编辑
	 */
	public function change_order(){
		$user = model("Order");
        $data = $user->change_order(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 置顶
	 */
	public function operate_top(){
		$user = model("Order");
        $data = $user->operate_top(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 总排产计划
	 */
	public function schedule_order(){
		$user = model("Order");
        $data = $user->schedule_order(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 排产
	 */
	public function schedule(){
		$user = model("Order");
        $data = $user->schedule(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 车间排产计划
	 */
	public function workshop_order(){
		$user = model("Order");
        $data = $user->workshop_order(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 产品入库出库
	 */
	public function product_stock(){
		$user = model("Order");
        $data = $user->product_stock(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 获取配件信息（单个订单）
	 */
	public function getoneorderparts(){
		$user = model("Order");
        $data = $user->getoneorderparts(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 模板信息获取（单个）
	 */
	public function getOneTemplate(){
		$user = model("Order");
        $data = $user->getOneTemplate(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 编辑模板
	 */
	public function changeTemplate(){
		$user = model("Order");
        $data = $user->changeTemplate(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 车间排产计划
	 */
	public function getWorkshopOneOrder(){
		$user = model("Order");
        $data = $user->getWorkshopOneOrder(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 获取所有的原材料库存
	 */
	public function getAllMaterial(){
		$user = model("Order");
        $data = $user->getAllMaterial(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 获取所有的产品库存
	 */
	public function getAllProduct(){
		$user = model("Order");
        $data = $user->getAllProduct(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 添加产品库存
	 */
	public function addProductStock(){
		$user = model("Order");
        $data = $user->addProductStock(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 申请入库
	 */
	public function aplyStock(){
		$user = model("Order");
        $data = $user->aplyStock(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 入库审核列表
	 */
	public function getWorkshopAply(){
		$user = model("Order");
        $data = $user->getWorkshopAply(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 审核入库申请
	 */
	public function reviewAply(){
		$user = model("Order");
        $data = $user->reviewAply(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}

	/**
	 * 发货
	 */
	public function sendEditNumm(){
		$user = model("Order");
        $data = $user->sendEditNumm(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}
	

	/**
	 * 经纬度
	 */
	public function getlnglat(){
		$user = model("Order");
        $data = $user->getlnglat(array_merge($this->param, ['userid' => $this->getUserId()]));
        return json($data);
	}
}