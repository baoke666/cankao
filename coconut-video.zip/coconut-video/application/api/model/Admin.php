<?php
// +----------------------------------------------------------------------
// | Description: 用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\api\model;

use app\common\library\Token;
use think\Cache;
use think\Config;
use think\Db;
use app\api\model\Common;
use com\verify\HonrayVerify;
use think\Request;
use think\Controller;

class Admin extends Common
{

    private $sysAccount = [3, 4, 5];

    /**
     * 错误返回
     */
    public function error($errorcode,$message,$data=[]){
        $result=array(
            "code"=>$errorcode,
            "message"=>$message,
            "body"=>$data,
        );
        return $result;
    }

    /**
     * 为了数据库的整洁，同时又不影响Model和Controller的名称
     * 我们约定每个模块的数据表都加上相同的前缀，比如微信模块用weixin作为数据表前缀
     */
    protected $createtime = 'createtime';
    protected $updateTime = 'updatetime';
	protected $autoWriteTimestamp = true;
	protected $insert = [
		'status' => 1,
	];
	/**
	 * 获取用户所属所有用户组
	 * @param  array   $param  [description]
	 */
    public function groups()
    {
        return $this->belongsToMany('group', '__ADMIN_ACCESS__', 'group_id', 'user_id');
    }

    /**
     * [getDataList 列表]
     * @AuthorHTL
     * @DateTime  2017-02-10T22:19:57+0800
     * @param     [string]                   $keywords [关键字]
     * @param     [number]                   $page     [当前页数]
     * @param     [number]                   $limit    [t每页数量]
     * @return    [array]                             [description]
     */
	public function getDataList($keywords, $page, $limit)
	{
		$map = [];
		if ($keywords) {
			$map['username|realname'] = ['like', '%'.$keywords.'%'];
		}

		// 默认除去超级管理员
		$map['user.id'] = array('neq', 1);
		$dataCount = $this->alias('user')->where($map)->count('id');

		$list = $this
				->where($map)
				->alias('user')
				->join('__ADMIN_STRUCTURE__ structure', 'structure.id=user.structure_id', 'LEFT')
				->join('__ADMIN_POST__ post', 'post.id=user.post_id', 'LEFT');

		// 若有分页
		if ($page && $limit) {
			$list = $list->page($page, $limit);
		}

		$list = $list
				->field('user.*,structure.name as s_name, post.name as p_name')
				->select();

		$data['list'] = $list;
		$data['dataCount'] = $dataCount;

		return $data;
	}

	/**
	 * [getDataById 根据主键获取详情]
	 * @linchuangbin
	 * @DateTime  2017-02-10T21:16:34+0800
	 * @param     string                   $id [主键]
	 * @return    [array]
	 */
	public function getDataById($id = '')
	{
		$data = $this->get($id);
		if (!$data) {
			$this->error = '暂无此数据';
			return false;
		}
		$data['groups'] = $this->get($id)->groups;
		return $data;
	}
	/**
	 * 创建用户
	 * @param  array   $param  [description]
	 */
	public function createData($param)
	{
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}

		// 验证
		$validate = validate($this->name);
		if (!$validate->check($param)) {
			$this->error = $validate->getError();
			return false;
		}

		$this->startTrans();
		try {
			$param['password'] = user_md5($param['password']);
			$this->data($param)->allowField(true)->save();

			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $this->id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);

			$this->commit();
			return true;
		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '添加失败';
			return false;
		}
	}

	/**
	 * 通过id修改用户
	 * @param  array   $param  [description]
	 */
	public function updateDataById($param, $id)
	{
		// 不能操作超级管理员
		if ($id == 1) {
			$this->error = '非法操作';
			return false;
		}
		$checkData = $this->get($id);
		if (!$checkData) {
			$this->error = '暂无此数据';
			return false;
		}
		if (empty($param['groups'])) {
			$this->error = '请至少勾选一个用户组';
			return false;
		}
		$this->startTrans();

		try {
			Db::name('admin_access')->where('user_id', $id)->delete();
			foreach ($param['groups'] as $k => $v) {
				$userGroup['user_id'] = $id;
				$userGroup['group_id'] = $v;
				$userGroups[] = $userGroup;
			}
			Db::name('admin_access')->insertAll($userGroups);

			if (!empty($param['password'])) {
				$param['password'] = user_md5($param['password']);
			}
			 $this->allowField(true)->save($param, ['id' => $id]);
			 $this->commit();
			 return true;

		} catch(\Exception $e) {
			$this->rollback();
			$this->error = '编辑失败';
			return false;
		}
	}


    /**
     * @param $username
     * @param $password
     * @param string $verifyCode
     * @param string $codeId 验证码编号
     * @param bool $isRemember
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
	public function login($username, $password, $verifyCode, $codeId, $isRemember = false)
	{
        if (!$username) {
			$this->error = '帐号不能为空';
			return false;
		}
		if (!$password){
			$this->error = '密码不能为空';
			return false;
		}
        if (!$verifyCode) {
            $this->error = '验证码不能为空';
            //return false;
        }
        $captcha = new HonrayVerify(config('captcha'));
        if (!$captcha->check($verifyCode, $codeId)) {
            $this->error = '验证码错误';
            //return false;
        }

		$map['username'] = $username;
		$userInfo = $this->where($map)->find();
    	if (!$userInfo) {
			$this->error = '帐号不存在';
			return false;
    	}
//    	if ($userInfo['loginfailure'] >= 3){
//            $this->error = '密码错误已经达到3次，账户将被锁定2个小时';
//            return false;
//        }
    	if (user_md5($password.$userInfo['salt']) !== $userInfo['password']) {
            $userInfo['loginfailure'] = $userInfo['loginfailure'] + 1;
            $userInfo['logintime'] = time();
            $userInfo->save();
			$this->error = '密码错误';
			return false;
    	}
    	if ($userInfo['status'] === 'closed') {
			$this->error = '帐号已被禁用';
			return false;
    	}
//        // 获取菜单和权限
//        $dataList = $this->getMenuAndRule($userInfo['id']);
//
//        if (!$dataList['menusList']) {
//			$this->error = '没有权限';
//			return false;
//        }

        if ($isRemember) {
        	$secret['username'] = $username;
        	$secret['password'] = $password;
            $data['rememberKey'] = encrypt($secret);
        }

//        // 保存缓存
//        session_start();
//        $info['userInfo'] = $userInfo;
//        $info['sessionId'] = session_id();
//        $authKey = user_md5($userInfo['username'].$userInfo['password'].$info['sessionId']);
//        $info['_AUTH_LIST_'] = $dataList['rulesList'];
//        $info['authKey'] = $authKey;
//        cache('Auth_'.$authKey, null);
//        cache('Auth_'.$authKey, $info, config('LOGIN_SESSION_VALID'));
//        // 返回信息
//        $data['authKey']		= $authKey;
//        $data['sessionId']		= $info['sessionId'];
//        $data['userInfo']		= $userInfo;
//        $data['authList']		= $dataList['rulesList'];
//        $data['menusList']		= $dataList['menusList'];
        return Token::create($userInfo['id']);

    }

	/**
	 * 修改密码
	 * @param  array   $param  [description]
	 */
    public function setInfo($id, $old_pwd, $new_pwd)
    {
        if (!$old_pwd) {
			$this->error = '请输入旧密码';
			return false;
        }
        if (!$new_pwd) {
            $this->error = '请输入新密码';
			return false;
        }
        if ($new_pwd == $old_pwd) {
            $this->error = '新旧密码不能一致';
			return false;
        }

        $userInfo = $this->where('id', $id)->find();
        if (user_md5($old_pwd.$userInfo['salt']) != $userInfo['password']) {
            $this->error = '原密码错误';
			return false;
        }
        if (user_md5($new_pwd) == $userInfo['password']) {
            $this->error = '密码没改变';
			return false;
        }
        if ($this->where('id', $id)->setField('password', user_md5($new_pwd.$userInfo['salt']))) {
            return true;
        }
        $this->error = '修改失败';
		return false;
    }

	/**
	 * 获取菜单和权限
	 * @param  array   $param  [description]
	 */
    protected function getMenuAndRule($u_id)
    {
    	if ($u_id === 1) {
            $map['status'] = 1;
    		$menusList = Db::name('admin_menu')->where($map)->order('sort asc')->select();
    	} else {
    		$groups = $this->get($u_id)->groups;
            $ruleIds = [];
    		foreach($groups as $k => $v) {
    			$ruleIds = array_unique(array_merge($ruleIds, explode(',', $v['rules'])));
    		}

            $ruleMap['id'] = array('in', $ruleIds);
            $ruleMap['status'] = 1;
            // 重新设置ruleIds，除去部分已删除或禁用的权限。
            $rules =Db::name('admin_rule')->where($ruleMap)->select();
            foreach ($rules as $k => $v) {
            	$ruleIds[] = $v['id'];
            	$rules[$k]['name'] = strtolower($v['name']);
            }
            empty($ruleIds)&&$ruleIds = '';
    		$menuMap['status'] = 1;
            $menuMap['rule_id'] = array('in',$ruleIds);
            $menusList = Db::name('admin_menu')->where($menuMap)->order('sort asc')->select();
        }
        if (!$menusList) {
            return null;
        }
        //处理菜单成树状
        $tree = new \com\Tree();
        $ret['menusList'] = $tree->list_to_tree($menusList, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['menusList'] = memuLevelClear($ret['menusList']);
        // 处理规则成树状
        $ret['rulesList'] = $tree->list_to_tree($rules, 'id', 'pid', 'child', 0, true, array('pid'));
        $ret['rulesList'] = rulesDeal($ret['rulesList']);

        return $ret;
    }

    /**
     * 判断是否是三代内下级
     */
    public function isInvitedUser($user, $invter_user){

        $user = $this->allmyteam(['userid' => $user])['all'];
        $invter_arr = array_filter($user, function ($v) use ($invter_user){
            if ($invter_user == $v['id'])
                return true;
            else
                return false;
        });
        if (empty($invter_arr))
            return false;
        else
            return true;
    }

    /**
     * 验证是否存在账户手机号为我的下级
     */
    public function isexitelowuser($userid="",$phone=""){
    	//查询一代
    	$phoneinfo=Db::name("user")->where("phone=$phone")->find();
    	$inviteid=$phoneinfo['inviter_id'];
    	if($inviteid==$userid){
    		return true;
    	}else{
    		$inviteinfo=Db::name("user")->where("id=$inviteid")->find();
    		if($inviteinfo['inviter_id']==$userid){
    			return true;
    		}else{
    			return false;
    		}
    	}
    }
    /**
     * 转让排单币
     */
    public function attompaicoin($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$phone=$param['phone'];
    	$paicoinnum=$param['paicoinnum'];
//    	$isexitelowuser=$this->isexitelowuser($userid,$phone);

        $subUser = Db::name('user')->where('phone', $phone)->find();

    	if(!$this->isInvitedUser($userid, $subUser['id'])){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改user数据
    	$result1=Db::name("user")->where("id=$userid")->find();
    	$paicoin1=$result1['paicoin']-$paicoinnum;
    	if($paicoin1<0){
    		return $this->error("2007","排单币余额不足，转让失败",array());
    	}
    	$result2=Db::name("user")->where("phone=$phone")->find();
    	$paicoin2=$result2['paicoin']+$paicoinnum;
    	$res1=Db::name("user")->where("id=$userid")->update(array("paicoin"=>$paicoin1));
    	$res2=Db::name("user")->where("phone=$phone")->update(array("paicoin"=>$paicoin2));
    	if($res1 && $res2){
    		$data=array(
    			"code"=>200,
    			"message"=>"转让成功",
    			"body"=>array(
    				"id"=>$userid,
    				"paicoin"=>$paicoin1
    			)
    		);
    		return json($data);
    	}else{
    		return $this->error("2005","转让失败",array());
    	}
    	
    }
    /**
     * 转让激活码
     */
    public function attomactivationcode($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$phone=$param['phone'];
    	$activationcodenum=$param['activationcodenum'];

    	$subUser = Db::name('user')->where('phone', $phone)->find();
//    	$isexitelowuser=$this->isexitelowuser($userid,$phone);

    	if(!$this->isInvitedUser($userid, $subUser['id'])){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改user数据
    	$result1=Db::name("user")->where("id=$userid")->find();
    	$activationcode1=$result1['activationcode']-$activationcodenum;
    	if($activationcode1<1){
    		return $this->error("2007","排单币不足，不能转让",array());
    	}
    	$result2=Db::name("user")->where("phone=$phone")->find();
    	$activationcode2=$result2['activationcode']+$activationcodenum;
    	$res1=Db::name("user")->where("id=$userid")->update(array("activationcode"=>$activationcode1));
    	$res2=Db::name("user")->where("phone=$phone")->update(array("activationcode"=>$activationcode2));
    	if($res1 && $res2){
    		$data=array(
    			"code"=>200,
    			"message"=>"转让成功",
    			"body"=>array(
    				"id"=>$userid,
    				"activationcode"=>$activationcode1
    			)
    		);
    		return $data;
    	}else{
    		return $this->error("2005","转让失败",array());
    	}
    }
    /**
     * 激活用户
     */
    public function activationuser($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param['userid'];
    	$activationuserid=$param["activationuserid"];
    	//获取当前用户的信息
    	$userinfo=Db::name("user")->where("id=$userid")->find();
    	if($userinfo["activationcode"]<1){
    		return $this->error("2007","激活码不足，激活失败",array());
    	}
    	if($userinfo["activation"]==0){
    		return $this->error("2011","当前用户未激活",array());
    	}
    	//获取被激活用户的信息
    	$activationuserinfo = Db::name("user")->where("id=$activationuserid")->find();

    	if(!$this->isInvitedUser($userid, $activationuserid)){
    		return $this->error("2003","该账户不是您的下级用户",array());
    	}
    	//修改用户的状态
    	$result=Db::name("user")->where("id=$activationuserid")->update(array("activation"=>1));
    	if($result){
    		//修改当前用户的激活码数目
    		$res=Db::name("user")->where("id=$userid")->update(array("activationcode"=>$userinfo["activationcode"]-1));
    		if(!$res){
    			return $this->error("2009","激活失败",array());
    		}
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=>array(
    				"id"=>$userid
    			)
    		);
    		return $data;
    	}else{
    		return $this->error("2005","不能重复激活",array());
    	}
    }

    /**
     *用户当前抽奖次数
     */

    public function lotteryCount($param){
        $user_id = $param['userid'];
        //当天抽奖次数
        $today=strtotime(date("Y-m-d"),time());
        $todayend=$today+60*60*24;
        $count=Db::name("draw_list")->where('userid', $user_id)->where("createtime between $today and $todayend")->count();

        return array(
            'code' => 200,
            'count' => $count
        );
    }

    /**
     * 点击抽奖
     */
    public function lotterydraw($param=""){
    	if(empty($param)){
    		return $this->error("2001","请确认信息",array());
    	}
    	$userid=$param["userid"];
    	$listid=$param['listid'];

        $time = intval (date("Hi"));
        if ($time < "1400" || $time > "2030") {
            return $this->error('2002', '当前时间不开放');
        }

    	 $res_count = $this->lotteryCount($param);
    	 $count = $res_count['count'];

    	 if ($count > 1) {
    	     return $this->error('2002', '今天抽奖次数已用完');
         }

        //今日排单币中奖数量
        // if ($listid == 3){
        //     $today = strtotime(date("Y-m-d"),time());
        //     $todayend = $today+60*60*24;
        //     $count = Db::name("draw_list")->where('draw_list_id', $listid)->where("createtime between $today and $todayend")->count();
        //     if ($count >= 100) {
        //         return $this->error('2002', '今天交易码已经派发完了');
        //     }
        // }
        
        // 获取激活码库存
        $lottery_count=Db::name("system_num")->where("id=1")->value("lottery_count");
        if(!$lottery_count){
            return $this->error("20012","大转盘抽奖尚未开放");
        }

        //今日激活码中奖数量
        if ($listid == 6){
            $today = strtotime(date("Y-m-d"),time());
            $todayend = $today+60*60*24;
            $count = Db::name("draw_list")->where('draw_list_id', $listid)->where("createtime between $today and $todayend")->count();
            if($count >= $lottery_count) {
                return $this->error('2002', '今天激活码已经抢完了');
            }
        }

        $result = 1;
        if ($listid == 6) {
            //查询奖品结果
            $drawinfo=Db::name("lottery_draw")->where("list=$listid")->find();
            //用户信息
            $userinfo=Db::name("user")->where("id=$userid")->find();
            $data=array(
                // "paicoin"=>$userinfo["paicoin"]+$drawinfo["paicoin_num"],
                "activationcode"=>$userinfo["activationcode"]+$drawinfo["activationcode_num"],
            );
            //修改信息
            $result = Db::name("user")->where("id=$userid")->update($data);
        }

    	if(!$result){
    		return $this->error("2003","抽奖失败",array());
    	}else{
    		//添加抽奖流水表单
    		$info=array(
                "userid"=>$userid,
                "draw_list_id"=>$listid,
                "createtime"=>time()
            );
    		$res=Db::name("draw_list")->insert($info);
    		if(!$res){
    			return $this->error("2005","抽奖记录添加失败",array());
    		}
    		//当天抽奖次数
    		$today=strtotime(date("Y-m-d"),time());
    		$todayend=$today+60*60*24;
    		$count=Db::name("draw_list")->where('userid', $userid)->where("createtime between $today and $todayend")->count();
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body" => $count
    		);
    		return $data;
    	}
    }
    /**
     * 奖品列表
     */
    public function drawlist($param=""){
    	$userid=$param["userid"];
    	if(!$userid){
    		return $this->error("2001","请确认用户登录",array());
    	}
    	//获取奖品列表
    	$datalist=Db::name("lottery_draw")->field("id,list,descrition")->select();

    	//用户今日抽奖次数
        $res_count = $this->lotteryCount($param);

        //当前是否开放
        $time = intval (date("Hi"));
        $open = 'yes';
        if ($time < "1400" || $time > "2030") {
            $open = 'no';
        }

    	if(!$datalist){
    		return $this->error("2003","获取失败",array());
    	}else{
    		$data=array(
    			"code"=>200,
    			"message"=>"修改成功",
    			"body"=> array(
    			    'list' => $datalist,
                    'count' => $res_count['count'],
                    'open' => $open
                )
    		);
    		return $data;
    	}
    }
    /**
     * 我的钱包
     */
    public function mywallet($param=""){
    	$userid=$param["userid"];
    	$userinfo = Db::name('user')
			    ->alias('m')
			    ->join("t_pay_list a", 'm.id = a.userid','left')
			    ->where("m.id=$userid")
			    ->field('m.id,m.username,m.phone,m.paicoin,m.activationcode,a.jing_money,a.dong_money')
			    ->find();

		if(!$userinfo){
			return $this->error("2001","用户信息获取失败",array());
		}

        $userinfo['money']=$userinfo['jing_money']+$userinfo['dong_money'] + $userinfo['green_money'];
        $userinfo['ben_money']=0;
        $userinfo['shou_money']=0;

		$data=array(
			"code"=>200,
			"message"=>"获取成功",
			"body"=>$userinfo
		);
		return json($data);

    }
    /**
     * 静态钱包
     */
    public function jing_wallet($param=""){
        $userid=$param['userid'];

        //静态金额

        $jing_money=Db::name("pay_list")->where("userid=".$userid)->find();
        if(!$jing_money){
            return $this->error("2001","参数错误");
        }

//        $jing_income=Db::name("jing_income")->where("paylist_id=".$jing_money['id'])->find();
//        if(!$jing_income){
//            return $this->error("2001","参数错误");
//        }

//        $offer_info=Db::name("offer")->where("id=".$jing_income['offer_id'])->find();
//        if(!$offer_info){
//            return $this->error("2001","参数错误");
//        }

        //累计收益
        $jing_income_list=Db::name("jing_income")->where("userid=".$userid)->select();
        $count=0;
        foreach ($jing_income_list as $key => $val) {
            $count+=$val['jing_income'];
        }

        $data=array(
            "jing_money"=>$count,
//            "ben_money"=>$offer_info['offer_money'],
            "ben_money"=>0,
//            "shou_money"=>$jing_income['jing_income'],
            "shou_money"=>0,
            "green_money"=> $jing_money['green_money']
        );

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$data
        );

        return $result;
    }

    /**
     * 我的团队
     */
    public function myteam($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        if($userinfo['activation']==0){
            return $this->error("2003","当前用户未激活",array(
                "userid"=>$userinfo['id'],
                "phone"=>$userinfo['phone'],
                "activation"=>$userinfo['activation'],
            ));
        }
        //直系人数
        $directcount=Db::name('user')->where("inviter_id=$userid")->count();
        //获取用户的直系
        $directuser = Db::name('user')
                ->alias('m')
                ->join("t_dong_income a",'m.id = a.offer_userid','left')
                ->where("m.inviter_id=$userid")
                ->field('m.id,m.username,m.phone,m.realname,m.activation,a.income_money as shou_money')
                ->select();
        //获取二代用户
        $bibasicuser = array();
        foreach ($directuser as $key => $v) {
            $arr=Db::name('user')->where("inviter_id=".$v['id'])->field("id,phone")->find();
            if($arr){
                $bibasicuser[]=$arr;
            }
        }
        //获取三代用户
        $tertuser = array();
        foreach ($bibasicuser as $k => $val) {
            $tertuser = Db::name('user')
                ->alias('m')
                ->join("t_dong_income a",'m.id = a.offer_userid','left')
                ->where("m.inviter_id=".$val['id'])
                ->field('m.id,m.username,m.phone,m.realname,m.activation,a.income_money as shou_money')
                ->select();
        }
        $tertcount=count($tertuser);
        //组合数组
        $result=array(
            "code" => 200,
            "directcount"=>$directcount,
            "directuser"=>$directuser,
            "tertcount"=>$tertcount,
            "tertuser"=>$tertuser,
        );
        return $result;
    }

    /**
     * 团队人数
     */
    public function teamCount($param){
        $data = $this->allmyteam($param);
        return array(
            'code' => 200,
            'total' => $data['total'],
            'direct_count' => $data['direct_count']
        );
    }

    /**
     * 获取三代以内的所有成员
     */
    public function allmyteam($param=""){
        $userid=$param["userid"];

        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        if($userinfo['activation']==0){
            return $this->error("2003","当前用户未激活",array(
                "userid"=>$userinfo['id'],
                "phone"=>$userinfo['phone'],
                "activation"=>$userinfo['activation'],
            ));
        }
        //直系
        $directuser=Db::name("user")->where("inviter_id=$userid")->field("id,phone,username,realname,create_time,activation")->select();
//        //二代
//        foreach ($directuser as $key => $v) {
//            $arr=Db::name('user')->where("inviter_id=".$v['id'])->field("id,phone,username,realname,create_time,activation")->find();
//            if($arr){
//                $bibasicuser[]=$arr;
//            }
//        }
        //二代
        $two_parents = array();
        foreach ($directuser as $k => $v) {
            $two_parents[] = $v['id'];
        }
        $two_res = [];
        if (!empty($two_parents)) {
            $two_res = Db::name('user')->whereIn('inviter_id', $two_parents)->field("id,phone,username,realname,create_time,activation")->select();
        }
        //三代
        $three_parents = array();
        foreach ($two_res as $k => $v) {
            $three_parents[] = $v['id'];
        }
        $three_res = [];
        if (!empty($three_parents)) {
            $three_res = Db::name('user')->whereIn('inviter_id', $three_parents)->field("id,phone,username,realname,create_time,activation")->select();
        }

//        //三代
//        foreach ($bibasicuser as $k => $val) {
//            $tertuser=Db::name("user")->where("inviter_id=".$val["id"])->field("id,phone,username,realname,create_time,activation")->select();
//        }

        $result = array_merge($directuser, $two_res, $three_res);
        foreach ($result as $k => $v) {
            $v['create_time'] = date("Y-m-d H:i:s", $v['create_time']);
            if($v['activation']==0){
                $arr1[]=$v;
            }else{
                $arr2[]=$v;
            }
        }

        $data=array(
            "code" => 200,
            "total" => count($result),
            "direct_count" => count($directuser),
            "all" => $result,
            "tobeactivation"=>$arr1?$arr1:array(),
            "enabledactivation"=>$arr2?$arr2:array()
        );
        return $data;
    }
    /**
     * 问题留言
     */
    public function askquestion($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }
        $question=$param["question"];
        if(empty($question)){
            return $this->error("2003","问题留言不能为空",array());
        }
        //添加留言
        $data=array(
           "userid"=>$userid, 
           "question"=>$question, 
           "ask_time"=>time()
        );
        //检查是否重复添加
        $isexite=Db::name("question_answer")->where(array("userid"=>$userid,"question"=>$question))->find();
        if($isexite){
            return $this->error("2007","请不要重复添加留言",array());
        }
        $result=Db::name("question_answer")->insert($data);
        if(!$result){
            return $this->error("2005","添加失败",array());
        }else{
            $list=Db::name("question_answer")->where(array("userid"=>$userid,"question"=>$question))->find();
            $res=array(
                "code"=>200,
                "message"=>"留言添加成功",
                "body"=>array(
                    "id"=>$list['id'],
                    "userid"=>$list['userid'],
                    "question"=>$list['question']
                )
            );
            return json($res);
        }
    }

    /**
     * 提供帮助
     */
    public function offer($param){

        $offer_money = $param['offer_money'];
        $auto = empty($param['auto']) ? 0 : 1;
        $user_id = $param['userid'];

        if (empty($offer_money) || $offer_money < 1000) {
            return $this->error(2001, '参数错误');
        }

        $res_user = Db::name('user')->where('id', $user_id)->find();
        if (empty($res_user))
            return $this->error(2002, '非法操作，当前用户不存在');
        if ($res_user['activation'] != 1)
            return $this->error(2002, '当前用户未激活，不能排单');
        if (empty($res_user['realname']) || empty($res_user['zfbname']) && empty($res_user['card']) )
            return $this->error(2002, '当前用户未完善交易资料，不能排单');

        /**
         * 进场人数判断   system_num
         */
        //获取进场人数
        $offer_num=Db::name("system_num")->where("id=1")->value("offer_num");
        if(!$offer_num){
            return $this->error("20012","系统错误");
        }

        //查询今天已经进场的人数
        $begin_time = strtotime(date("Y-m-d"),time());
        $offer_list=Db::name("offer")->where("status=0 and pay_status=0 and help_money=0")->select();
        $num=0;

        if($offer_list){
            foreach ($offer_list as $key => $val) {
                # code...
                if(strtotime($val["create_time"]) > $begin_time && strtotime($val["create_time"])<time()){
                    $num+=1;
                }
            }
            if($num>$offer_num || $num==$offer_num){
                return $this->error("20013","今日排单已结束");
            }
        }

        /**
         * 当前是否可以进行排单操作
         * 1、当前客户没有排单记录
         * 2、当前客户有排单记录，但是已经完成本次排单(付款完成)且资金已经解封
         */

        //是否存在正在进行的排单
        $cond['user_id'] = $user_id;
        $cond['status'] = 0;
        $res_offer = Db::name('offer')->where($cond)->find();
        if ($res_offer){
            return $this->error(400, '已经排单成功，等待交易匹配中');
        }   

        //是否存在已完成的排单
        $cond['user_id'] = $user_id;
        $cond['status'] = 1;
        $res_offer = Db::name('offer')->where($cond)->find();
        if ($res_offer){
            $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));
            if ( strtotime($now) >= strtotime($res_offer['unfreeze_time'])) {
                //自动排单在交易匹配中统一处理
                if ($res_offer['auto'] == 1) {
                    return $this->error(400, '自动排单成功，等待交易匹配中');
                } else {
                    //手动排单
                }
            } else {
                return $this->error(401, '正在收益中，不能排单');
            }
        }

        /**
         * 排单
         * 1、扣除排单币
         * 2、根据排单金额、自动排单选项进行排单
         */
        $coin = $offer_money / 100;
        if ($res_user['paicoin'] < $coin)
            return $this->error(2002, '交易码不足，不能排单');
        $remain_coin = $res_user['paicoin'] - $coin;

        // 启动事务
        Db::startTrans();
        try{
            Db::name('user')->where('id', $user_id)->update(['paicoin' => $remain_coin]);
            Db::name('offer')->insert([
                'user_id' => $user_id,
                'offer_money' => $offer_money,
                'auto' => $auto,
                'status' => 0,
                'pay_status' => 0,
                'unfreeze_time' => date("Y-m-d H:i:s"),
                'create_time' => date("Y-m-d H:i:s")
            ]);

            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '排单繁忙，请稍后重试');
        }

        return array(
            'code' => 200,
            'message' => '排单成功'
        );
    }
    /**
     * 请求帮助   accept
     */
    public function accept($param){
        $user_id=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$user_id and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在或者用户当前未激活",array());
        }

        //当前用户有已经排单完成的记录，且已经过了冻结时间
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));
        $offerinfo=Db::name("offer")->where("user_id=$user_id and status=1")->find();

        if(empty($offerinfo)){
            return $this->error("2003","请先完成排单",array());
        }
        if(strtotime($offerinfo['unfreeze_time'])>strtotime($now)){
            return $this->error("2005","正在收益中，不能请求帮助",array());
        }

        //当前用户有正在排单的记录，且付款状态为1，已经付了20%
        $is_exite=Db::name("offer")->where("user_id=$user_id and status=0")->find();
//        if($offerinfo['auto']==1){
            if($is_exite['pay_status'] == 0){
                return $this->error("2007","请支付下次排单20%付款金额",array());
            }
//        }
        
        $offer_money=$param['offer_money'];
        $type=$param['type'];
        $trader=$param['trader'];
        $auto=$param['auto'];

        //余额查询   pay_list
        $pay_info=Db::name("pay_list")->where("userid=".$user_id)->find();
        if (empty($pay_info)){
            return $this->error('2002', '获取钱包信息错误');
        }
        //查询当前所有的请求帮助的记录
        $accept_list_info=Db::name("accept_list")->where("userid=$user_id and is_finish = 0")->select();

        //判断
        if($userinfo['trader'] != user_md5($trader)){
            return $this->error("20016","交易密码不正确");
        }
        $num=0;
        foreach ($accept_list_info as $key => $val) {
            # code...
            $num+=$val['money'];
        }


        if($type==0){
            //静态
            $number=$offer_money/100;
//            $numbers=$offer_money+$num;

            if(floor($number) != $number){
                return $this->error("20013","静态金额提现必须为100的整数倍");
            }
            if($offer_money > $pay_info['jing_money']){
                return $this->error("20014","静态金额不足");
            }
        }
        if($type==1){
            //动态
            $number=$offer_money/500;
//            $numbers=$offer_money+$num;

            if(floor($number) != $number){
                return $this->error("20015","动态金额提现必须为500的整数倍");
            }
            if($offer_money > $pay_info['dong_money']){
                return $this->error("20017","动态金额不足");
            }
        }

        //是否已经添加拍单记录

        $cond['userid'] = $user_id;
        $cond['is_finish'] = 0;
        $res_types = Db::name("accept_list")->field("type")->where($cond)->select();
        if (in_array($type, $res_types)){
            return $this->error("2013","已经提现，交易正在匹配",array());
        }

        if ($type != 2){
            $query_type = $type == 0 ? 1 : 0;
            if (in_array($query_type, $res_types)){
                return $this->error("2013","动静态金额只能提现一种",array());
            }
        }
//        if($have_add_accept && $have_add_accept['type'] != $type){
//            return $this->error("2013","动静态金额只能提现一种",array());
//        }

        $accept_insert = array(
            "userid"=>$user_id,
            "offer_id" => $offerinfo['id'],
            "money"=>$offer_money,
            "is_finish"=>0,
            "type"=>$type,
            'create_time'=>date("Y-m-d H:i:s")
        );


        $wallet_update = array(
            'id' => $pay_info['id']
        );
        if ($type == 0) {
            $wallet_update['jing_money'] = $pay_info['jing_money'] - $offer_money;
        } else {
            $wallet_update['dong_money'] = $pay_info['dong_money'] - $offer_money;
        }

        // 启动事务
        Db::startTrans();
        try{
            Db::name('accept_list')->insert($accept_insert);
            Db::name('pay_list')->update($wallet_update);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统忙，请稍后重试');
        }

        $result=array(
            'code' => 200,
            'message' => '排单成功'
        );

        return json($result);
    }
    /**
     * 交易匹配
     */
    public function trade1(){
        /**
         * 1、获取待帮助的列表
         * 2、获取80%进场的提供帮助列表
         * 3、获取20%进场的提供帮助的列表
         */
        //获取待帮助列表
        $accept_list=Db::name("accept_list")->where("is_finish = 0")->order("create_time")->select();
        //获取帮助列表80%
        $offer_list=Db::name("offer")->where("status=0 and pay_status=1")->order("create_time")->select();
        //获取帮助列表20%
        $offer_list_20=Db::name("offer")->where("status=0 and pay_status=0")->order("create_time")->select();

        //判断当天的不给于匹配
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));
        foreach ($offer_list as $key => $val) {
            $daytime=strtotime($now)-strtotime($val['create_time']);
            $daytime=$daytime/24*60*60;
            if($daytime < 1){
                unset($offer_list[$key]);
            }else{
                //是否存在未结束的订单
                $offerinfo=Db::name("offer")->where("user_id=".$val['user_id']." and status = 1 and pay_status = 2")->find();
                if($offerinfo){
                    unset($offer_list[$key]);
                }else{
                    $offer_list[$key]['offer_money']=$val['offer_money']*0.8;
                }
            }
        }
        foreach ($offer_list_20 as $k => $v) {
            $daytime=strtotime($now)-strtotime($v['create_time']);
            $daytime=$daytime/24*60*60;
            if($daytime < 1){
                unset($offer_list_20[$k]);
            }else{
                $offer_list_20[$k]['offer_money']=$v['offer_money']*0.2;
            }
        }
        foreach ($accept_list as $key => $val) {
            $accept_list[$key]['money']=$val['money']-$val['have_accept_money'];
        }

        //匹配
        foreach ($accept_list as $key => $val) {
            //80%   匹配
            $num=0;
            foreach ($offer_list as $k => $v) {
                if($v['offer_money'] != 0 && $val['userid'] != $v['user_id']){
                    $num=$accept_list[$key]['money']-$offer_list[$k]['offer_money'];
                    if($num>0){
                        //添加记录表单
                        $data=array(
                            "offer_userid"=>$v['user_id'],
                            "accept_userid"=>$val['userid'],
                            "offer_id"=>$v['id'],
                            "accept_id"=>$val['id'],
                            "create_time"=>$now,
                            "help_money"=>$offer_list[$k]['offer_money']
                        );

                        Db::name("offer_accept_list")->insert($data);
                        //动态修改offer表单help_money
                        $help_money=$offer_list[$k]['help_money']+$offer_list[$k]['offer_money'];
                        Db::name("offer")->where("id=".$v['id'])->update(array("help_money"=>$help_money));

                        //删除匹配数组
                        $accept_list[$key]['money']=$num;
                        $offer_list[$k]['offer_money']=0;
                    }else{
                        //添加记录表单
                        $data=array(
                            "offer_userid"=>$v['user_id'],
                            "accept_userid"=>$val['userid'],
                            "offer_id"=>$v['id'],
                            "accept_id"=>$val['id'],
                            "create_time"=>$now,
                            "help_money"=>$accept_list[$key]['money']
                        );

                        Db::name("offer_accept_list")->insert($data);
                        //动态修改offer表单help_money
                        $help_money=$offer_list[$k]['help_money']+$accept_list[$key]['money'];
                        Db::name("offer")->where("id=".$v['id'])->update(array("help_money"=>$help_money));
                        
                        //删除匹配数组
                        $offer_list[$k]['offer_money']=$offer_list[$k]['offer_money']-$accept_list[$key]['money'];
                        $accept_list[$key]['money']=0;
                        break;
                    }
                }
            }

            //20%  匹配
            if($accept_list[$key]['money'] != 0){
                $nums=0;
                foreach ($offer_list_20 as $keys => $vals) {
                    if($offer_list_20[$keys]["offer_money"] != 0  && $val['userid'] != $vals['user_id']){
                        $nums=$accept_list[$key]['money']-$offer_list_20[$keys]['offer_money'];
                        if($nums>0){
                            //添加记录表单
                            $data=array(
                                "offer_userid"=>$vals['user_id'],
                                "accept_userid"=>$val['userid'],
                                "offer_id"=>$vals['id'],
                                "accept_id"=>$val['id'],
                                "create_time"=>$now,
                                "help_money"=>$offer_list_20[$keys]['offer_money']
                            );

                            Db::name("offer_accept_list")->insert($data);
                            //动态修改offer表单help_money
                            $help_money=$offer_list_20[$keys]['help_money']+$offer_list_20[$keys]['offer_money'];
                            Db::name("offer")->where("id=".$vals['id'])->update(array("help_money"=>$help_money));

                            //删除匹配数组
                            $accept_list[$key]['money']=$nums;
                            $offer_list_20[$keys]['offer_money']=0;
                        }else{
                            //添加记录表单
                            $data=array(
                                "offer_userid"=>$vals['user_id'],
                                "accept_userid"=>$val['userid'],
                                "offer_id"=>$vals['id'],
                                "accept_id"=>$val['id'],
                                "create_time"=>$now,
                                "help_money"=>$accept_list[$key]['money']
                            );

                            Db::name("offer_accept_list")->insert($data);
                            //动态修改offer表单help_money
                            $help_money=$offer_list_20[$keys]['help_money']+$accept_list[$key]['money'];
                            Db::name("offer")->where("id=".$vals['id'])->update(array("help_money"=>$help_money));

                            //删除匹配数组
                            $offer_list_20[$keys]['offer_money']=$offer_list_20[$keys]['offer_money']-$accept_list[$key]['money'];
                            $offer_list_20[$keys]['help_money']=$offer_list_20[$keys]['help_money']+$accept_list[$key]['money'];
                            $accept_list[$key]['money']=0;
                            break;
                        }
                    }  
                }
            }
        }

        //处理最后一个唯有匹配完全的资金
        //80%
        $number=0;
        foreach ($offer_list as $k => $v) {
            if($v['offer_money'] != 0  ){
                //添加匹配
                $data=array(
                    "offer_userid"=>$v['user_id'],
                    "accept_userid"=>0,
                    "offer_id"=>$v['id'],
                    "accept_id"=>0,
                    "create_time"=>$now,
                    "help_money"=>$v['offer_money']
                );

                Db::name("offer_accept_list")->insert($data);
                //动态修改offer表单help_money
                $help_money=$v['help_money']+$v['offer_money'];
                Db::name("offer")->where("id=".$v['id'])->update(array("help_money"=>$help_money));

                break;
            }else{
                $number+=1;
            }
        }
        $count=count($offer_list);

        //20%
        if($number == $count){
            foreach ($offer_list_20 as $k => $v) {
                if($v['offer_money'] != 0  ){
                    //添加匹配
                    $data=array(
                        "offer_userid"=>$v['user_id'],
                        "accept_userid"=>0,
                        "offer_id"=>$v['id'],
                        "accept_id"=>0,
                        "create_time"=>$now,
                        "help_money"=>$v['offer_money']
                    );

                    Db::name("offer_accept_list")->insert($data);
                    //动态修改offer表单help_money
                    $help_money=$v['help_money']+$v['offer_money'];

                    Db::name("offer")->where("id=".$v['id'])->update(array("help_money"=>$help_money));
                    break;
                }
            }
        }
        
        $data=array(
            "code"=>200,
            "message"=>"排单匹配成功"
        );
        return json($data);
    }

    /**
     * 交易匹配
     */
    public function trade(){
        /**
         * 1、获取待帮助的列表
         * 2、获取80%进场的提供帮助列表
         * 3、获取20%进场的提供帮助的列表
         */

        //获取待帮助列表
        $acceptList = Db::name('accept_list')
            ->where('is_finish', 0)
            ->whereTime('create_time', '<', date("Y-m-d"))
            ->order('create_time', 'asc')
            ->select();

        $offerList20 = Db::name('offer')
            ->whereTime('create_time', '<', date("Y-m-d"))
            ->where('status=0 and pay_status=0')
            ->order('create_time', 'asc')
            ->select();

        //进场80%
        $offerList80 = Db::name('offer')
            ->alias('a')
            ->where(function($query){
                $query->name('offer b')->where('b.user_id=a.user_id and b.status=1 and b.pay_status=2');
            }, 'not exists')
            ->where('a.status=0 and a.pay_status=1')
            ->whereTime('a.create_time', '<', date("Y-m-d"))
            ->select();

        //系统钱包
        $offerSystem = Db::name('sys_offer')->where('offer_money > help_money')->select();

        //实际需要的钱
        array_walk($acceptList, function (&$item){
            $item['accept_actual_money'] = $item['money'] - $item['accept_money'];
        });

        //实际提供的钱 80
        array_walk($offerList80, function (&$item){
            $item['offer_actual_money'] = $item['offer_money'] - $item['help_money'];
        });
        //实际提供的钱 20
        array_walk($offerList20, function (&$item){
            $item['offer_actual_money'] = $item['offer_money'] * 0.2 - $item['help_money'];
        });
        //平台所剩余的钱
        array_walk($offerSystem, function (&$item){
            $item['offer_actual_money'] = $item['offer_money'] - $item['help_money'];
        });

        //今日进场人数
        $limit = Db::name('system_num')->where('id', 1)->value('offer_num');
        //今日已进场人数
        $have_enter = 0;
        $limit_res = Db::name('enter_limit')->where('create_date', date('Y-m-d'))->find();
        if (empty($limit_res)){
            Db::name('enter_limit')->insert([
                'limit' => $have_enter,
                'create_date' => date('Y-m-d')
            ]);
        } else {
            $have_enter = $limit_res['limit'];
        }

        if ($have_enter >= $limit) {
            return $this->error(400, '今日进场人数已达上限');
        }

        //匹配位置
        $match_80 = -1;
        $match_20 = -1;

        //匹配
        foreach ($acceptList as $key => &$accept) {

            if ($accept['accept_actual_money'] <= 0)
                continue;
            if ($have_enter >= $limit){
                break;
            }
            //80%   匹配
            foreach ($offerList80 as $k => &$offer) {
                if($offer['offer_actual_money'] > 0 && $accept['userid'] != $offer['user_id']){
                    $remain_require = $accept['accept_actual_money'] - $offer['offer_actual_money'];
                    if($remain_require > 0){
                        //添加记录表单
                        $data = array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>$offer['id'],
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$offer['offer_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            //动态修改offer表单help_money
                            $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $offer['offer_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $offer['offer_actual_money']));

                            $have_enter++;
                            Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);

                            //更新数据
                            $accept['accept_actual_money'] = $remain_require;
                            $offer['offer_actual_money'] = 0;
                            // 提交事务
                            Db::commit();

                        } catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        return $this->error(2003, '匹配错误，请重新匹配');
                    }
                        continue;
                    }else{
                        //添加记录表单
                        $data=array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>$offer['id'],
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$accept['accept_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $accept['accept_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $accept['accept_actual_money']));

                            //更新数据
                            $offer['offer_actual_money'] = $offer['offer_actual_money'] - $accept['accept_actual_money'];
                            $accept['accept_actual_money'] = 0;
                            // 提交事务
                            Db::commit();
                        } catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            dump($e);
                            return $this->error(2004, '匹配错误，请重新匹配');
                        }
                        $match_80 = $k;
                        break;
                    }
                }
            }

            //20%   匹配
            foreach ($offerList20 as $k => &$offer) {
                if($offer['offer_actual_money'] > 0 && $accept['userid'] != $offer['user_id']){
                    $remain_require = $accept['accept_actual_money'] - $offer['offer_actual_money'];
                    if($remain_require > 0){
                        //添加记录表单
                        $data = array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>$offer['id'],
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$offer['offer_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            //动态修改offer表单help_money
                            $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $offer['offer_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $offer['offer_actual_money']));

                            $have_enter++;
                            Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);

                            //更新数据
                            $accept['accept_actual_money'] = $remain_require;
                            $offer['offer_actual_money'] = 0;
                            // 提交事务
                            Db::commit();
                        } catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            dump($e);
                            return $this->error(2005, '匹配错误，请重新匹配');
                        }
                        continue;
                    }else{
                        //添加记录表单
                        $data=array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>$offer['id'],
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$accept['accept_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $accept['accept_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $accept['accept_actual_money']));

                            //更新数据
                            $offer['offer_actual_money'] = $offer['offer_actual_money'] - $accept['accept_actual_money'];
                            $accept['accept_actual_money'] = 0;
                            // 提交事务
                            Db::commit();
                        } catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            dump($e);
                            return $this->error(2006, '匹配错误，请重新匹配');
                        }
                        $match_20 = $k;
                        break;
                    }
                }
            }

            //系统钱包   匹配
            foreach ($offerSystem as $k => &$offer) {
                if($offer['offer_actual_money'] > 0 && $accept['userid'] != $offer['user_id']){
                    $remain_require = $accept['accept_actual_money'] - $offer['offer_actual_money'];
                    if($remain_require > 0){
                        //添加记录表单
                        $data = array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>0,
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$offer['offer_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            //动态修改offer表单help_money
                            $has_help_money = Db::name("sys_offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("sys_offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $offer['offer_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $offer['offer_actual_money']));

                            //更新数据
                            $accept['accept_actual_money'] = $remain_require;
                            $offer['offer_actual_money'] = 0;
                            // 提交事务
                            Db::commit();
                        } catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            dump($e);
                            return $this->error(2007, '匹配错误，请重新匹配');
                        }
                        continue;
                    }else{
                        //添加记录表单
                        $data=array(
                            "offer_userid"=>$offer['user_id'],
                            "accept_userid"=>$accept['userid'],
                            "offer_id"=>0,
                            "accept_id"=>$accept['id'],
                            "create_time"=>date("Y-m-d H:i:s"),
                            "help_money"=>$accept['accept_actual_money']
                        );

                        Db::startTrans();
                        try{
                            Db::name("offer_accept_list")->insert($data);
                            $has_help_money = Db::name("sys_offer")->where("id", $offer['id'])->value('help_money');
                            Db::name("sys_offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $accept['accept_actual_money']));

                            $has_accept_money = Db::name("accept_list")->where("id", $accept['id'])->value('accept_money');
                            Db::name("accept_list")->where("id", $accept['id'])->update(array("accept_money"=> $has_accept_money + $accept['accept_actual_money']));

                            //更新数据
                            $offer['offer_actual_money'] = $offer['offer_actual_money'] - $accept['accept_actual_money'];
                            $accept['accept_actual_money'] = 0;
                            // 提交事务
                            Db::commit();
                        } catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            dump($e);
                            return $this->error(2008, '匹配错误，请重新匹配');
                        }
                        break;
                    }
                }
            }
        }

        // 帮助完成后多余的资金打入系统用户
        $system_user = $this->sysAccount;
        if ($match_80 >=0 && $match_80 < count($offerList80) - 1) {
            $sysUser = $system_user[array_rand($system_user)];
            $data=array(
                "offer_userid"=>$offerList80[$match_80]['user_id'],
                "accept_userid"=>$sysUser,
                "offer_id"=>$offerList80[$match_80]['id'],
                "accept_id"=>0,
                "create_time"=>date("Y-m-d H:i:s"),
                "help_money"=> $offerList80[$match_80]['offer_actual_money']
            );

            Db::startTrans();
            try{
                Db::name("offer_accept_list")->insert($data);
                $has_help_money = Db::name("offer")->where("id", $offerList80[$match_80]['id'])->value('help_money');
                Db::name("offer")->where("id", $offerList80[$match_80]['id'])->update(array("help_money"=> $has_help_money + $offerList80[$match_80]['offer_actual_money']));

                $sys_offer_money = Db::name('sys_offer')->where('user_id', $sysUser)->value('offer_money');
                Db::name('sys_offer')->where('user_id', $sysUser)->update(['offer_money' => $sys_offer_money + $offerList80[$match_80]['offer_actual_money']]);

                $have_enter++;
                Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);
                //更新数据
                $offerList80[$match_80]['offer_actual_money'] = 0;
                // 提交事务
                Db::commit();
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                dump($e);
                return $this->error(2009, '匹配错误，请重新匹配');
            }
        }

        if ($match_20 >=0 && $match_20 < count($offerList20) - 1) {
            $sysUser = $system_user[array_rand($system_user)];
            $data=array(
                "offer_userid"=>$match_20[$match_20]['user_id'],
                "accept_userid"=>$sysUser,
                "offer_id"=>$match_20[$match_20]['id'],
                "accept_id"=>0,
                "create_time"=>date("Y-m-d H:i:s"),
                "help_money"=> $offerList20[$match_20]['offer_actual_money']
            );

            Db::startTrans();
            try{
                Db::name("offer_accept_list")->insert($data);
                $has_help_money = Db::name("offer")->where("id", $match_20[$match_20]['id'])->value('help_money');
                Db::name("offer")->where("id", $match_20[$match_20]['id'])->update(array("help_money"=> $has_help_money + $offerList20[$match_20]['offer_actual_money']));
                $sys_offer_money = Db::name('sys_offer')->where('user_id', $sysUser)->value('offer_money');
                Db::name('sys_offer')->where('user_id', $sysUser)->update(['offer_money' => $sys_offer_money + $offerList20[$match_20]['offer_actual_money']]);
                $have_enter++;
                Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);
                //更新数据
                $offerList20[$match_20]['offer_actual_money'] = 0;
                // 提交事务
                Db::commit();
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                dump($e);
                return $this->error(2010, '匹配错误，请重新匹配');
            }
        }


        //进场人数匹配完成之后有多余的资金也需要打入平台账户
        if ($have_enter < $limit) {
            //80%   匹配系统用户
            foreach ($offerList80 as $k => &$offer) {
                if($offer['offer_actual_money'] > 0 ){
                    $sysUser = $system_user[array_rand($system_user)];
                    $data=array(
                        "offer_userid"=>$offer['user_id'],
                        "accept_userid"=>$sysUser,
                        "offer_id"=>$offer['id'],
                        "accept_id"=>0,
                        "create_time"=>date("Y-m-d H:i:s"),
                        "help_money"=> $offer['offer_actual_money']
                    );

                    Db::startTrans();
                    try{
                        Db::name("offer_accept_list")->insert($data);
                        $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                        Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $offer['offer_actual_money']));

                        $sys_offer_money = Db::name('sys_offer')->where('user_id', $sysUser)->value('offer_money');
                        Db::name('sys_offer')->where('user_id', $sysUser)->update(['offer_money' => $sys_offer_money + $offer['offer_actual_money']]);

                        $have_enter++;
                        Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);
                        //更新数据
                        $offer['offer_actual_money'] = 0;
                        // 提交事务
                        Db::commit();
                    } catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        dump($e);
                        return $this->error(2011, '匹配错误，请重新匹配');
                    }
                    if ($have_enter >= $limit)
                        break;
                }
            }

            //20%   匹配系统用户
            foreach ($offerList20 as $k => &$offer) {
                if($offer['offer_actual_money'] > 0 ){
                    $sysUser = $system_user[array_rand($system_user)];
                    $data=array(
                        "offer_userid"=>$offer['user_id'],
                        "accept_userid"=>$sysUser,
                        "offer_id"=>$offer['id'],
                        "accept_id"=>0,
                        "create_time"=>date("Y-m-d H:i:s"),
                        "help_money"=> $offer['offer_actual_money']
                    );

                    Db::startTrans();
                    try{
                        Db::name("offer_accept_list")->insert($data);
                        $has_help_money = Db::name("offer")->where("id", $offer['id'])->value('help_money');
                        Db::name("offer")->where("id", $offer['id'])->update(array("help_money"=> $has_help_money + $offer['offer_actual_money']));

                        $sys_offer_money = Db::name('sys_offer')->where('user_id', $sysUser)->value('offer_money');
                        Db::name('sys_offer')->where('user_id', $sysUser)->update(['offer_money' => $sys_offer_money + $offer['offer_actual_money']]);

                        $have_enter++;
                        Db::name('enter_limit')->where('create_date', date('Y-m-d'))->update(['limit' => $have_enter]);
                        //更新数据
                        $offer['offer_actual_money'] = 0;
                        // 提交事务
                        Db::commit();
                    } catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        return $this->error(2012, '匹配错误，请重新匹配');
                    }
                    if ($have_enter >= $limit)
                        break;
                }
            }
        }

        $data=array(
            "code"=>200,
            "message"=>"交易匹配成功"
        );
        return json($data);
    }

    /**
     * 帮助记录
     */
    public function offerhelpnotes($param=""){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }

        //获取提供帮助记录
        $offerhelpinfo=Db::name("offer_accept_list")->where("offer_userid=$userid and pay_status = 1")->select();
        //获取接受帮助记录
        $accepthelpinfo=Db::name("offer_accept_list")->where("accept_userid=$userid and pay_status = 1")->select();

        //数组处理 提供帮助 接受帮助
        if($offerhelpinfo){
            $res = [];
            foreach ($offerhelpinfo as $k => $v) {
                $res[$v['offer_id']][] = $v;
            }
            $data=array_values($res);
            foreach ($data as $key => $val) {
                $offer_list[$key]['count']=count($val);
                $count=0;
                foreach ($val as $k => $v) {
                    //获取帮助信息
                    $offerinfo=Db::name("offer")->where("id=".$v['offer_id'])->find();
                    $count+=$v['help_money'];
                }
                $offer_list[$key]['offer_id']=$offerinfo['id'];
                $offer_list[$key]['offer_money']=$count;
                $offer_list[$key]['create_time']=$offerinfo['create_time'];
            }
        }
        if($accepthelpinfo){
            $arr = [];
            foreach ($accepthelpinfo as $k => $v) {
                $arr[$v['offer_id']][] = $v;
            }
            $data=array_values($arr);
            foreach ($data as $key => $val) {
                $accept_list[$key]['count']=count($val);
                $counts=0;
                foreach ($val as $k => $v) {
                    //获取帮助信息
                    $offerinfo=Db::name("offer")->where("id=".$v['offer_id'])->find();
                    $counts+=$v['help_money'];
                }
                $accept_list[$key]['offer_id']=$offerinfo['id'];
                $accept_list[$key]['offer_money']=$counts;
                $accept_list[$key]['create_time']=$offerinfo['create_time'];
            }            
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>array(
                "offer_list"=>$offer_list?$offer_list:array(),
                "accept_list"=>$accept_list?$accept_list:array()
            )
        );
        return json($result);
    }
    /**
     * 帮助详情
     */
    public function offerhelpinfo($param=""){

        $offer_id=$param['offer_id'];

        //获取帮助记录
        $offernotes=Db::name('offer_accept_list')->where("offer_id=$offer_id and status=1")->select();

        if(!$offernotes){
            return $this->error("2001","没有交易记录");
        }



        foreach ($offernotes as $key => $val) {
            $count+=$val['help_money'];
            //提供帮助的信息
            $offerinfo=Db::name("offer")->where("id=".$offer_id)->find();
            //获取被帮助人的信息
            if($val['accept_userid']!=0){
                $userinfo=Db::name("user")->where("id=".$val['accept_userid'])->find();
            }else{
                $userinfo=Db::name("payment_admin")->where("is_play=1")->find();
            }
            $data=array(
                // "offer_money"=>$offerinfo["offer_money"],
                "notes_id"=>$val["id"],
                "accept_phone"=>$userinfo["phone"],
                "accept_help_money"=>$val["help_money"],
                "zfbname"=>$userinfo["zfbname"]?$userinfo["zfbname"]:'',
                "card"=>$userinfo["card"]?$userinfo["card"]:'',
                "card_address"=>$userinfo["card_address"]?$userinfo["card_address"]:'',
                "pay_status"=>$val["pay_status"],
                "pay_img"=>$val["pay_img"],
                "pay_time"=>$val["pay_time"],
            );
            $list[$key]=$data;
        }
        foreach ($list as $k => $v) {
            $list[$k]["count"]=$count;
            # code...
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
        return json($result);
    }

    /**
     * 接受帮助详情
     */
    public function acceptHelpInfo($param){

        $note_id=$param['note_id'];

        if (!$note_id) {
            return $this->error("2001","参数错误");
        }

        //获取接受帮助记录
        
        $acceptList = Db::name('offer_accept_list')
            ->alias('a')
            ->join('t_user b', 'a.offer_userid = b.id')
            ->where('a.id', $note_id)
            ->where('a.status', 1)
            ->field('b.phone as offer_phone,b.zfbname,b.card,b.card_address,a.help_money,a.pay_status,a.pay_img,a.accept_status,a.accept_time')
            ->find();

        if(empty($acceptList)){
            return $this->error("2001","交易不存在");
        }

        return array(
            'code' => 200,
            'body' => $acceptList
        );
    }

    /**
     * 上传支付凭证
     */
    public function uploadeimg($param){
        $notes_id=$param['notes_id'];
        $file_url= $param['file_url'];

        $now=date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));
        $data["pay_img"]=$file_url;
        $data["pay_time"]=$now;
        $data["pay_status"]=1;

        if(!$file_url || !$notes_id){
            return $this->error("20013","参数不能为空");
        }

        //获取匹配记录信息
        $notes_info=Db::name("offer_accept_list")->where("id=".$notes_id." and status=1")->find();

        //判断收益利率
        $pay_time_3hour=strtotime($notes_info['confirm_time'])+3*60*60;
        $pay_time_6hour=strtotime($notes_info['confirm_time'])+6*60*60;

        if(time()<$pay_time_3hour){
            $data['pay_rate']="20";
        }elseif (time()>$pay_time_3hour && time()<$pay_time_6hour) {
            $data['pay_rate']="10";
        }elseif (time()>$pay_time_6hour) {
            //冻结账户
            Db::name("user")->where("id=".$notes_info['offer_userid'])->update(array("status"=>0));
            return array(
                "code"=>2001,
                "message"=>"超过六小时未打款，账户已冻结"
            );
        }

        //修改  offer_accept_list  
        Db::name("offer_accept_list")->where("id=".$notes_id)->update($data);

        //短信通知接受帮助的人
        $accept_phone = Db::name('user')
            ->where('id', $notes_info['accept_userid'])
            ->value('phone');
        if ($accept_phone){
            $userModel = model("User");
            $userModel->sendphonecode($accept_phone, 151703);
        }

        $res=array(
            "code"=>200,
            "message"=>"上传成功"
        );
        return $res;
    }

    /**
     * 上传支付凭证
     */
    public function sysUpLoadeImg($param){
        $notes_id=$param['notes_id'];
        $file_url= $param['file_url'];

        $now=date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));
        $data["pay_img"]=$file_url;
        $data["pay_time"]=$now;
        $data["pay_status"]=1;

        if(!$notes_id){
            return $this->error("20013","参数不能为空");
        }

        //获取匹配记录信息
        $notes_info=Db::name("offer_accept_list")->where("id=".$notes_id." and status=1")->find();

        if (!in_array($notes_info['offer_userid'], $this->sysAccount)){
            return $this->error("2003","非系统用户不能确认打款");
        }

        //判断收益利率
        $pay_time_3hour=strtotime($notes_info['confirm_time'])+3*60*60;
        $pay_time_6hour=strtotime($notes_info['confirm_time'])+6*60*60;

        if(time()<$pay_time_3hour){
            $data['pay_rate']="20";
        }elseif (time()>$pay_time_3hour && time()<$pay_time_6hour) {
            $data['pay_rate']="10";
        }elseif (time()>$pay_time_6hour) {
            //冻结账户
            $data['pay_rate']="5";
//            Db::name("user")->where("id=".$notes_info['offer_userid'])->update(array("status"=>0));
//            return array(
//                "code"=>2001,
//                "message"=>"超过六小时未打款，账户已冻结"
//            );
        }

        //修改  offer_accept_list
        Db::name("offer_accept_list")->where("id=".$notes_id)->update($data);

        //短信通知接受帮助的人
        $accept_phone = Db::name('user')
            ->where('id', $notes_info['accept_userid'])
            ->value('phone');
        if ($accept_phone){
            $userModel = model("User");
            $userModel->sendphonecode($accept_phone, 151703);
        }

        $res=array(
            "code"=>200,
            "message"=>"上传成功",
            "status" => 1,
            "confirm_time" => $now
        );
        return $res;
    }

    /**
     * 待帮助确认收款
     */
    public function accept_gather($param){
        $notes_id=$param['notes_id'];
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));

        //获取匹配信息
        $notes_info = Db::name("offer_accept_list")->where("id=$notes_id and status=1 and pay_status=1")->find();

        if(!$notes_info){
            return $this->error("2015","当前交易不存在");
        }

        if($notes_info['accept_status'] == 1){
            return $this->error("2003","已经确认收款");
        }

        /**
         *接受帮助的人确认本条交易记录
         */
        $note_update = array(
            'id' => $notes_info['id'],
            'accept_status' => 1,
            'accept_time' => date('Y-m-d H:i:s')
        );


        /**
         * 接受帮助的人是否已经全部收款
         * 1.部分收款,更新have_accept_money
         * 2.全部收款，更新is_finish
         * 3.结束排单
         */
        $cond = [
            'id' => $notes_info['accept_id'],
            'is_finish' => 0
        ];
        $accept = Db::name("accept_list")->where($cond)->find();
        if (empty($accept)){
            return $this->error("2015","当前交易不存在");
        }

        $accept_money = $accept['have_accept_money'] + $notes_info['help_money'];
        if ($accept_money > $accept['money']){
            return $this->error("2005","非法交易");
        }

        $is_finished = $accept_money == $accept['money'] ? 1 : 0;
        $accept_update = array(
            "id" => $accept['id'],
            "have_accept_money" => $accept_money,
            "is_finish" => $is_finished
        );

        $accept_offer_update = array();
        if ($is_finished == 1){
            $accept_offer_update = array(
                'id' => $accept['offer_id'],
                'status' => 2,
                'create_time' => date('Y-m-d H:i:s')
            );
        }

        /**
         * 提供帮助的人是否已经全部付款
         * 提供帮助的人offer更新信息
         * 1.付完20%，更新pay_status=1
         * 2.不足20%，不需要处理
         * 3.全部付完更新pay_status=2,status=1，该用户已经完成排单，需要计算本轮的静态收益和上级玩家的动态收益
         * 4.如果是系统提供帮助，忽略本段逻辑
         *
         */
        if (in_array($notes_info['offer_userid'], $this->sysAccount)){
            // 系统提供帮助，不做任何处理
        } else {
            $offer = Db::name('offer')->where('id', $notes_info['offer_id'])->find();
            if (empty($offer)){
                return $this->error("2015","当前交易不存在");
            }

            //本次排单已付款、已确认的接受帮助信息
            $haveAcceptList = Db::name("offer_accept_list")->where("offer_id=".$notes_info['offer_id']." and pay_status=1 and accept_status=1")->select();
            $havePay = 0;
            if($haveAcceptList){
                $havePay = array_sum(array_column($haveAcceptList, 'help_money'));
            }

            $allPay = $havePay + $notes_info['help_money'];
            if ($allPay > $offer['offer_money']){
                return $this->error("2005","非法交易");
            }

            $offer_update_offer = array(
                "id" => $offer['id'],
                "status" => $offer['status'],
                "pay_status" => $offer['pay_status'],
                "create_time" => date('Y-m-d H:i:s'),
                "unfreeze_time" => $offer['unfreeze_time']
            );

            $temp_update = [];

            //20%
            if ($offer['pay_status'] == 0){
                if ($allPay == $offer['offer_money'] * 0.2){
                    $temp_update = array(
                        "id" => $offer['id'],
                        "status" => 0,
                        "pay_status" => 1,
                    );
                }
            }

            $have_income = false;
            //80%
            if ($offer['pay_status'] == 1) {
                if ($allPay == $offer['offer_money']){
                    $temp_update = array(
                        "id" => $offer['id'],
                        "status" => 1,
                        "pay_status" => 2,
                        "unfreeze_time" => date("Y-m-d H:i:s",time() + 8*24*60*60)
                    );
                    $have_income = true;
                }
            }
            $offer_update_offer = array_merge($offer_update_offer, $temp_update);


            //计算静态和动态收益
            $jing_income_insert = array();
            $jing_income_update = array();
            $dyna_wallet_update = array();
            $dyna_income_insert = array();

            if ($have_income) {
                //静态收益
                $wallet = Db::name('pay_list')->where('userid', $notes_info['offer_userid'])->find();
                if (!$wallet){
                    return $this->error("2007","用户钱包信息有误");
                }

                $rate_arr = array_merge(array_column($haveAcceptList, 'pay_rate'), ['pay_rate' => $notes_info['pay_rate']]);
                $cur_rate = min($rate_arr);
                $dong_income = Db::name("dong_income")->where("offer_userid", $notes_info['offer_userid'])->find();
                $round = Db::name("offer")->where("user_id=".$notes_info['offer_userid']." and status=2")->count();
                if ($round > 6 && empty($dong_income)) {
                    $cur_rate = 10;
                }

                $offer_money = $offer['offer_money'];
                $jing_income = $offer_money * $cur_rate / 100;
                $jing_income_update = array(
                    'id' => $wallet['id'],
                    'jing_money' => $wallet['jing_money'] + $offer_money + $jing_income
                );

                $jing_income_insert = array(
                    "userid" => $notes_info['offer_userid'],
                    "paylist_id" => $wallet['id'],
                    "offer_id" => $notes_info['offer_id'],
                    "jing_income" => $jing_income,
                    "pay_rate" => $cur_rate,
                    "create_time" => date("Y-m-d H:i:s")
                );

                //动态收益
                $fatheruser = $this->getfatheruser(["userid"=>$notes_info['offer_userid']]);

                if ($fatheruser) {

                    $offer_user = $notes_info['offer_userid'];

                    array_walk($fatheruser, function($item) use($offer_money, $offer_user, &$dyna_wallet_update, &$dyna_income_insert){

                        if ($item['userid']){
                            $pay_info = Db::name("pay_list")->where("userid", $item['userid'])->find();
                            if ($pay_info){
                                $dyna_wallet_update[] = array(
                                    "id" => $pay_info['id'],
                                    "dong_money" => $pay_info['dong_money'] + $offer_money * 5 / 100
                                );

                                $dyna_income_insert[] = array(
                                    "offer_userid" => $offer_user,
                                    "accept_userid"=> $item['userid'],
                                    "income_money" => $offer_money * 5 / 100,
                                    "create_time" => date("Y-m-d H:i:s")
                                );
                            }
                        }

                    });
                }
            }
        }



//        //收益表  pay_list
//        $pay_list_info=Db::name("pay_list")->where("userid=".$notes_info['offer_userid'])->find();
//
//        //判断
//        if(!$offer_info || !$accept_info){
//            return $this->error("2001","参数错误");
//        }
//
//
//        //匹配表
//        $data=array(
//            "id"=>$notes_info['id'],
//            "accept_status"=>1,
//            "accept_time"=>$now
//        );
//        //判断offer表单
//        $count=0;
//        if($offerinfo){
//            foreach ($offerinfo as $k => $v) {
//                $count+=$v['help_money'];
//            }
//
//            if($offer_info['offer_money']*0.2 == $count){
//                $offer_data=array(
//                    "id"=>$offer_info['id'],
//                    "pay_status"=>1,
//                    "create_time"=>$now
//                );
//            }elseif($offer_info['offer_money'] == $count){
//                $offer_data=array(
//                    "id"=>$offer_info['id'],
//                    "status"=>2,
//                    "pay_status"=>2,
//                    "unfreeze_time"=>date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time())+8*24*60*60),
//                );
//            }
//        }
//        //判断accept
//        $money=$notes_info['help_money']+$accept_info["have_accept_money"];
//        if($money == $accept_info['money']){
//            $accept_data=array(
//                "id"=>$accept_info['id'],
//                "have_accept_money"=>$money,
//                "is_finish"=>1
//            );
//        }else{
//            $accept_data=array(
//                "id"=>$accept_info['id'],
//                "have_accept_money"=>$money
//            );
//        }
//        //修改收益   pay_list
//        $pay_list_data=array(
//            "id"=>$pay_list_info['id']
//        );
//        if($accept_info['type']==0){
//            $pay_list_data['jing_money']=$pay_list_info['jing_money']-$notes_info['help_money'];
//        }else{
//            $pay_list_data['dong_money']=$pay_list_info['dong_money']-$notes_info['help_money'];
//        }

        // 启动事务
        Db::startTrans();
        try{
            //1. 确认当前收款记录
            Db::name('offer_accept_list')->update($note_update);

            //2. 更新收款进度
            Db::name('accept_list')->update($accept_update);
            if (!empty($accept_offer_update)){
                Db::name('offer')->update($accept_offer_update);
            }

            if (in_array($notes_info['offer_userid'], $this->sysAccount)){
                //系统打款，不做处理
            } else {
                //3. 更新打款进度
                Db::name('offer')->update($offer_update_offer);

                //4. 更新打款用户静态收益
                if (!empty($jing_income_update)){
                    Db::name('pay_list')->update($jing_income_update);
                    Db::name('jing_income')->insert($jing_income_insert);
                }

                //5. 更新打款用户上级玩家动态收益
                if (!empty($dyna_wallet_update)) {
                    foreach ($dyna_wallet_update as $index => $item){
                        Db::name('pay_list')->update($item);
                        Db::name('dong_income')->insert($dyna_income_insert[$index]);
                    }
                }
            }
            
//            if($notes_info['green_channel']==0){
//                if($offer_data){
//                    Db::name('offer')->update($offer_data);
//                }
//            }else{
//                $green_info=Db::name("green_channel")->where("id=".$notes_info['offer_id'])->find();
//                if($count == $green_info['offer_money']){
//                    Db::name('green_channel')->update(array(
//                        "id"=>$notes_info['offer_id'],
//                        "unfreeze_time"=>date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time())+5*24*60*60)
//                    ));
//                }
//            }

//            Db::name('accept_list')->update($accept_data);
//            Db::name("pay_list")->update($pay_list_data);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            dump($e);die();
            return $this->error(2003, '排单繁忙，请稍后重试');
        }

//        /**
//         * 动态收益accept_userid
//         * 静态收益offer_userid
//         */
//        //重新获取
//        $offer_info_income=Db::name("offer")->where("id=".$offer_info['id'])->find();
//        //前七轮收益
//        $jing_income_num=Db::name("offer")->where("user_id=".$offer_info_income['user_id']." and status=2")->count();
//        //获取最低获益比率
//        $notes_info=Db::name("offer_accept_list")->where("offer_id=".$offer_info_income['id'])->order("pay_rate desc")->find();
//
//        if($offer_info_income['status'] == 2){
//            //静态
//            if($jing_income_num>6){
//                //判断是否存在动态收益
//                $exite_dong_income=Db::name("dong_income")->where("userid=".$offer_info_income['user_id'])->find();
//                if(!$exite_dong_income){
//                    $pay_rate=0.10;
//                }else{
//                    $pay_rate=$notes_info['pay_rate'];
//                }
//            }else{
//                $pay_rate=$notes_info['pay_rate'];
//            }
//
//            //获取金额数据  pay_list
//            $pay_offer_info=Db::name("pay_list")->where("userid=".$offer_info_income['user_id'])->find();
//
//            $jing_income=$offer_info_income['offer_money']*$pay_rate/100;
//
//            $offer_data=array(
//                "id"=>$pay_offer_info['id'],
//                "jing_money"=>$pay_offer_info['jing_money']+$jing_income,
//            );
//            $offer_jing_income=array(
//                "userid"=>$offer_info_income['user_id'],
//                "paylist_id"=>$pay_offer_info['id'],
//                "offer_id"=>$offer_info_income['id'],
//                "jing_income"=>$jing_income,
//                "pay_rate"=>$pay_rate,
//                "create_time"=>$now
//            );
//
//            Db::name("pay_list")->update($offer_data);
//            Db::name("jing_income")->insert($offer_jing_income);
//
//
//
//
//
//            foreach ($fatheruser as $key => $val) {
//                if($val['userid']){
//                    //获取金额数据  pay_list
//                    $pay_info=Db::name("pay_list")->where("userid=".$val['userid'])->find();
//                    if($val['num']==1){
//                        $pay_rate_dong=0.04;
//                    }else{
//                        $pay_rate_dong=0.05;
//                    }
//                    $pay_data=array(
//                        "id"=>$pay_info['id'],
//                        "dong_money"=>$pay_info['dong_money']+$jing_income*$pay_rate_dong
//                    );
//                    $income_data=array(
//                        "offer_userid"=>$offer_info_income['user_id'],
//                        "accept_userid"=>$val['userid'],
//                        "income_money"=>$jing_income*$pay_rate_dong,
//                        "create_time"=>$now
//                    );
//
//                    Db::name("pay_list")->update($pay_data);
//                    Db::name("dong_income")->insert($income_data);
//                }
//            }
//
//        }
        //短信通知提供帮助的人
        $offer_phone = Db::name('user')
            ->where('id', $notes_info['offer_userid'])
            ->value('phone');
        if ($offer_phone){
            $userModel = model("User");
            $userModel->sendphonecode($offer_phone, 151703);
        }

        return array(
            'code' => 200,
            'message' => '确认收款成功'
        );
    }


    /**
     * 待帮助确认收款
     */
    public function sys_accept_gather($param){
        $notes_id=$param['notes_id'];

        //获取匹配信息
        $notes_info = Db::name("offer_accept_list")->where("id=$notes_id and status=1 and pay_status=1")->find();

        if(!$notes_info){
            return $this->error("2015","当前交易不存在");
        }

        if($notes_info['accept_status'] == 1){
            return $this->error("2003","已经确认收款");
        }

        if (!in_array($notes_info['accept_userid'], $this->sysAccount)){
            return $this->error("2003","非系统用户不能确认交易");
        }

        /**
         *接受帮助的人确认本条交易记录
         */
        $note_update = array(
            'id' => $notes_info['id'],
            'accept_status' => 1,
            'accept_time' => date('Y-m-d H:i:s')
        );

        /**
         * 提供帮助的人是否已经全部付款
         * 提供帮助的人offer更新信息
         * 1.付完20%，更新pay_status=1
         * 2.不足20%，不需要处理
         * 3.全部付完更新pay_status=2,status=1，该用户已经完成排单，需要计算本轮的静态收益和上级玩家的动态收益
         *
         *
         */
        $offer = Db::name('offer')->where('id', $notes_info['offer_id'])->find();
        if (empty($offer)){
            return $this->error("2015","当前交易不存在");
        }

        //本次排单已付款、已确认的接受帮助信息
        $haveAcceptList = Db::name("offer_accept_list")->where("offer_id=".$notes_info['offer_id']." and pay_status=1 and accept_status=1")->select();
        $havePay = 0;
        if($haveAcceptList){
            $havePay = array_sum(array_column($haveAcceptList, 'help_money'));
        }

        $allPay = $havePay + $notes_info['help_money'];
        if ($allPay > $offer['offer_money']){
            return $this->error("2005","非法交易");
        }

        $offer_update_offer = array(
            "id" => $offer['id'],
            "status" => $offer['status'],
            "pay_status" => $offer['pay_status'],
            "create_time" => date('Y-m-d H:i:s'),
            "unfreeze_time" => $offer['unfreeze_time']
        );

        $temp_update = [];

        //20%
        if ($offer['pay_status'] == 0){
            if ($allPay == $offer['offer_money'] * 0.2){
                $temp_update = array(
                    "id" => $offer['id'],
                    "status" => 0,
                    "pay_status" => 1,
                );
            }
        }

        $have_income = false;
        //80%
        if ($offer['pay_status'] == 1) {
            if ($allPay == $offer['offer_money']){
                $temp_update = array(
                    "id" => $offer['id'],
                    "status" => 1,
                    "pay_status" => 2,
                    "unfreeze_time" => date("Y-m-d H:i:s",time() + 8*24*60*60)
                );
                $have_income = true;
            }
        }
        $offer_update_offer = array_merge($offer_update_offer, $temp_update);


        //计算静态和动态收益
        $jing_income_insert = array();
        $jing_income_update = array();
        $dyna_wallet_update = array();
        $dyna_income_insert = array();

        if ($have_income) {
            //静态收益
            $wallet = Db::name('pay_list')->where('userid', $notes_info['offer_userid'])->find();
            if (!$wallet){
                return $this->error("2007","用户钱包信息有误");
            }

            $rate_arr = array_merge(array_column($haveAcceptList, 'pay_rate'), ['pay_rate' => $notes_info['pay_rate']]);
            $cur_rate = min($rate_arr);
            $dong_income = Db::name("dong_income")->where("offer_userid", $notes_info['offer_userid'])->find();
            $round = Db::name("offer")->where("user_id=".$notes_info['offer_userid']." and status=2")->count();
            if ($round > 6 && empty($dong_income)) {
                $cur_rate = 10;
            }

            $offer_money = $offer['offer_money'];
            $jing_income = $offer_money * $cur_rate / 100;
            $jing_income_update = array(
                'id' => $wallet['id'],
                'jing_money' => $wallet['jing_money'] + $offer_money + $jing_income
            );

            $jing_income_insert = array(
                "userid" => $notes_info['offer_userid'],
                "paylist_id" => $wallet['id'],
                "offer_id" => $notes_info['offer_id'],
                "jing_income" => $jing_income,
                "pay_rate" => $cur_rate,
                "create_time" => date("Y-m-d H:i:s")
            );

            //动态收益
            $fatheruser = $this->getfatheruser(["userid"=>$notes_info['offer_userid']]);

            if ($fatheruser) {

                $offer_user = $notes_info['offer_userid'];

                array_walk($fatheruser, function($item) use($offer_money, $offer_user, &$dyna_wallet_update, &$dyna_income_insert){

                    if ($item['userid']){
                        $pay_info = Db::name("pay_list")->where("userid", $item['userid'])->find();
                        if ($pay_info){
                            $dyna_wallet_update[] = array(
                                "id" => $pay_info['id'],
                                "dong_money" => $pay_info['dong_money'] + $offer_money * 5 / 100
                            );

                            $dyna_income_insert[] = array(
                                "offer_userid" => $offer_user,
                                "accept_userid"=> $item['userid'],
                                "income_money" => $offer_money * 5 / 100,
                                "create_time" => date("Y-m-d H:i:s")
                            );
                        }
                    }

                });
            }
        }

        // 启动事务
        Db::startTrans();
        try{
            //1. 确认当前收款记录
            Db::name('offer_accept_list')->update($note_update);

            //3. 更新打款进度
            Db::name('offer')->update($offer_update_offer);

            //4. 更新打款用户静态收益
            if (!empty($jing_income_update)){
                Db::name('pay_list')->update($jing_income_update);
                Db::name('jing_income')->insert($jing_income_insert);
            }

            //5. 更新打款用户上级玩家动态收益
            if (!empty($dyna_wallet_update)) {
                foreach ($dyna_wallet_update as $index => $item){
                    Db::name('pay_list')->update($item);
                    Db::name('dong_income')->insert($dyna_income_insert[$index]);
                }
            }

            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '排单繁忙，请稍后重试');
        }

        //短信通知提供帮助的人
        $offer_phone = Db::name('user')
            ->where('id', $notes_info['offer_userid'])
            ->value('phone');
        if ($offer_phone){
            $userModel = model("User");
            $userModel->sendphonecode($offer_phone, 151703);
        }

        return array(
            'code' => 200,
            "status" => 1,
            "confirm_time" => date('Y-m-d H:i:s'),
            'message' => '确认收款成功'
        );
    }

    /**
     * 后台确认匹配成立
     */
    public function confirm_notes($param){
        $notes_id=$param['notes_id'];
        $status=$param['status'];
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));

        //获取匹配信息
        $notes_info=Db::name("offer_accept_list")->where("id=$notes_id")->find();

        if(!$notes_info){
            return $this->error(2001,"参数错误");
        }

        $data=array(
            "id"=>$notes_id,
            "status"=>$status,
            "confirm_time"=>$now
        );

        // 启动事务
        Db::startTrans();
        try{
            Db::name("offer_accept_list")->update($data);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003,'系统繁忙，请稍后重试');
        }

        return array(
            'code' => 200,
            'message' => '匹配确认修改成功'
        );
    }
    /**
     * 获取上一代，和上三代
     */
    public function getfatheruser($param){
        $userid=$param['userid'];

        //当前用户的信息
        $userinfo=Db::name("user")->where("id=".$userid)->find();

        if($userinfo['inviter_id'] == 0){
            return null;
        }

        $data = array();

        //上一代
        $fatheruser=Db::name("user")->where("id=".$userinfo['inviter_id'])->find();
        $father_team_total = $this->teamCount(['userid'=>$fatheruser['id']])['direct_count'];

        if($father_team_total >= 2){

            $data[] = array(
                "num" => 3,
                "userid"=>$fatheruser['id']
            );
        }else{
            $data[] =  array(
                "num" => 3,
                "userid"=>""
            );
        }
       
        //向上第二代
        $father2user=Db::name("user")->where("id=".$fatheruser['inviter_id'])->find();
        if($father2user['inviter_id'] == 0){
//            $data[] =  array(
//                "num" => 1,
//                "userid"=>""
//            );
            return $data;
        }

        //向上第三代
        $father3user=Db::name("user")->where("id=".$father2user['inviter_id'])->find();

        $father3_team_total=$this->teamCount(['userid' =>$father3user['id'] ])['direct_count'];

        if($father3_team_total>4){
            $data[] =  array(
                "num"=>1,
                "userid"=>$father3user['id']
            );
        }else{
            $data[] =  array(
                "num"=>1,
                "userid"=>""
            );
        }
        return $data;

    }

    /**
     *  判断当前是否存在正在排单
     */
    public function offer_state($param){
        $userid=$param["userid"];

        //是否正在排单
        $offerinfo=Db::name("offer")->where("user_id=".$userid." and status = 0")->find();

        if(!$offerinfo){
            return $data=array(
                "code"=>0,
                "message"=>"当前无排单状态"
            );
        }

        //是否正在排单
        $notes_info=Db::name("offer_accept_list")->where("offer_id=".$offerinfo['id']." and status=1 and (pay_status = 0 or accept_status = 0)")->find();
        if(!$notes_info){
            return $data=array(
                "code"=>2,
                "message"=>"当前已排单，无匹配",
                "money" => $offerinfo['offer_money']
            );
        }

        $data=array(
                "code"=>1,
                "message"=>"已排单,已匹配"
            );
        return $data;
    }
    /**
     * 我的帮助
     */
    public function myhelplist($param){
        $userid=$param['userid'];

        //获取帮助信息
        $offerinfo=Db::name("offer")->where("user_id=$userid and status = 0")->find();
        if(empty($offerinfo)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        //获取匹配信息
        $notes_info=Db::name("offer_accept_list")->where("offer_id=".$offerinfo['id']." and status=1")->field("id,offer_userid,accept_userid,help_money,pay_status,create_time,accept_status,accept_time")->select();
        if(empty($notes_info)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        foreach ($notes_info as $key => $val) {
            if($val['accept_userid']==0){
                //系统平台的账户信息
                $accept_userinfo=Db::name("paymeng_admin")->field("phone,payment as zfbname")->where("is_play=1")->find();
            }else{
                $accept_userinfo=Db::name("user")->where("id=".$val['accept_userid'])->field("phone,zfbname,card,card_address")->find();
            }
            $notes_info[$key]['phone']=$accept_userinfo['phone'];
            $notes_info[$key]['zfbname']=$accept_userinfo['zfbname']?$accept_userinfo['zfbname']:'';
            $notes_info[$key]['card']=$accept_userinfo['card']?$accept_userinfo['card']:'';
            $notes_info[$key]['card_address']=$accept_userinfo['card_address']?$accept_userinfo['card_address']:'';
            $notes_info[$key]['offer_money']=$offerinfo['offer_money'];
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$notes_info
        );
        return $result;
    }
    /**
     * 生成二维码
     * 名字 name
     * 链接 addr
     */
    public function create_qrcode($param){
        $userid=$param['userid'];
        // $addr=$param['addr'];
        
        //获取用户的信息
        $userinfo=Db::name("user")->where("id=$userid")->find();

        if(!$userinfo){
            return $this->error("2003","参数错误");
        }

        $name=$userinfo['phone'];
        $addr="http://192.168.0.104:8082/#/pages/login-reg/reg/reg?phone=".$name;
        
        if(!$name || !$addr){
            return $this->error("2001","参数错误");
        }

        $path=$this->create_qrcodes($name,$addr);

        if(!$path){
            return $this->error("2005","二维码生成失败");
        }

        //添加数据库
        $data=array(
            "id"=>$userinfo['id'],
            "qrcode"=>$path
        );
        //检查是否已经添加
        $is_exite=Db::name("user")->where($data)->find();
        if($is_exite){
            return array(
                "code"=>200,
                "message"=>"获取成功",
                "body"=>array(
                    "userid"=>$userid,
                    "path"=>$path
                )
            );
        }
        $result=Db::name("user")->update($data);
        if(!$result){
            return $this->error("2007","二维码添加失败");
        }
        $data=array(
            "code"=>200,
            "message"=>"二维码生成成功",
            "body"=>array(
                "userid"=>$userid,
                "path"=>$path
            )
        );
        return $data;
    }
    /**
     * 生成币种充值地址二维码并返回图片路径
     * @param  string $symbol 币种
     * @param  string $addr   充值地址
     * @return string
     */
    public function create_qrcodes($symbol,$addr)
    {
        if (!$addr) {
            return '';
        }

        $path = ROOT_PATH . 'public'  . DS . 'assets' . DS . 'temp' . DS . 'qrcode';
        if (!is_dir($path)) {
            // 若目录不存在则创建之
            mkdir($path, 0777, true);
        }

        vendor('phpqrcode.phpqrcode');
        $outfile = $path . DS . "{$symbol}.jpg";
        $level   = 'L';
        $size    = 7.6;
        $QRcode  = new \QRcode();
        ob_start();
        $QRcode->png($addr, $outfile, $level, $size, 2);
        ob_end_clean();

        $start = strpos($outfile, 'assets' . DS . 'temp');
        return str_replace(DS, '/', substr($outfile, $start));
    }
    /**
     * 动态钱包
     */
    public function dong_wallet($param){
        $userid=$param['userid'];

        if(!$userid){
            return $this->error("2001","参数错误");
        }

        //累计动态收益
        $dong_income_info=Db::name("dong_income")->where("accept_userid=$userid")->select();
        //我的团队总人数
        $myteam_total=$this->teamCount(["userid"=>$userid])['total'];
        
        $num=0;
        foreach ($dong_income_info as $key => $val) {
            # code...
            $num+=$val['income_money'];
        }

        $data=array(
            "dong_income"=>$num?$num:0,
            "myteam_total"=>$myteam_total
        );

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$data
        );

        return $result;
    }

    /**
     * 排单绿色通道
     */
    public function green_channel($param){
        $offer_money=$param['offer_money'];
        $userid=$param['userid'];
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));

        if(!$offer_money){
            return $this->error("2007","参数不能为空");
        }

        /**
         * 绿色通道排单人数限制
         */
        $green_num=Db::name("system_num")->where("id=1")->value("green_num");
        if(!$green_num){
            return $this->error("20012","绿色通道暂未开放");
        }  

        $begin_time=strtotime(date('Y-m-d',strtotime(date('Y-m-d'))));
        $num=0;

        //获取今天绿色通道排单人数
        $green_list=Db::name("green_channel")->where("is_finish=0")->select();
        if($green_list){
            foreach ($green_list as $key => $val) {
                # code...
                if(strtotime($val['create_time']) > $begin_time && strtotime($val['create_time']) < time()){
                    $num+=1;
                }
            }
            if($num>$green_num || $num == $green_num){
                return $this->error("20013","今日绿色通道抢单结束");
            }
        }

        //已完成的排单
        $offerinfo=Db::name("offer")->where("user_id=$userid and status=2")->select();
        //所有需要帮助的信息
        $accept_list=Db::name("accept_list")->where("is_finish = 0")->select();
        //是否存在未完成的排单
        $green_channel_info=Db::name("green_channel")->where("user_id=$userid and is_finish=0")->find();

        //已完成两次匹配
        if(count($offerinfo) < 2){
            return $this->error("2001","会员未完成两次排单，暂时不能参与绿色通道抢单");
        }
        //前一次是否结束
        // $green_date=strtotime($green_channel_info['unfreeze_time'])-time();
        if($green_channel_info){
            return $this->error("2003","有未完成的交易");
        }
        if(!$accept_list){
            return $this->error("20013","暂无抢单");
        }else{
            foreach ($accept_list as $k => $v) {
                # code...
                if($v['userid'] == $userid){
                    unset($accept_list[$k]);
                }
            }
            if(count($accept_list) == 0){
                return $this->error("20013","暂无抢单");
            }
        }

        //添加绿色通道表单
        $green_data=array(
            "user_id"=>$userid,
            "offer_money"=>$offer_money,
            "create_time"=>$now
        );
        $res=Db::name("green_channel")->insert($green_data);
        if(!$res){
            return $this->error("2005","系统错误");
        }

        //获取添加的信息
        $green_info=Db::name("green_channel")->where($green_data)->find();

        //排单
        foreach ($accept_list as $key => $val) {
            # code...
            $num=$green_info['offer_money']-$val['money'];
            if($num>0){
                //添加记录表单
                $data=array(
                    "offer_userid"=>$green_info['user_id'],
                    "accept_userid"=>$val['userid'],
                    "offer_id"=>$green_info['id'],
                    "accept_id"=>$val['id'],
                    "create_time"=>$now,
                    "help_money"=>$accept_list[$key]['money'],
                    "green_channel"=>1
                );

                Db::name("offer_accept_list")->insert($data);
                //动态修改offer表单help_money
                $help_money=$green_info['offer_money']-$accept_list[$key]['money'];
                Db::name("green_channel")->where("id=".$green_info['id'])->update(array("help_money"=>$help_money));

                $accept_list[$key]['money']=0;
                $green_info['offer_money']=$num;
            }else{
                //添加记录表单
                $data=array(
                    "offer_userid"=>$green_info['user_id'],
                    "accept_userid"=>$val['userid'],
                    "offer_id"=>$green_info['id'],
                    "accept_id"=>$val['id'],
                    "create_time"=>$now,
                    "help_money"=>$green_info['offer_money'],
                    "green_channel"=>1
                );

                Db::name("offer_accept_list")->insert($data);
                //动态修改offer表单help_money
                $help_money=$green_info['offer_money']-$offer_money;
                Db::name("green_channel")->where("id=".$green_info['id'])->update(array("help_money"=>$help_money));
                
                $green_info['offer_money']=0;
                $accept_list[$key]['money']=$accept_list[$key]['money']-$offer_money;
                break;
            }
        }

        //多余的钱打给平台
        if($green_info['offer_money'] > 0){
            //添加记录表单
            $data=array(
                "offer_userid"=>$green_info['user_id'],
                "accept_userid"=>0,
                "offer_id"=>$green_info['id'],
                "accept_id"=>0,
                "create_time"=>$now,
                "help_money"=>$green_info['offer_money'],
                "green_channel"=>1
            );

            Db::name("offer_accept_list")->insert($data);
            //动态修改offer表单help_money
            Db::name("green_channel")->where("id=".$green_info['id'])->update(array("help_money"=>$offer_money));
        }

        $result=array(
            "code"=>200,
            "message"=>"排单成功"
        );

        return $result;
    }
    /**
     * 我的接受帮助列表
     */
    public function myacceptlist($param){
        $userid=$param['userid'];

        //获取帮助信息
        $acceptinfo=Db::name("accept_list")->where("userid=$userid and is_finish=0")->find();

        if(empty($acceptinfo)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        //获取匹配信息
        $notes_info=Db::name("offer_accept_list")->where("accept_id=".$acceptinfo['id']." and status=1")->field("id,offer_userid,accept_userid,help_money,pay_status,create_time,accept_status,accept_time")->select();
        if(empty($notes_info)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        foreach ($notes_info as $key => $val) {
            if($val['accept_userid'] == 0){
                $accept_userinfo=Db::name("payment_admin")->where("is_play=1")->find();
            }else{
                $accept_userinfo=Db::name("user")->where("id=".$val['offer_userid'])->field("phone,zfbname,card,card_address")->find();
            }
            // $accept_userinfo=Db::name("user")->where("id=".$val['offer_userid'])->field("phone,zfbname,card,card_address")->find();
            $notes_info[$key]['phone']=$accept_userinfo['phone'];
            $notes_info[$key]['zfbname']=$accept_userinfo['zfbname']?$accept_userinfo['zfbname']:'';
            $notes_info[$key]['card']=$accept_userinfo['card']?$accept_userinfo['card']:'';
            $notes_info[$key]['card_address']=$accept_userinfo['card_address']?$accept_userinfo['card_address']:'';
            $notes_info[$key]['offer_money']=$acceptinfo['money'];
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$notes_info
        );
        return $result;
    }

    /**
     * 接受帮助状态判断
     */
    public function accept_state($param){
        $userid=$param["userid"];

        //接受帮助记录
        $accept_info=Db::name("accept_list")->where("userid=$userid and is_finish = 0")->find();
        if(!$accept_info){
            return array(
                "code"=>0,
                "message"=>"没有接受帮助的记录"
            );
        }

        //匹配记录
        $notes_info=Db::name("offer_accept_list")->where("accept_userid = $userid and status = 1 and accept_status = 0")->find();
        if(!$notes_info){
            return array(
                "code"=>2,
                "message"=>"交易正在匹配中",
                "money" => $accept_info['money']
            );
        }else{
            return array(
                "code"=>1,
                "message"=>"存在匹配帮助的记录"
            );
        }
    }
    /**
     *   拒绝收款
     */
    public function refuse_accept($param){
        $notes_id=$param['notes_id'];

        if(!$notes_id){
            return $this->error("2001","参数错误");
        }

        //获取匹配信息
        $notes_info = Db::name("offer_accept_list")->where("id=$notes_id and status=1 and pay_status=1 and accept_status = 0")->find();

        if(!$notes_info){
            return $this->error("2015","当前交易不存在");
        }

        //申请疑问订单
        $data=array(
            "id"=>$notes_id,
            "question_order"=>1,
            "question_time"=>date("Y-m-d H:i:s", time())
        );

        $result=Db::name("offer_accept_list")->update($data);

        if(!$result){
            return $this->error("2003","提交失败");
        }
        return array(
            "code"=>200,
            "message"=>"申请提交成功"
        );
    }
    /**
    *   超时收款  定时器
     */
    public function overtime_accept(){
        //获取所有的符合条件的匹配记录
        $notes_info=Db::name("offer_accept_list")->field("id,pay_time")->where("pay_status=1 and accept_status = 0 and question_order = 0")->select();

        foreach ($notes_info as $key => $val){
            $pay_time=strtotime($val['pay_time'])+6*60*60;
            if(time() > $pay_time){
                //确认收款
                $result=$this->accept_gather(['notes_id'=>$val['id']]);
                
            }
        }
    }
    /**
    *   绿色通道状态
     *  1.没有排单0
     *  2.有排单1
     */
    public function green_channel_state($param){
        $userid=$param['userid'];

        //获取排单记录
        $green_channel_info=Db::name("green_channel")->where("user_id=".$userid." and is_finish = 0")->find();
        if(!$green_channel_info){
            //正在收益中
            $green_channel_finish=Db::name("green_channel")->where("user_id=".$userid." and is_finish = 1")->find();
            if(!$green_channel_finish){
                $data=array(
                    "code"=>0,
                    "message"=>"绿色通道没有排单记录"
                );
                return array(
                            "code"=>200,
                            "message"=>"获取成功",
                            "body"=>$data
                        );
            }
            $time=strtotime($green_channel_finish['unfreeze_time'])-time();
            if($time > 0){
                $data=array(
                    "code"=>2,
                    "message"=>"绿色通道正在收益中"
                );
                return array(
                            "code"=>200,
                            "message"=>"获取成功",
                            "body"=>$data
                        );
            }else{
                //正在提现中
                $green_channel_gather=Db::name("green_channel")->where("user_id=".$userid." and is_finish = 2")->find();
                if(!$green_channel_gather){
                    $data=array(
                            "code"=>3,
                            "message"=>"没有提现记录"
                        );
                    return array(
                                "code"=>200,
                                "message"=>"获取成功",
                                "body"=>$data
                            );
                }else{
                    //提现记录
                    $green_accept_list=Db::name("accept_list")->where("userid=$userid and type=2 and offer_id=".$green_channel_gather['id'])->find();
                    if(!$green_accept_list){
                        $data=array(
                            "code"=>3,
                            "message"=>"没有提现记录"
                        );
                        return array(
                                    "code"=>200,
                                    "message"=>"获取成功",
                                    "body"=>$data
                                );
                    }else{
                        //有匹配记录
                        $notes_info=Db::name("offer_accept_list")->where("accept_id=".$green_accept_list['id']." and status=1 and accept_status = 1")->find();
                        if(!$notes_info){
                            $data=array(
                                "code"=>4,
                                "message"=>"无匹配记录，正在匹配中"
                            );
                        }else{
                            $data=array(
                                "code"=>5,
                                "message"=>"有提现记录"
                            );
                        }
                        return array(
                                    "code"=>200,
                                    "message"=>"获取成功",
                                    "body"=>$data
                                );
                    }
                }
            }
        }else{
            $data=array(
                "code"=>1,
                "message"=>"绿色通道有排单记录"
            );
            return array(
                        "code"=>200,
                        "message"=>"获取成功",
                        "body"=>$data
                    );
        }
    }
    /**
    *   绿色通道 排单记录
     */
    public function green_channel_list($param){
        $userid=$param['userid'];

        //获取绿色通道排单记录
        $green_channel_info=Db::name("green_channel")->where("user_id=".$userid." and is_finish=0")->find();
        if(!$green_channel_info){
            return array(
                "code"=>2001,
                "message"=>"绿色通道没有排单记录"
            );
        }

        //获取匹配记录
        $green_channel_list=Db::name("offer_accept_list")->where("offer_id=".$green_channel_info['id']." and green_channel = 1")->field("id,offer_userid,accept_userid,help_money,status,pay_status,accept_status")->select();

        foreach($green_channel_list as $key => $val){
            //获取用户的信息
            if($val['accept_userid'] == 0){
                $userinfo=Db::name("payment_admin")->field("phone,payment as zfbname")->where("is_play = 1")->find();
            }else{
                $userinfo=Db::name("user")->where("id=".$val['accept_userid'])->field("id,phone,zfbname,card")->find();
            }

            $green_channel_list[$key]['phone']=$userinfo['phone'];
            $green_channel_list[$key]['zfbname']=$userinfo['zfbname']?$userinfo['zfbname']:"";
            $green_channel_list[$key]['card']=$userinfo['card']?$userinfo['card']:"";
            $green_channel_list[$key]['card_address']=$userinfo['card_address']?$userinfo['card_address']:"";

        }
        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$green_channel_list
        );
    }
    /**
    *   绿色通道 提现
     */
    public function green_channel_cash($param){
        $user_id=$param["userid"];
        $offer_money=$param['offer_money'];
        $trader=$param['trader'];
        $now = date("Y-m-d H:i:s",time());

        if(!$offer_money || !$trader){
            return $this->error("20017","参数错误");
        }

        //获取用户信息
        $userinfo=Db::name("user")->where("id=$user_id and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在或者用户当前未激活",array());
        }
        //判断交易密码
        if($userinfo['trader'] != user_md5($trader)){
            return $this->error("20016","交易密码不正确");
        }

        //当前用户有已经排单完成的记录，且已经过了冻结时间
        $offerinfo=Db::name("green_channel")->where("user_id=$user_id and is_finish = 1")->find();

        if(empty($offerinfo)){
            return $this->error("2003","请先完成排单",array());
        }
        if(strtotime($offerinfo['unfreeze_time'])>strtotime($now)){
            return $this->error("2005","正在收益中，不能请求帮助",array());
        }

        //余额查询   pay_list
        $pay_info=Db::name("pay_list")->where("userid=".$user_id)->find();
        if (empty($pay_info)){
            return $this->error('2002', '获取钱包信息错误');
        }

        if($offer_money > $pay_info['green_money']){
            return $this->error("20018","绿色通道金额不足");
        }

        //是否已经添加拍单记录
        $cond['userid'] = $user_id;
        $cond['is_finish'] = 0;
        $cond['offer_id']=$offerinfo['id'];
        $cond['type'] = 2;

        $res_types = Db::name("accept_list")->where($cond)->value('type');
        
        if ($res_types){
            return $this->error("2013","绿色通道金额每轮只能提现一次",array());
        }

        $accept_insert = array(
            "userid"=>$user_id,
            "offer_id" => $offerinfo['id'],
            "money"=>$offer_money,
            "is_finish"=>0,
            "type"=>2,
            'create_time'=>date("Y-m-d H:i:s")
        );


        $wallet_update = array(
            'id' => $pay_info['id']
        );
        $wallet_update['green_money'] = $pay_info['green_money'] - $offer_money;

        $green_channel_finish=array(
            "id"=>$offerinfo['id'],
            "is_finish"=>2
        );

        // 启动事务
        Db::startTrans();
        try{
            Db::name('accept_list')->insert($accept_insert);
            Db::name('pay_list')->update($wallet_update);
            //提现状态
            Db::name("green_channel")->update($green_channel_finish);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统忙，请稍后重试');
        }

        $result=array(
            'code' => 200,
            'message' => '排单成功'
        );

        return $result;
    }
    /**
     * 绿色通道 确认收款
     */
    public function green_channel_gather($param){
        $notes_id=$param['notes_id'];
        $now = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s"),time()));

        if(!$notes_id){
            return $this->error("20013","参数错误");
        }
        //获取匹配信息
        $notes_info = Db::name("offer_accept_list")->where("id=$notes_id and status=1 and pay_status=1 and green_channel = 1")->find();

        if(!$notes_info){
            return $this->error("2015","当前交易不存在");
        }

        if($notes_info['accept_status'] == 1){
            return $this->error("2003","已经确认收款");
        }

        /**
         *接受帮助的人确认本条交易记录
         */
        $note_update = array(
            'id' => $notes_info['id'],
            'accept_status' => 1,
            'accept_time' => date('Y-m-d H:i:s')
        );

        /**
         * 接受帮助的人是否已经全部收款
         * 1.部分收款,更新have_accept_money
         * 2.全部收款，更新is_finish
         * 3.结束排单
         */
        $cond = [
            'id' => $notes_info['accept_id'],
            'is_finish' => 0
        ];
        $accept = Db::name("accept_list")->where($cond)->find();

        if (empty($accept)){
            return $this->error("2015","当前交易不存在");
        }

        $accept_money = $accept['have_accept_money'] + $notes_info['help_money'];
        if ($accept_money > $accept['money']){
            return $this->error("2005","非法交易");
        }

        $is_finished = $accept_money == $accept['money'] ? 1 : 0;
        $accept_update = array(
            "id" => $accept['id'],
            "have_accept_money" => $accept_money,
            "is_finish" => $is_finished
        );

        $accept_offer_update = array();
        if ($is_finished == 1){
            $accept_offer_update = array(
                'id' => $accept['offer_id'],
                'create_time' => date('Y-m-d H:i:s')
            );
        }

        /**
         * 提供帮助的人是否已经全部付款
         * 提供帮助的人offer更新信息
         * 1.付完20%，更新pay_status=1
         * 2.不足20%，不需要处理
         * 3.全部付完更新pay_status=2,status=1，该用户已经完成排单，需要计算本轮的静态收益和上级玩家的动态收益
         *
         *
         */
        $offer = Db::name('green_channel')->where('id', $notes_info['offer_id'])->find();

        if (empty($offer)){
            return $this->error("2015","当前交易不存在");
        }

        //本次排单已付款、已确认的接受帮助信息
        $haveAcceptList = Db::name("offer_accept_list")->where("offer_id=".$notes_info['offer_id']." and pay_status=1 and accept_status=1 and green_channel = 1")->select();
        $havePay = 0;
        if($haveAcceptList){
            $havePay = array_sum(array_column($haveAcceptList, 'help_money'));
        }

        $allPay = $havePay + $notes_info['help_money'];
        if ($allPay > $offer['offer_money']){
            return $this->error("2005","非法交易");
        }

        $offer_update_offer = array(
            "id" => $offer['id'],
            "unfreeze_time" => date("Y-m-d H:i:s",time()+5*24*60*60)
        );


        //计算静态和动态收益
        $green_income_insert = array();
        $green_income_update = array();

        //静态收益
        $wallet = Db::name('pay_list')->where('userid', $notes_info['offer_userid'])->find();
        if (!$wallet){
            return $this->error("2007","用户钱包信息有误");
        }

        $cur_rate = 10;

        $offer_money = $offer['offer_money'];
        $green_income = $offer_money * $cur_rate / 100;
        $green_income_update = array(
            'id' => $wallet['id'],
            'green_money' => $wallet['green_money'] + $offer_money + $green_income
        );

        $green_income_insert = array(
            "userid" => $notes_info['offer_userid'],
            "paylist_id" => $wallet['id'],
            "green_id" => $notes_info['offer_id'],
            "green_money" => $green_income,
            "pay_rate" => $cur_rate,
            "create_time" => date("Y-m-d H:i:s")
        );

        // 启动事务
        Db::startTrans();
        try{
            //1. 确认当前收款记录
            Db::name('offer_accept_list')->update($note_update);

            //2. 更新收款进度
            Db::name('accept_list')->update($accept_update);
            if (!empty($accept_offer_update)){
                Db::name('green_income')->update($green_income_update);
            }

            //3. 更新打款进度
            Db::name('green_channel')->update($offer_update_offer);

            //4. 更新打款用户静态收益
            if (!empty($green_income_update)){
                Db::name('pay_list')->update($green_income_update);
                Db::name('green_income')->insert($green_income_insert);
            }

            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            dump($e);die();
            return $this->error(2003, '排单繁忙，请稍后重试');
        }

        return array(
            'code' => 200,
            'message' => '确认收款成功'
        );
    }
    /**
     * 绿色通道 提现记录
     */
    public function green_channel_accept($param){
        $userid=$param['userid'];

        //获取帮助信息
        $acceptinfo=Db::name("accept_list")->where("userid=$userid and is_finish=0 and type=2")->find();

        if(empty($acceptinfo)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        //获取匹配信息
        $notes_info=Db::name("offer_accept_list")->where("accept_id=".$acceptinfo['id']." and status=1 and green_channel=1")->field("id,offer_userid,accept_userid,help_money,pay_status,create_time,accept_status,accept_time")->select();
        if(empty($notes_info)){
            return array(
                "code"=>2001,
                "message"=>"暂无交易信息"
            );
        }

        foreach ($notes_info as $key => $val) {
            if($val['accept_userid'] == 0){
                $accept_userinfo=Db::name("payment_admin")->where("is_play=1")->find();
            }else{
                $accept_userinfo=Db::name("user")->where("id=".$val['offer_userid'])->field("phone,zfbname,card,card_address")->find();
            }
            
            $notes_info[$key]['phone']=$accept_userinfo['phone'];
            $notes_info[$key]['zfbname']=$accept_userinfo['zfbname']?$accept_userinfo['zfbname']:'';
            $notes_info[$key]['card']=$accept_userinfo['card']?$accept_userinfo['card']:'';
            $notes_info[$key]['card_address']=$accept_userinfo['card_address']?$accept_userinfo['card_address']:'';
            $notes_info[$key]['offer_money']=$acceptinfo['money'];
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$notes_info
        );
        return $result;
    }
    /**
     * 绿色通道 提供帮助详情
     */
    public function green_channel_offer($param){
        $offer_id=$param['offer_id'];
        $green_channel=$param['green_channel'];

        //获取帮助记录
        $offernotes=Db::name('offer_accept_list')->where("offer_id=$offer_id and status=1 and green_channel=$green_channel")->select();

        if(!$offernotes){
            return $this->error("2001","没有交易记录");
        }

        foreach ($offernotes as $key => $val) {
            $count+=$val['help_money'];
            //获取被帮助人的信息
            if($val['accept_userid']!=0){
                $userinfo=Db::name("user")->where("id=".$val['accept_userid'])->find();
            }else{
                $userinfo=Db::name("payment_admin")->where("is_play=1")->find();
            }
            $data=array(
                // "offer_money"=>$offerinfo["offer_money"],
                "notes_id"=>$val["id"],
                "accept_phone"=>$userinfo["phone"],
                "accept_help_money"=>$val["help_money"],
                "zfbname"=>$userinfo["zfbname"]?$userinfo["zfbname"]:'',
                "card"=>$userinfo["card"]?$userinfo["card"]:'',
                "card_address"=>$userinfo["card_address"]?$userinfo["card_address"]:'',
                "pay_status"=>$val["pay_status"],
                "pay_img"=>$val["pay_img"],
                "pay_time"=>$val["pay_time"],
                "accept_status"=>$val["accept_status"],
                "accept_time"=>$val["accept_time"],
            );
            $list[$key]=$data;
        }
        foreach ($list as $k => $v) {
            $list[$k]["count"]=$count;
            # code...
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
        return $result;
    }
    /**
     * 绿色通道 接受帮助详情
     */
    public function green_channel_accepthelp($param){
        $offer_id=$param['offer_id'];
        $green_channel=$param['green_channel'];

        if(!$offer_id){
            return $this->error("2003","参数错误");
        }

        //获取帮助记录
        $offernotes=Db::name('offer_accept_list')->where("accept_id=".$offer_id." and status=1")->select();

        if(!$offernotes){
            return $this->error("2001","没有交易记录");
        }

        foreach ($offernotes as $key => $val) {
            $count+=$val['help_money'];
            //获取提供帮助人的信息
            $userinfo=Db::name("user")->where("id=".$val['offer_userid'])->find();
            $data=array(
                // "offer_money"=>$offerinfo["offer_money"],
                "notes_id"=>$val["id"],
                "accept_phone"=>$userinfo["phone"],
                "accept_help_money"=>$val["help_money"],
                "zfbname"=>$userinfo["zfbname"]?$userinfo["zfbname"]:'',
                "card"=>$userinfo["card"]?$userinfo["card"]:'',
                "card_address"=>$userinfo["card_address"]?$userinfo["card_address"]:'',
                "pay_status"=>$val["pay_status"],
                "pay_img"=>$val["pay_img"],
                "pay_time"=>$val["pay_time"],
                "accept_status"=>$val["accept_status"],
                "accept_time"=>$val["accept_time"],
            );
            $list[$key]=$data;
        }
        foreach ($list as $k => $v) {
            $list[$k]["count"]=$count;
            # code...
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
        return $result;
    }
    /**
     * 绿色通道  帮助记录
     */
    public function green_channel_helplist($param){
        $userid=$param["userid"];
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid and status=1")->find();
        if(!$userinfo){
            return $this->error("2001","用户不存在",array());
        }

        //获取提供帮助记录
        $offerhelpinfo=Db::name("offer_accept_list")->where("offer_userid=$userid and pay_status = 1")->select();
        //获取接受帮助记录
        $accepthelpinfo=Db::name("offer_accept_list")->where("accept_userid=$userid and pay_status = 1")->select();

        //数组处理 提供帮助 接受帮助
        if($offerhelpinfo){
            $res = [];
            foreach ($offerhelpinfo as $k => $v) {
                $res[$v['offer_id']][] = $v;
            }
            $data=array_values($res);
            foreach ($data as $key => $val) {
                $offer_list[$key]['count']=count($val);
                $count=0;
                foreach ($val as $k => $v) {
                    //获取帮助信息
                    if($v['green_channel']==0){
                        $offerinfo=Db::name("offer")->where("id=".$v['offer_id'])->find();
                    }else{
                        $offerinfo=Db::name("green_channel")->where("id=".$v['offer_id'])->find();
                    }
                    $count+=$v['help_money'];
                }
                $offer_list[$key]['offer_id']=$offerinfo['id'];
                $offer_list[$key]['offer_money']=$count;
                $offer_list[$key]['create_time']=$offerinfo['create_time'];
                $offer_list[$key]['green_channel']=$v['green_channel']?$v['green_channel']:0;
            }
        }

        if($accepthelpinfo){
            $arr = [];
            foreach ($accepthelpinfo as $k => $v) {
                $arr[$v['accept_id']][] = $v;
            }
            $data=array_values($arr);
            foreach ($data as $key => $val) {
                $accept_list[$key]['count']=count($val);
                $counts=0;
//                foreach ($val as $k => $v) {
//                    //获取帮助信息
//                    if($v['green_channel']==0){
//
//                        $offerinfo=Db::name("offer")->where("id=".$v['offer_id'])->find();
//                    }else{
//                        $offerinfo=Db::name("green_channel")->where("id=".$v['offer_id'])->find();
//                    }
//                    $acceptinfo=Db::name('accept_list')->where('id='.$v['accept_id'])->find();
//                    $counts+=$v['help_money'];
//                }
                $acceptinfo=Db::name('accept_list')->where('id='.$val[0]['accept_id'])->find();
                $accept_list[$key]['offer_id']=$acceptinfo['id'];
                $accept_list[$key]['offer_money']=$acceptinfo['money'];
                $accept_list[$key]['create_time']=$acceptinfo['create_time'];
//                $accept_list[$key]['green_channel']=$val[0]['green_channel']?$v['green_channel']:0;
            }            
        }

        $result=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>array(
                "offer_list"=>$offer_list?$offer_list:array(),
                "accept_list"=>$accept_list?$accept_list:array()
            )
        );
        return $result;
    }
    /**
     * 静态收益账单
     */
    public function jing_wallet_list($param){
        $userid=$param['userid'];

        //获取静态流水记录
        $wallet_list=Db::name("jing_income")->where("userid=$userid")->select();
        if(!$wallet_list){
            return $this->error("2001","暂时没有静态收益");
        }

        foreach ($wallet_list as $key => $val) {
            # code...
            //获取offer信息
            $offerinfo=Db::name("offer")->where("id=".$val['offer_id'])->find();
            $wallet_list[$key]['offer_money']=$offerinfo['offer_money'];
        }
        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$wallet_list
        );

    }
    /**
     * 匹配结果列表
     */
    public function getallnotes($param){
//        $page=$param['page']?$param['page']:0;
//        $size=$param['size']?$param['size']:5;
//        $size_num=$page*$size;

        $phone_offer = $param['offer_phone'];
        $phone_accept = $param['accept_phone'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? 20 : $param['limit'];

        $where = [];
        if ($phone_offer) {
            $where['b.phone'] = $phone_offer;
        }if ($phone_accept) {
            $where['c.phone'] = $phone_accept;
        }

        $count = Db::name('offer_accept_list')
            ->alias('a')
            ->join('t_user b', 'a.offer_userid=b.id')
            ->join('t_user c', 'a.accept_userid=c.id')
            ->where($where)
            ->whereTime('a.create_time', 'today')
            ->count();

        $list = Db::name('offer_accept_list')
            ->alias('a')
            ->join('t_user b', 'a.offer_userid=b.id')
            ->join('t_user c', 'a.accept_userid=c.id')
            ->field('a.id,
            b.phone as offer_phone, b.realname as offer_name,
            c.phone as accept_phone, c.realname as accept_name,
            a.status,a.confirm_time,a.pay_status,a.pay_time,a.pay_img,a.help_money,
            a.accept_status, a.accept_time, a.green_channel')
            ->where($where)
            ->whereTime('a.create_time', 'today')
            ->page($page, $limit)
            ->select();

//        $count=Db::name("offer_accept_list")->count();
//        $page_size=ceil($count/$size);
//
//        //获得所有列表   status倒叙
//        $notes_info=Db::name("offer_accept_list")->field("id,offer_userid,accept_userid,status,help_money")->limit($size_num,$size)->order("create_time desc")->select();
//
//        if(!$notes_info){
//            return $this->error("2001","暂时没有匹配记录");
//        }
//
//        foreach ($notes_info as $key => $val) {
//            # code...
//            $offerinfo=$this->getuserinfo($val['offer_userid']);
//            $acceptinfo=$this->getuserinfo($val['accept_userid']);
//            $notes_info[$key]['offer_phone']=$offerinfo['phone'];
//            $notes_info[$key]['offer_username']=$offerinfo['username'];
//            $notes_info[$key]['offer_realname']=$offerinfo['realname'];
//            $notes_info[$key]['accept_phone']=$acceptinfo['phone'];
//            $notes_info[$key]['accept_username']=$acceptinfo['username'];
//            $notes_info[$key]['accept_realname']=$acceptinfo['realname'];
//
//        }

        $data=array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>array(
                "count"=>$count,
//                "page_size"=>$page_size,
                "list"=>$list
            )
        );

        return $data;
    }
    /**
     * 获取用户信息
     */
    public function getuserinfo($userid){
        if($userid==0){
            $payment=Db::name("payment_admin")->where("is_play=1")->find();
            return array(
                "phone"=>$payment['phone'],
                "username"=>"系统平台",
                "realname"=>"系统平台",
                "head"=>""
            );
        }
        //获取用户信息
        $userinfo=Db::name("user")->where("id=$userid")->field("phone,username,realname,head")->find();
        if(!$userinfo){
            return $this->error("2005","用户不存在");
        }

        return $userinfo;
    }
    /**
     * 今日进场人数  累计进场人数   今日出场人数  今日出场资金
     */
    public function getallnums(){
        $begin_time = strtotime(date("Y-m-d"),time());
        $time=time();

        //累计进场人数
//        $offer_count=Db::name("offer")->count();

        //进场20%
        $offer_20 = Db::name("offer")->where("status = 0 and pay_status = 0 ")->select();

        //进场80%
        $offer_80 = Db::name('offer')
            ->alias('a')
            ->where(function($query){
                $query->name('offer b')->where('b.user_id=a.user_id and b.status=1 and b.pay_status=2');
            }, 'not exists')->where('a.status=0 and a.pay_status=1')
            ->select();

        $offer_20_num = empty($offer_20) ? 0 : count($offer_20);
        $offer_80_num = empty($offer_80) ? 0 : count($offer_80);

        $offer_20_money = 0;
        if ($offer_20_num){
            $offer_20_money = array_sum(array_column($offer_20, 'offer_money')) * 0.2;
        }

        $offer_80_money = 0;
        if ($offer_80_num){
            $offer_80_money = array_sum(array_column($offer_80, 'offer_money')) * 0.8;
        }

//        //今日排单人数
//        $offer_num=0;
//        $offer_money_count=0;
//        $offer_list=Db::name("offer")->where("status = 0 and pay_status = 0 ")->select();
//        if($offer_list){
//            foreach ($offer_list as $key => $val) {
//                # code...
//                if(strtotime($val['create_time']) > $begin_time  && strtotime($val['create_time']) < $time){
//                    $offer_num+=1;
//                    $offer_money_count+=$val['offer_money'];
//                }
//            }
//        }

        //今日出场人数

        $accept_list = Db::name("accept_list")->where("is_finish = 0")->select();
        $accept_num = empty($accept_list) ? 0 : count($accept_list);
        $accept_money_count = 0;
        if ($accept_num){
            $accept_money_count = array_sum(array_column($accept_list, 'money')) - array_sum(array_column($accept_list, 'have_accept_money'));
        }

//        if($accept_list){
//            foreach ($accept_list as $key => $val) {
//                # code...
//                if(strtotime($val['create_time']) > $begin_time  && strtotime($val['create_time']) < $time){
//                    $accept_num+=1;
//                    $accept_money_count+=$val["money"];
//                }
//            }
//        }

        $data=array(
//            "offer_count"=>$offer_count?$offer_count:0,
            "offer_num"=> $offer_20_num + $offer_80_num,
            "offer_money_count"=>$offer_20_money + $offer_80_money,
            "accept_num"=>$accept_num,
            "accept_money_count"=>$accept_money_count
        );

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$data
        );
    }
    /**
     * 后台确认订单
     */
    public function confirm_status($param){
//        $userid=$param["userid"];
        $notes_id=$param['notes_id'];

//        $userinfo=$this->getuserinfo($userid);
//        if(!$userinfo){
//            return $userinfo;
//        }

        //获取匹配订单
        $notes_info=Db::name("offer_accept_list")->where("id=$notes_id")->find();
        if(!$notes_info){
            return $this->error("2003","没有此订单");
        }

        if($notes_info['status']==1){
            return $this->error("2005","请不要重复修改");
        }

        $data=array(
            "id"=>$notes_id,
            "status"=>1,
            "confirm_time"=>date("Y-m-d H:i:s")
        );

        $result=Db::name("offer_accept_list")->update($data);

        if(!$result){
            return $this->error("2006","系统错误");
        }

        //短信通知提供方和接受方
        $user_list = Db::name('user')
            ->whereIn('id', [$notes_info['offer_userid'], $notes_info['accept_userid']])
            ->field('phone')
            ->select();
        if ($user_list){
            $list = array_column($user_list, 'phone');
            $userModel = model("User");

            foreach ($list as $user){
                $userModel->sendphonecode($user, 151703);
            }
        }


        return array(
            "code"=>200,
            "message"=>"修改成功",
            "status" => 1,
            "confirm_time" => date("Y-m-d H:i:s")
        );
    }

    /**
     * 修改提供帮助时间
     */
    public function change_offer_time($param){
        $offer_id=$param["offer_id"];
        $type=$param['type']?$param['type']:0;

        if(!$offer_id){
            return $this->error("2001","参数错误");
        }

        $offer_info=Db::name("offer")->where("id=$offer_id")->find();

        if(!$offer_info){
            return $this->error("2003","参数错误");
        }
        if($type==0){
            //offer  创建时间
            $create_time=date("Y-m-d H:i:s",strtotime($offer_info['create_time'])-24*60*60);

            $create_data=array(
                "id"=>$offer_info['id'],
                "create_time"=>$create_time
            );
        }else{
            //冻结时间
            $unfreeze_time=date("Y-m-d H:i:s",strtotime($offer_info['unfreeze_time'])-24*60*60);

            $create_data=array(
                "id"=>$offer_id,
                "unfreeze_time"=>$unfreeze_time
            );
        }
        Db::name("offer")->update($create_data);

        return array(
            "code"=>200,
            "message"=>"修改成功",
            "confirm_time" => $create_time
        );
    }
    /**
     * 修改接受帮助时间
     */
    public function change_accept_time($param){
        $accept_id=$param["accept_id"];

        if(!$accept_id){
            return $this->error("2001","参数错误");
        }

        $accept_info=Db::name("accept_list")->where("id=$accept_id")->find();
        if(!$accept_info){
            return $this->error("2003","参数错误");
        }

        //offer  创建时间
        $create_time=date("Y-m-d H:i:s",strtotime($accept_info['create_time'])-24*60*60);

        $create_data=array(
            "id"=>$accept_id,
            "create_time"=>$create_time
        );
        Db::name("accept_list")->update($create_data);

        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }
    /**
     * 修改绿色通道时间
     */
    public function change_green_time($param){
        $green_id=$param["green_id"];
        $type=$param['type']?$param['type']:0;

        if(!$green_id){
            return $this->error("2001","参数错误");
        }

        $green_info=Db::name("green_channel")->where("id=$green_id")->find();

        if(!$green_info){
            return $this->error("2003","参数错误");
        }
        if($type==0){
            //offer  创建时间
            $create_time=date("Y-m-d H:i:s",strtotime($green_info['create_time'])-24*60*60);

            $create_data=array(
                "id"=>$green_id,
                "create_time"=>$create_time
            );
        }else{
            //冻结时间
            $unfreeze_time=date("Y-m-d H:i:s",strtotime($green_info['unfreeze_time'])-24*60*60);

            $create_data=array(
                "id"=>$green_id,
                "unfreeze_time"=>$unfreeze_time
            );
        }
        Db::name("green_channel")->update($create_data);

        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }

    public function getSystemNum(){
        return array(
            "code"=>200,
            "message"=>"修改成功",
            "body" => Db::name('system_num')->select()
        );
    }

    public function updateSystemNum($param){

        $offer = empty($param['offer']) ? 0 : $param['offer'];
        $green = empty($param['green']) ? 0 : $param['green'];
        $lottery = empty($param['lottery']) ? 0 : $param['lottery'];

        Db::name('system_num')->where('id', 1)->update([
            'offer_num' => $offer,
            'green_num' => $green,
            'lottery_count' => $lottery
        ]);
        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }
}