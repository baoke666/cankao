<?php
// +----------------------------------------------------------------------
// | Description: 规则
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\api\model;

use app\api\model\Common;
use app\common\library\Token;
use think\Cache;
use think\Config;
use think\Db;
use com\verify\HonrayVerify;
use think\Request;
use think\Controller;

class Order extends Common 
{
    /**
     * 错误返回
     */
    public function error($errorcode,$message,$data=[]){
        $result=array(
            "code"=>$errorcode,
            "message"=>$message,
            "body"=>$data,
        );
        return $result;
    }

    /**
     * 模板列表
     * 分页
     */
    public function template_list($param=""){
        $page=intval($param['page'])?intval($param['page']):1;
        $size=intval($param['size'])?intval($param['size']):10;
        $begin=($page-1)*$size;
        $end=$page*$size;

        //获取
        $list=Db::name("product_template")->field("id,serial_num,name")->where("status=0")->limit($begin,$end)->select();
        
        foreach ($list as $key => $val) {
            $money=0;
            $info=Db::name("product_parts")
                ->alias("a")
                ->join("t_parts b","a.parts_id = b.id")
                ->where(["a.serial_id" => $val['id']])
                ->field("a.id,a.amount,b.price")
                ->select();
            if($info){
                foreach ($info as $k => $v) {
                    $money+=$v['amount']*$v['price'];
                }
            }
            $list[$key]['money']=$money;
        }
        
        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$list
        );
    }

    /**
     * [getDataList] 添加模板                    
     */
    public function add_template($param="")
    {
        $serial_num=$param["serial_num"];
        $name=trim($param["name"]);
        $parts=$param["parts"];
        $parts=json_decode($parts,true);

        if(!$serial_num || !$name || !$parts){
            return $this->error("10011","参数错误");
        }

        $template=array(
            "serial_num"=>$serial_num,
            "name"=>$name
        );

        //验证重复添加
        $template_info=Db::name("product_template")->where($template)->find();
        if($template_info){
            return $this->error("10012","请不要重复添加");
        }

        //添加数据库
        $res=Db::name('product_template')->insert($template);
        if(!$res){
            return $this->error("10013","添加失败"); 
        }

        $info=Db::name("product_template")->where($template)->find();

        //整件库存
        $stock=array(
            "type"=>1,
            "serial_id"=>$info["id"],
            "amount"=>0,
            "create_time"=>date("Y-m-d H:i:s")
        );
        $date=array();
        $list=array();
        foreach ($parts as $key => $val) {
            # code...
            $date[$key]['serial_id']=$info['id'];
            $date[$key]['parts_id']=$val['id'];
            $date[$key]['status']=0;
            //配件库存
            $is_exite=Db::name("product_stock")->where("serial_id=".$val["id"]." and type=2")->find();
            if(!$is_exite){
                $list[$key]["type"]=2;
                $list[$key]["serial_id"]=$val["id"];
                $list[$key]["amount"]=0;
                $list[$key]["create_time"]=date("Y-m-d H:i:s");
            }
        }

        // 启动事务
        Db::startTrans();
        try{
            Db::name('product_parts')->insertAll($date);
            Db::name('product_stock')->insert($stock);
            Db::name('product_stock')->insertAll($list);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            'code' => 200,
            'message' => '添加成功'
        );
    }

    /**
     * 搜索部件
     */
    public function search_parts($param=""){
        $keywords=trim($param['keywords']);
        if(!$keywords){
           return $this->error("10001","请输入有效字符");
        }

        $result=Db::name("parts")->where("(name like '%".$keywords."%') or (serial_num like '%".$keywords."%')")->select();

        if(!$result){
           return $this->error("10002","未找到搜索的内容");
        }
        return $data=array(
            "code"=>200,
            "message"=>"搜索成功",
            "body"=>$result
        );
    }

    /**
     * 删除模板  （单个模板）
     */
    public function del_template($param=""){
        $serial_id=$param['serial_id'];

        if(!$serial_id){
            return $this->error("10001","请选择删除的模板");
        }


        // 启动事务
        Db::startTrans();
        try{
            //原材料
            Db::name('product_template')->where("id = $serial_id")->delete();
            //原材料配件
            Db::name("product_parts")->where("serial_id = $serial_id")->delete();
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"删除成功"
        );
    }

    /**
     * 添加订单  production_order
     * 分车间  wokeshop
     * 排产   parts_order
     */
    public function add_orders($param=""){
        $data['type']=$type=$param['type']?$param['type']:"1";
        $data['serial_id']=$serial_id=$param['serial_id'];
        $data['name']=$name=trim($param['name']);
        $data['spec']=$spec=$param['spec'];
        $data['number']=$number=intval($param['number']);
        $data['planned_delivery_time']=$planned_delivery_time=$param['planned_delivery_time'];
        // $data['create_time']=$create_time="2019-05-14 18:35:49";
        $data['create_time']=$create_time=date("Y-m-d H:i:s",time());

        if(!$name || !$spec || !$number || !$planned_delivery_time || !$serial_id){
            return $this->error("10001","参数错误");
        }

        unset($param['userid']);
        //验证是否重复添加
        $result=Db::name("production_order")->where($param)->find();
        if($result){
            return $this->error("10002","请不要重复添加");
        }
        //验证模板是否存在
        $template_info=Db::name("product_template")->where("id=$serial_id")->find();
        if(!$template_info){
            return $this->error("10003","模板参数错误");
        }

        //添加订单
        $res=Db::name("production_order")->insert($data);
        if(!$res){
            return $this->error("10004","添加失败");
        }
        
        //获取添加信息
        $info=Db::name("production_order")->where($data)->find();

        //分车间(一车间，二车间)
        $num1=intval($number/2);
        if($num1==$number/2){
           $num2=$num1; 
        }else{
            $num2=$num1+1;
        }
        //获取配件信息
        $parts=Db::name('product_template')
                ->alias('m')
                ->join("t_product_parts a", 'm.id = a.serial_id')
                ->where("m.id=$serial_id")
                ->field('a.parts_id,a.amount')
                ->select();
        $workshop1=$parts;
        $workshop2=$parts;
        foreach ($workshop1 as $key => $val) {
            # code...
            $workshop1[$key]['order_id']=$info['id'];
            $workshop1[$key]['workshop']=1;
            $workshop1[$key]['amount']=$val['amount']*$num1;
            $workshop2[$key]['order_id']=$info['id'];
            $workshop2[$key]['workshop']=2;
            $workshop2[$key]['amount']=$val['amount']*$num2;
        }

        // 启动事务
        Db::startTrans();
        try{
            //排产
            Db::name('parts_order')->insertAll($workshop1);
            Db::name('parts_order')->insertAll($workshop2);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"订单添加成功"
        );
    }

    /**
     * 搜索模板
     */
    public function search_template($param=""){
        $keywords=trim($param['keywords']);

        if(!$keywords){
            return $this->error("10001","参数错误");
        }

        //查询
        $result=Db::name("product_template")->field("id,serial_num,name")->where("(serial_num like '%".$keywords."%') or (name like '%".$keywords."%') and status=0")->select();

        if(!$result){
            return $this->error("10002","未找到搜索的内容");
        }

        return array(
            "code"=>200,
            "message"=>"搜索成功",
            "body"=>$result
        );
    }

    /**
     * 模板信息获取（单个）
     */
    public function getOneTemplate($param){
        $template_id=$param["template_id"];

        if(!$template_id){
            return $this->error("10001","参数错误");
        }

        //获取模板信息
        $template_info=Db::name("product_template")->where("id=$template_id")->find();

        if(!$template_id){
             return $this->error("10002","模板信息错误");
        }

        //获取配件信息
        $parts_info=Db::name("product_parts")
                    ->alias("a")
                    ->join("parts b","a.parts_id=b.id")
                    ->where("a.serial_id=$template_id and a.status=0")
                    ->field("a.id,b.name,b.serial_num,a.amount,a.type")
                    ->select();

        if(!$parts_info){
            return $this->error("10003","配件信息获取错误");
        }

        $template_info["parts"]=$parts_info;

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$template_info
        );
    }

    /**
     * 编辑模板
     */
    public function changeTemplate($param){
        $template["id"]=$id=$param['id'];
        $template["name"]=$name=$param['name'];
        $template["serial_num"]=$serial_num=$param['serial_num'];
        $parts=$param["parts"];

        if(!$id || !$name || !$serial_num || !$parts){
            return $this->error("10001","参数错误");
        }

        foreach ($parts as $key => $val) {
            unset($parts[$key]["name"]);
            unset($parts[$key]["serial_num"]);
        }

        // 启动事务
        Db::startTrans();
        try{
            //模板
            Db::name("product_template")->update($template);
            //配件
            foreach ($parts as $key => $val) {
               Db::name("product_parts")->update($val);
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }

    /**
     * 订单列表
     */
    public function order_list($param=""){
        $page=intval($param['page'])?intval($param['page']):1;
        $size=intval($param['size'])?intval($param['size']):10;
        $begin=($page-1)*$size;
        $end=$page*$size;

        //库存
        $stockInfo=Db::name("product_stock")->field("serial_id,amount")->where("type=1")->select();
        $stockId=array_column($stockInfo,"serial_id");
        $stockInfo=array_column($stockInfo,"amount","serial_id");

        //获取
        $list=$this->getallorders($begin,$end);

        foreach ($list as $key => $val) {
            if(in_array($val["serial_id"], $stockId)){
                $num=$stockInfo[$val["serial_id"]]+$val["stock_num"]-$val["number"];
                if($num < 0){
                    $list[$key]["amount"]=$stockInfo[$val["serial_id"]];
                    $stockInfo[$val["serial_id"]]=0;
                }elseif($num == 0){
                    $list[$key]["amount"]=$stockInfo[$val["serial_id"]];
                    $stockInfo[$val["serial_id"]]=0;
                }elseif($num > 0){
                    $list[$key]["amount"]=$val["number"]-$val["stock_num"];
                    $stockInfo[$val["serial_id"]]=$num;
                }
            }else{
                $list[$key]["amount"]=0;
            }
        }

        return array(
                "code"=>200,
                "message"=>"获取成功",
                "body"=>$list
            );
    }

    /**
     * 获取所有订单
     */
    public function getallorders($begin,$end){
        $list=Db::name("production_order")
            ->alias("a")
            ->join("t_product_template c","a.serial_id=c.id","left")
            ->where("c.status=0")
            ->field("a.id,a.name,a.spec,a.serial_id,c.serial_num,a.number,a.planned_delivery_time,a.real_delivery_time,a.status,a.delivery_status,a.stock_num,a.list")
            // ->limit($begin,$end)
            ->order("a.list desc , a.planned_delivery_time asc,a.create_time asc")
            ->select();
        // return Db::name("production_order")->getlastsql();
        return $list;
    }

    /**
     * 获取所有订单
     * 当月
     */
    public function getallorder($begin,$end){
        $date1=date("Y-m-d",time());
        $date2=explode("-", $date1);
        //当月一号
        $date4[0]=$date2[0];
        $date4[1]=$date2[1];
        $date4[2]=1;
        $date4=implode("-",$date4);
        //下月一号
        $date3[0]=$date2[0];
        $date3[1]=$date2[1]+1;
        $date3[2]=1;
        $date3=implode("-",$date3);
        
        $list=Db::name("production_order")
            ->alias("a")
            ->join("t_product_template c","a.serial_id=c.id","left")
            ->where("c.status=0 and a.planned_delivery_time > '".$date4."' and a.planned_delivery_time < '".$date3."'")
            ->field("a.id,a.name,a.spec,a.serial_id,c.serial_num,a.number,a.planned_delivery_time,a.real_delivery_time,a.status,a.delivery_status,a.stock_num")
            ->limit($begin,$end)
            ->order("a.list desc , a.planned_delivery_time asc,a.create_time asc")
            ->select();
        // return Db::name("production_order")->getlastsql();
        return $list;
    }

    /**
     * 删除订单(单个订单删除)
     * 总订单 production_order
     * 订单配件  parts_order
     */
    public function del_order($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,type,serial_id")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }

        // 启动事务
        Db::startTrans();
        try{
            //总订单
            Db::name("production_order")->where("id=$order_id")->delete();
            //部件
            Db::name("parts_order")->where("order_id=$order_id")->delete();
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"删除成功"
        );
    }

    /**
     * 确认发货
     */
    public function delivery($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,type,serial_id,number,stock_num")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }

        if($order_info["number"] != $order_info["stock_num"]){
            return $this->error("10004","请确认订单");
        }

        $data=array(
            "id"=>$order_id,
            "real_delivery_time"=>date("Y-m-d H:i:s",time()),
            "delivery_status"=>2,
            "is_finish"=>1
        );

        $result=Db::name("production_order")->update($data);
        if(!$result){
            return $this->error("10003","发货失败");
        }

        return array(
            "code"=>200,
            "message"=>"发货成功"
        );
    }

    /**
     * 显示订单信息（单个订单）
     */
    public function show_order($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,type,serial_id,name,spec,number,status,delivery_status,create_time,planned_delivery_time,real_delivery_time,stock_num")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }

        //产品型号
        $serial_num=Db::name("product_template")->field("serial_num")->where('id='.$order_info['serial_id'])->find();

        $order_info['serial_num']=$serial_num['serial_num'];

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$order_info
        );
    }

    /**
     * 订单编辑  发货时间排产状态,订单数量
     */
    public function change_order($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,serial_id,stock_num")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }

        $where=array(
            "id"=>$order_id
        );

        //排产状态
        $status=$param['status'];
        if($status){
            $where['status']=$status;
            if($status==3){
                $where['delivery_status']=1;
            }
        }

        //发货时间
        $planned_delivery_time=$param['planned_delivery_time'];
        if($planned_delivery_time){
            $where['planned_delivery_time']=$planned_delivery_time;
        }

        //订单数量
        $number=$param['number'];
        if($number){
            $where['number']=$number;
            //修改配件数量
            $parts_info=Db::name("parts_order")->field("id,parts_id")->where("order_id=$order_id")->select();
            foreach ($parts_info as $key => $val) {
                //获取配件信息
                $parts=Db::name('product_template')
                        ->alias('m')
                        ->join("t_product_parts a", 'm.id = a.serial_id')
                        ->where("a.type=0 and a.parts_id=".$val['parts_id']." and m.id=".$order_info['serial_id'])
                        ->field('a.amount')
                        ->find();
                $parts_info[$key]['amount']=$number*$parts['amount'];
            }

            //判断订单数与发货数
            if($order_info['stock_num'] == $number){
                $where["status"]=3;
            }
        }
   
        // 启动事务
        Db::startTrans();
        try{
            Db::name('production_order')->update($where);
            if($number){
                foreach ($parts_info as $key => $val) {
                    Db::name('parts_order')->update($val);
                }
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"编辑成功"
        );
    }

    /**
     * 发货
     */
    public function sendEditNumm($param){
        $stock_num=$param['stock_num'];
        $order_id=$param["order_id"];

        if(!$stock_num || !$order_id){
            return $this->error("10001","参数错误");
        }

        $order_info=Db::name("production_order")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","参数错误");
        }

        $stock_nums=$stock_num+$order_info["stock_num"];

        $where=array(
            "id"=>$order_id,
            'stock_num'=>$stock_nums,
            "real_delivery_time"=>date("Y-m-d H:i:s")
        );

        if($stock_num > $order_info["number"]){
            return $this->error("10003","请确认发货数量");
        }

        if($stock_nums == $order_info["number"]){
            $where["status"]=3;
        }

        //修改配件数量
        $stock=Db::name("parts_order")->field("id,parts_id")->where("order_id=$order_id")->select();

        foreach ($stock as $key => $val) {
            //获取配件信息
            $parts=Db::name('product_template')
                    ->alias('m')
                    ->join("t_product_parts a", 'm.id = a.serial_id')
                    ->where("a.type=0 and a.parts_id=".$val['parts_id']." and m.id=".$order_info['serial_id'])
                    ->field('a.amount')
                    ->find();
            $stock[$key]['stock_num']=$stock_nums*$parts['amount'];
        }

        //库存
        $product_stock=Db::name("product_stock")->where("serial_id=".$order_info["serial_id"]." and type=1")->find();
        if(!$product_stock){
            return $this->error("10045","库存不足，请确认！");
        }
        $amount=$product_stock["amount"]-$stock_num;
        if($amount < 0){
            return $this->error("10046","库存不足，请确认！");
        }
        $stock_data=array(
            "id"=>$product_stock["id"],
            "amount"=>$amount
        );

        // 启动事务
        Db::startTrans();
        try{
            Db::name("production_order")->update($where);
            Db::name("product_stock")->update($stock_data);
            foreach ($stock as $key => $val) {
                Db::name('parts_order')->update($val);
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"编辑成功"
        );
    }

    /**
     * 原材料列表
     */
    public function getAllMaterial($param){
        $material_id=$param["material_id"];

        if($material_id){
            $where=array("id"=>$material_id);
        }else{
            $where=array();
        }

        $material_info=Db::name("material")->where($where)->select();

        if(!$material_info){
            return $this->error("10001","暂时没有原材料，请添加！");
        }

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$material_info
        );
    }

    /**
     * 添加原材料库存
     */
    public function add_material($param=""){
        $data['name']=$name=trim($param['name']);
        $data['serial_num']=$serial_num=$param['serial_num'];
        $data['amount']=$amount=$param['amount']?$param['amount']:0;
        $data['create_time']=$create_time=date("Y-m-d H:i:s",time());
        $data['unit']=$unit=$param['unit'];
        $data['price']=$price=$param['price'];
        $parts=$param['parts'];
        $parts=json_decode($parts,true);

        if(!$name || !$serial_num || !$unit || !$price ||!$amount ||!$parts){
            return $this->error("10001","参数错误");
        }

        //验证重复添加
        $result=Db::name("material")->where("name='".$name."' and serial_num='".$serial_num."'")->find();
        if($result){
            return $this->error("10002","请不要重复添加");
        }

        $res=Db::name("material")->insert($data);
        if(!$res){
            return $this->error("10003","添加失败");
        }

        $info=Db::name("material")->where($data)->find();
        $data=array();
        foreach ($parts as $key => $val) {
            $data[$key]['material_id']=$info['id'];
            $data[$key]['parts_id']=$val["id"];
        }

        // 启动事务
        Db::startTrans();
        try{
            Db::name('parts_material')->insertAll($data);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"添加成功"
        );
    }

    /**
     * 原材料入库出库
     * amount  入库出库数量
     * 入库(type=1)
     * 出库（type=2）
     */
    public function material_stock($param){
        $type=$param['type'];
        $material_id=$param['material_id'];
        $amount=$param['amount'];
        $userid=$param["userid"];
        $change_time=date("Y-m-d H:i:s",time());

        if(!$type || !$material_id || !$amount ||!$userid){
            return $this->error("10001","参数错误");
        }

        //获取原材料信息
        $material_info=Db::name("material")->where("id=$material_id")->find();
        //获取用户信息
        $userinfo=Db::name("admin")->where("id=$userid")->find();
        if(!$material_info){
            return $this->error("10002","原材料信息获取失败");
        }
        if(!$userinfo){
            return $this->error("10003","用户信息获取失败");
        }

        $data=array();
        if($type==1){
            $data['amount']=$material_info['amount']+$amount;
        }elseif($type==2){
            $data['amount']=$material_info['amount']-$amount;
            if($data['amount']<0){
                return $this->error("10005","库存不足，请确认");
            }
        }
        $data['id']=$material_info['id'];
        $data['change_time']=$change_time;

        $list=array(
            "type"=>$type,
            "operator"=>$userinfo["username"],
            "amount"=>$amount,
            "material_id"=>$material_id,
            "create_time"=>date("Y-m-d H:i:s",time())
        );

        // 启动事务
        Db::startTrans();
        try{
            Db::name("material")->update($data);
            Db::name("material_list")->insert($list);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"添加成功"
        );
    }

    /**
     * 原材料删除
     */
    public function del_material($param=""){
        $material_id=$param['material_id'];

        if(empty($material_id)){
            return $this->error("10001","请选择删除的原材料");
        }
        
        // 启动事务
        Db::startTrans();
        try{
            //原材料
            Db::name('material')->where("id =".$material_id)->delete();
            //原材料配件
            Db::name("parts_material")->where("material_id =".$material_id)->delete();
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"删除成功"
        );
    }

    /**
     * 总排产计划
     */
    public function schedule_order($param=""){
        $order_list=$this->order_list($param);

        if(!$order_list['body']){
            return $this->error("10005","暂时没有订单");
        }
        $order_list=$order_list['body'];

        //获取所有配件库存
        $partStock=Db::name("product_stock")->field("serial_id,amount")->where("type=2")->select();
        $stockId=array_column($partStock, "serial_id");
        $partStock=array_column($partStock,"amount","serial_id");

        //配件
        foreach ($order_list as $key => $val) {
            $parts_order=$this->getAllPartsInfo($val["id"],$partStock,$stockId);
            $parts_order=$parts_order["parts_order"];
            $partStock=$parts_order["partStock"];
            $order_list[$key]['order_list']=$parts_order;

        }

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$order_list
        );
    }

    /**
     * 配件处理
     */
    public function getAllPartsInfo($order_id,$partStock,$stockId){
        if(!$order_id){
            return $this->error("10006","订单参数错误");
        }  
        $parts_order=Db::name("parts_order")
                        ->alias("a")
                        ->join("t_parts b","a.parts_id=b.id")
                        ->where("a.order_id=".$order_id)
                        ->field("b.name,a.parts_id,b.serial_num,a.stock_num,a.amount")
                        ->select();
        $data1=array();
        foreach ($parts_order as $key => $info) {
          $data1[$info['serial_num']][] = $info;
        }
        $data1=array_values($data1);
        $workshop=array();
        foreach ($data1 as $key => $val) {
            if(count($val)>1){
                foreach ($val as $k => $v) {
                    $workshop[$key]['parts_id']=$v['parts_id'];
                    $workshop[$key]['name']=$v['name'];
                    $workshop[$key]['serial_num']=$v['serial_num'];
                    $workshop[$key]['stock_num']+=$v['stock_num'];
                    $workshop[$key]['amount']+=$v['amount'];
                }
            }else{
                $workshop[$key]=$val[0];
            }
        }
        $parts_order=$workshop;

        //获取所有原材料
        $idList=implode(",",$stockId);
        $materialStock=Db::name("parts_material")
                    ->alias("a")
                    ->join("material b","a.material_id=b.id")
                    ->field("a.parts_id,b.amount,b.name,b.serial_num")
                    ->where("a.parts_id in (".$idList.")")
                    ->select();
        $materialStockId=array_column($materialStock,"parts_id");
        $materialAmount=array_column($materialStock,"amount","parts_id");
        $materialName=array_column($materialStock,"name","parts_id");
        $materialSerial=array_column($materialStock,"serial_num","parts_id");

        foreach ($parts_order as $key => $val) {
            //库存
            if(in_array($val["parts_id"],$stockId)){
                $num=$val["stock_num"]+$partStock[$val["parts_id"]];
                if($num < $val["amount"]){
                    $parts_order[$key]["stock_num"]=$num;
                    $partStock[$val["parts_id"]]=0;
                }elseif($num == $val["amount"]){
                    $parts_order[$key]["stock_num"]=$num;
                    $partStock[$val["parts_id"]]=0;
                }elseif($num > $val["amount"]){
                    $parts_order[$key]["stock_num"]=$val["amount"];
                    $partStock[$val["parts_id"]]=$num-$val["amount"];
                }
            }else{
                $parts_order[$key]["stock_num"]=$val["stock_num"];
            }

            //原材料
            if(in_array($val["parts_id"],$materialStockId)){
                $parts_order[$key]["material_name"]=$materialName[$val["parts_id"]];
                $parts_order[$key]["material_serial"]=$materialSerial[$val["parts_id"]];
                $parts_order[$key]["material_amount"]=$materialAmount[$val["parts_id"]];
            }else{
                $parts_order[$key]["material_name"]="";
                $parts_order[$key]["material_serial"]="";
                $parts_order[$key]["material_amount"]=0;
            }
        }

        return array(
            "parts_order"=>$parts_order,
            "partStock"=>$partStock,
        );

    }

    /**
     * 获取配件信息（单个订单）
     */
    public function getoneorderparts($param=""){
        $order_id=$param["order_id"];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证订单存在
        $order_info=Db::name("production_order")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单参数错误");
        }

        //获取订单配件信息
        $parts_order=$this->getallparts($order_id);
        if(!$parts_order){
            return $this->error("10003","配件信息错误");
        }

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$parts_order
        );
    }       

    /**
     * 获取配件信息
     */
    public function getallparts($order_id){
        if(!$order_id){
            return $this->error("10006","订单参数错误");
        }  
        $parts_order=Db::name("parts_order")
                        ->alias("a")
                        ->join("t_parts b","a.parts_id=b.id")
                        ->where("a.order_id=".$order_id)
                        ->field("b.name,a.parts_id,b.serial_num,a.stock_num,a.amount")
                        ->select();
        $data1=array();
        foreach ($parts_order as $key => $info) {
          $data1[$info['serial_num']][] = $info;
        }
        $data1=array_values($data1);
        $workshop=array();
        foreach ($data1 as $key => $val) {
            if(count($val)>1){
                foreach ($val as $k => $v) {
                    $workshop[$key]['parts_id']=$v['parts_id'];
                    $workshop[$key]['name']=$v['name'];
                    $workshop[$key]['serial_num']=$v['serial_num'];
                    $workshop[$key]['stock_num']+=$v['stock_num'];
                    $workshop[$key]['amount']+=$v['amount'];
                }
            }else{
                $workshop[$key]=$val[0];
            }
        }
        $parts_order=$workshop;

        $parts_id=Db::name("parts_order")->field("parts_id")->where("order_id=$order_id")->select();
        $arr=array();
        foreach ($parts_id as $key => $val) {
            $arr[]=$val['parts_id'];
        }
        $parts_id=implode(",", $arr);

        //产品库存
        $stock_num=Db::name("product_stock")->field("serial_id,amount")->where("type=2 and serial_id in (".$parts_id.")")->select();
        $data=array();
        $data2=array();
        foreach ($stock_num as $key => $info) {
          $data[]= $info['serial_id'];
          $data2[$info['serial_id']][]= $info;
        }
        foreach ($parts_order as $key => $val) {
            if(in_array($val["parts_id"],$data)){
                $number=$val["amount"]-$val['stock_num'];
                if($number<$data2[$val["parts_id"]][0]["amount"]){
                    $parts_order[$key]["stock_num"]=$val["amount"];
                    $data2[$val["parts_id"]][0]["amount"]=$data2[$val["parts_id"]][0]["amount"]-$val["amount"]+$val["stock_num"];
                }else{
                    $parts_order[$key]["stock_num"]=$data2[$val["parts_id"]][0]["amount"]+$val["stock_num"];
                    $data2[$val["parts_id"]][0]["amount"]=0;
                }
            }else{
                $parts_order[$key]["stock_num"]=$val["stock_num"];
            }
        }

        //原材料库存
        $material_id=Db::name("parts_material")
                    ->alias("a")
                    ->join("material b","a.material_id=b.id")
                    ->field("a.parts_id,b.amount,b.name,b.serial_num")
                    ->where("a.parts_id in (".$parts_id.")")
                    ->select();
        $data=array();
        $data2=array();
        foreach ($material_id as $key => $info) {
          $data[]= $info['parts_id'];
          $data2[$info['parts_id']][]= $info;
        }
        foreach ($parts_order as $key => $val) {
            if(in_array($val["parts_id"],$data)){
                $parts_order[$key]["material_name"]=$data2[$val["parts_id"]][0]["name"];
                $parts_order[$key]["material_amount"]=$data2[$val["parts_id"]][0]["amount"];
                $parts_order[$key]["material_serial"]=$data2[$val["parts_id"]][0]["serial_num"];
            }else{
                $parts_order[$key]["material_name"]="";
                $parts_order[$key]["material_amount"]=0;
                $parts_order[$key]["material_serial"]="";
            }
        }

        return $parts_order;
    }

    /**
     * 排产
     */
    public function schedule($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,serial_id,status")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }
        if($order_info['status']==1){
            return $this->error("10004","请不要重复排产");
        }
        if($order_info['status']==2){
            return $this->error("10005","订单已逾期");
        }
        if($order_info['status']==3){
            return $this->error("10006","订单已完成");
        }

        $where=array(
            "id"=>$order_id,
            "status"=>1,
        );

        $result= Db::name("production_order")->update($where);

        if(!$result){
            return $this->error("10003","修改失败");
        }
        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }

    /**
     * 置顶
     */
    public function operate_top($param=""){
        $order_id=$param['order_id'];

        if(!$order_id){
            return $this->error("10001","参数错误");
        }

        //验证是否存在订单
        $order_info=Db::name("production_order")->field("id,serial_id,list")->where("id=$order_id")->find();

        if(!$order_info){
            return $this->error("10002","订单不存在");
        }

        $where=array(
            "id"=>$order_id,
            "create_list_time"=>date("Y-m-d H:i:s",time())
        );
        if($order_info['list'] == 0){
            $where['list']=1;
        }else{
            $where['list']=0;
        }
       
        $result= Db::name("production_order")->update($where);

        if(!$result){
            return $this->error("10003","修改失败");
        }
        return array(
            "code"=>200,
            "message"=>"修改成功"
        );
    }

    /**
     * 车间排产计划
     */
    public function workshop_order(){
        //当月时间
        $date1=date("Y-m-d",time());
        $date2=explode("-", $date1);
        //当月一号
        $date4[0]=$date2[0];
        $date4[1]=$date2[1];
        $date4[2]=1;
        $date4=implode("-",$date4);
        //下月一号
        $date3[0]=$date2[0];
        $date3[1]=$date2[1]+1;
        $date3[2]=1;
        $date3=implode("-",$date3);

        $parts_info=Db::name("production_order")
                    ->alias("a")
                    ->join("t_parts_order b","a.id=b.order_id")
                    ->join("t_parts d","b.parts_id=d.id")
                    ->where("a.planned_delivery_time > '".$date4."' and a.planned_delivery_time < '".$date3."' and a.is_finish=0")
                    ->order("a.list desc , a.planned_delivery_time asc,a.create_time asc")
                    ->field("a.serial_id,d.id as parts_id,d.name,d.serial_num,d.unit,d.price,b.workshop,b.amount,b.stock_num")
                    ->select();

        //一车间/二车间排产计划
        $result= array();
        foreach ($parts_info as $key => $info) {
          $result[$info['workshop']][] = $info;
        }

        $workshop1=$result[1];
        $workshop2=$result[2];

        //数组处理 
        //一车间
        $data1=array();
        foreach ($workshop1 as $key => $info) {
          $data1[$info['serial_num']][] = $info;
        }
        $data1=array_values($data1);
        $workshop1_data=array();
        foreach ($data1 as $key => $val) {
            if(count($val)>1){
                foreach ($val as $k => $v) {
                    $workshop1_data[$key]['serial_id']=$v['serial_id'];
                    $workshop1_data[$key]['parts_id']=$v['parts_id'];
                    $workshop1_data[$key]['name']=$v['name'];
                    $workshop1_data[$key]['serial_num']=$v['serial_num'];
                    $workshop1_data[$key]['unit']=$v['unit'];
                    $workshop1_data[$key]['price']=$v['price'];
                    $workshop1_data[$key]['workshop']=$v['workshop'];
                    $workshop1_data[$key]['amount']+=$v['amount'];
                    $workshop1_data[$key]['stock_num']+=$v['stock_num'];
                }
            }else{
                $workshop1_data[$key]=$val[0];
            }
        }
        //二车间
        $data2=array();
        foreach ($workshop1 as $key => $info) {
          $data2[$info['serial_num']][] = $info;
        }
        $data2=array_values($data2);
        $workshop2_data=array();
        foreach ($data2 as $key => $val) {
            if(count($val)>1){
                foreach ($val as $k => $v) {
                    $workshop2_data[$key]['serial_id']=$v['serial_id'];
                    $workshop2_data[$key]['parts_id']=$v['parts_id'];
                    $workshop2_data[$key]['name']=$v['name'];
                    $workshop2_data[$key]['serial_num']=$v['serial_num'];
                    $workshop2_data[$key]['unit']=$v['unit'];
                    $workshop2_data[$key]['price']=$v['price'];
                    $workshop2_data[$key]['workshop']=$v['workshop'];
                    $workshop2_data[$key]['amount']+=$v['amount'];
                    $workshop2_data[$key]['stock_num']+=$v['stock_num'];
                }
            }else{
                $workshop2_data[$key]=$val[0];
            }
        }

        //获取参数 type 内产/外协  计划总数count_amount  库存总数count_stock
        $count_amount1="";
        $count_stock1="";
        $count_amount2="";
        $count_stock2="";
        foreach ($workshop1_data as $key => $val) {
            $type=Db::name("product_parts")->field('type')->where("serial_id=".$val["serial_id"]." and parts_id=".$val['parts_id'])->find();
            $workshop1_data[$key]['type']=$type["type"]?$type["type"]:0;
            $count_amount1+=$val['amount'];
            $count_stock1+=$val['stock_num'];
        }
        foreach ($workshop2_data as $key => $val) {
            $type=Db::name("product_parts")->field('type')->where("serial_id=".$val["serial_id"]." and parts_id=".$val['parts_id'])->find();
            $workshop2_data[$key]['type']=$type["type"]?$type["type"]:0;
            $count_amount2+=$val['amount'];
            $count_stock2+=$val['stock_num'];
        }

        $res['workshop1']=$workshop1_data;
        $res['workshop2']=$workshop2_data;
        $res['count_amount1']=$count_amount1;
        $res['count_stock1']=$count_stock1;
        $res['count_amount2']=$count_amount2;
        $res['count_stock2']=$count_stock2;

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$res
        );
    }

    /**
     * 车间排产计划  一车间type=1   二车间type=2
     */
    public function getWorkshopOneOrder($param){
        $type=$param["type"]?$param["type"]:1;

        //当月时间
        $date1=date("Y-m-d",time());
        $date2=explode("-", $date1);
        //当月一号
        $date4[0]=$date2[0];
        $date4[1]=$date2[1];
        $date4[2]=1;
        $date4=implode("-",$date4);
        //下月一号
        $date3[0]=$date2[0];
        $date3[1]=$date2[1]+1;
        $date3[2]=1;
        $date3=implode("-",$date3);

        $parts_info=Db::name("production_order")
                    ->alias("a")
                    ->join("t_parts_order b","a.id=b.order_id")
                    ->join("t_parts d","b.parts_id=d.id")
                    ->where("a.planned_delivery_time > '".$date4."' and a.planned_delivery_time < '".$date3."' and a.is_finish=0 and b.workshop=$type")
                    ->order("a.list desc , a.planned_delivery_time asc,a.create_time asc")
                    ->field("a.serial_id,d.id as parts_id,d.name,d.serial_num,d.unit,d.price,b.workshop,b.amount,b.stock_num")
                    ->select();

        $data1=array();
        foreach ($parts_info as $key => $info) {
          $data1[$info['serial_num']][] = $info;
        }
        $data1=array_values($data1);
        $workshop1_data=array();
        foreach ($data1 as $key => $val) {
            if(count($val)>1){
                foreach ($val as $k => $v) {
                    $workshop1_data[$key]['serial_id']=$v['serial_id'];
                    $workshop1_data[$key]['parts_id']=$v['parts_id'];
                    $workshop1_data[$key]['name']=$v['name'];
                    $workshop1_data[$key]['serial_num']=$v['serial_num'];
                    $workshop1_data[$key]['unit']=$v['unit'];
                    $workshop1_data[$key]['price']=$v['price'];
                    $workshop1_data[$key]['workshop']=$v['workshop'];
                    $workshop1_data[$key]['amount']+=$v['amount'];
                }
            }else{
                $workshop1_data[$key]=$val[0];
            }
        }

        $count_amount="";
        $count_stock="";
        foreach ($workshop1_data as $key => $val) {
            //外协件
            $types=Db::name("product_parts")->field('type')->where("serial_id=".$val["serial_id"]." and parts_id=".$val['parts_id'])->find();
            $workshop1_data[$key]['type']=$types["type"]?$types["type"]:0;

            //库存
            $number=Db::name("product_stock")->field("amount")->where("serial_id = ".$val["parts_id"]." and type=2")->find();
            $workshop1_data[$key]['amount']=$val["amount"]-$val["stock_num"];
            if($number){
                $num=intval($number['amount']/2);
                if($type==1){
                    $workshop1_data[$key]['stock_num']=$num;
                }else{
                    if($num==$number['amount']/2){
                       $workshop1_data[$key]['stock_num']=$num;
                    }else{
                        $num2=$num+1;
                        $workshop1_data[$key]['stock_num']=$num2;
                    }
                }
            }else{
                $workshop1_data[$key]['stock_num']=0;
            }

            //获取车间生产数量
            $aply_num=$this->getPartsNum(array("parts_id"=>$val["parts_id"],"workshop"=>$val["workshop"]));
            $workshop1_data[$key]['aply_num']=$aply_num;

            //总数
            if($workshop1_data[$key]['type']==0){
                $count_amount+=$val['amount'];
                $count_stock+=$val['stock_num'];
            }
        }

        $arr=array();
        $arr['count_amount']=$count_amount;
        $arr['count_stock']=$count_stock;
        $arr["parts"]=$workshop1_data;
        
        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$arr
        );

    }

    /**
     * 获取配件不同车间的生产数量
     */
    public function getPartsNum($param){
        $parts_id=$param["parts_id"];
        $workshop=$param["workshop"];

        if(!$parts_id || !$workshop){
            return $this->error("10007","参数错误");
        }

        $aply_info=Db::name("workshop_aply")->where("parts_id=$parts_id and workshop=$workshop and status=2")->select();

        $number='';
        if($aply_info){
            foreach ($aply_info as $key => $val) {
                $number+=$val["amount"];
            }
            $aply_num=$number;
        }

        return $aply_num?$aply_num:0;
    }

    /**
     * 产品入库出库    入库 status=1   出库 status=2
     * type=1整体  type=2部件
     */
    public function product_stock($param=""){
        $status=$param['status'];
        $type=$param['type'];
        $serial_id=$param['serial_id'];
        $id=$param['id'];
        $workshop=$param['workshop'];
        $amount=intval($param['amount']);
        $userid=$param['userid'];

        if(!$type || !$serial_id || !$amount || !$status ||!$workshop ||!$userid){
            return $this->error("10001","参数错误");
        }

        //是否存在库存记录
        $stock_info=Db::name("product_stock")->where("id=$id")->find();
        $userinfo=Db::name("admin")->where("id=$userid")->find();
        if(!$stock_info){
            return $this->error("10005","参数错误");
        }
        if($status==1){
            $number=$stock_info["amount"]+$amount;
        }else{
            $number=$stock_info["amount"]-$amount;
        }
        if($number < 0){
            return $this->error("10002","库存不足");
        }
        $data=array(
            "type"=>$type,
            "amount"=>$number,
            "serial_id"=>$serial_id,
            "create_time"=>date("Y-m-d H:i:s")
        );

        $list=array(
            "type"=>$type,
            "amount"=>$amount,
            "serial_id"=>$serial_id,
            "create_time"=>date("Y-m-d H:i:s"),
            "status"=>$status,
            "workshop"=>$workshop,
            "operator"=>$userinfo["username"]
        );

        // 启动事务
        Db::startTrans();
        try{
            if($stock_info){
                Db::name("product_stock")->update(array("id"=>$stock_info["id"],"amount"=>$number,"change_time"=>date("Y-m-d H:i:s")));
            }else{
                Db::name("product_stock")->insert($data);
            }
            Db::name("stock_list")->insert($list);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"出入库成功"
        );
    }

    /**
     * 获取产品库存列表
     * type 类型 1:整件；2：部件
     */
    public function getAllProduct($param){
        $product_id=$param["product_id"];

        if(!$product_id){
            $where=array();
        }else{
            $where=array("id"=>$product_id);
        }

        $productinfo=Db::name("product_stock")->where($where)->order("type asc")->select();

        if(!$productinfo){
            return $this->error("10001","暂时没有产品库存信息，请添加！");
        }

        foreach ($productinfo as $key => $val) {
            if($val["type"]==1){
                $partsinfo=Db::name("product_template")->field("name,serial_num")->where("id=".$val['serial_id']." and status=0")->find();
            }elseif ($val["type"]==2) {
                $partsinfo=Db::name("parts")->field("name,serial_num")->where("id=".$val['serial_id'])->find();
            }
            $productinfo[$key]["name"]=$partsinfo["name"];
            $productinfo[$key]["serial_num"]=$partsinfo["serial_num"];
        }

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=>$productinfo
        );
    }

    /**
     *   添加产品库存
     */
    public function addProductStock($param){
        $amount=$param["amount"];
        $parts=$param["parts"];
        $userid=$param["userid"];

        if(!$amount || !$parts){
            return $this->error("10001","参数错误");
        }

        $parts=json_decode($parts,true);
        $userinfo=Db::name("admin")->where("id=$userid")->find();

        $data=array();
        $list=array();
        foreach ($parts as $key => $val) {
            //重复添加去除
            $res=Db::name("product_stock")->where("serial_id=".$val['id'])->find();
            if($res){
                unset($parts[$key]);
            }else{
                $data[$key]["amount"]=$amount;
                $data[$key]["type"]=2;
                $data[$key]["serial_id"]=$val['id'];
                $data[$key]["create_time"]=date("Y-m-d H:i:s",time());
                $data[$key]["change_time"]=date("Y-m-d H:i:s",time());

                $list[$key]["amount"]=$amount;
                $list[$key]["type"]=2;
                $list[$key]["status"]=1;
                $list[$key]["serial_id"]=$val['id'];
                $list[$key]["create_time"]=date("Y-m-d H:i:s",time());
                $list[$key]["workshop"]=99;
                $list[$key]["operator"]=$userinfo["username"];
            }
        }

        if(empty($data)){
            return $this->error("10001","请不要重复添加");
        }

         // 启动事务
        Db::startTrans();
        try{
            Db::name("product_stock")->insertAll($data);
            Db::name("stock_list")->insertAll($list);
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"添加成功"
        );
    }

    /**
     * 申请入库
     */
    public function aplyStock($param){
        $data["parts_id"]=$parts_id=$param["parts_id"];
        $data["workshop"]=$workshop=$param["workshop"];
        $data["amount"]=$amount=$param["amount"];
        $data["status"]=$status=1;
        $data["create_time"]=$create_time=date("Y-m-d H:i:s");
        $userid=$param["userid"];

        if(!$parts_id || !$workshop || !$amount){
            return $this->error("10001","参数错误");
        }

        $userinfo=Db::name("admin")->where("id=$userid")->find();

        $data["operator"]=$userinfo["username"];

        $result=Db::name("workshop_aply")->insert($data);

        if(!$result){
            return $this->error("10002","系统错误");
        }

        return array(
            "code"=>200,
            "message"=>"申请入库成功"
        );
    }

    /**
     * 入库审核列表
     */
    public function getWorkshopAply($param){
        $aply_id=$param["aply_id"];

        if($aply_id){
            $where=array("a.id"=>$aply_id);
        }else{
            $where=array();
        }

        $aplyinfo=Db::name("workshop_aply")
                ->alias("a")
                ->join("t_parts b","a.parts_id=b.id")
                ->field("a.id,b.id as parts_id,b.name,b.serial_num,a.operator,a.workshop,a.amount,a.create_time,a.status,a.change_time")
                ->where($where)
                ->order("create_time desc")
                ->select();

        if(!$aplyinfo){
            return $this->error("10001","暂时没有申请信息");
        }

        return array(
            "code"=>200,
            "message"=>"获取成功",
            "body"=> $aplyinfo
        );
    }

    /**
     * 审核入库申请
     */
    public function reviewAply($param){
        $aply_id=$param["aply_id"];
        $parts_id=$param["parts_id"];
        $status=$param["status"];
        $amount=$param["amount"];
        $operator=$param["operator"];
        $workshop=$param["workshop"];

        if(!$aply_id  ||  !$parts_id  ||  !$status){
            return $this->error("10001","参数错误");
        }

        $aplyinfo=Db::name("workshop_aply")->where("id=$aply_id")->find();
        $stockinfo=Db::name("product_stock")->where("serial_id=$parts_id")->find();

        if($aplyinfo["status"]==$status){
            return $this->error("10002","请确认审核状态");
        }
        $number=$stockinfo["amount"]+$amount;

        $aply=array("id"=>$aply_id,"status"=>$status,"change_time"=>date("Y-m-d H:i:s"));
        $data=array("amount"=>$number,"change_time"=>date("Y-m-d H:i:s"));
        $list=array("serial_id"=>$parts_id,"type"=>2,"status"=>1,"amount"=>$amount,"create_time"=>date("Y-m-d H:i:s"),"workshop"=>$workshop,"operator"=>$operator);

        // 启动事务
        Db::startTrans();
        try{
            if($status==2){
                Db::name("workshop_aply")->update($aply);
                Db::name("product_stock")->where(array("serial_id"=>$parts_id,"type"=>2))->update($data);
                Db::name("stock_list")->insert($list);
            }else{
                Db::name("workshop_aply")->update($aply);
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return $this->error(2003, '系统繁忙，请稍后重试');
        }

        return array(
            "code"=>200,
            "message"=>"审核成功"
        );
    }


    /**
     * 获取经纬度
     */
    public function getlnglat(){
        $data=Db::name("district")->field("id,district,lng,lat")->where("level=2")->select();

        $list=array();
        foreach ($data as $key => $val) {
            $url="http://api.map.baidu.com/geocoder/v2/?address=".$val['district']."&output=json&ak=3MZDAUZ0z1oD9yhimZFRIobvHAevegNu&city=".$val['district'];
            $content = file_get_contents($url);
            $json = json_decode($content,true);
            $json=$json["result"]["location"];
            $list["id"]=$val["id"];
            $list["lng"]=$json["lng"];
            $list["lat"]=$json["lat"];
            Db::name("district")->update($list);
        }
    }
    
}