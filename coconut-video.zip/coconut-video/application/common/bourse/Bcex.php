<?php
namespace app\common\bourse;

use Exception;

class Bcex
{
    public function __construct()
    {
        $this->auth = [
            'url' => config('bcex_url'),
            'key' => config('bcex_key'),
        ];
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
    	$url  = $this->auth['url'] . 'api_market/getTradeLists';
    	$data = ['api_key' => $this->auth['key']];
    	return curl_request($url, 'get', $data);
    }
}