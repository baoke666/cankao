<?php
namespace app\common\bourse;

use Exception;

class Lbank
{
    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
    	return curl_request('https://api.lbkex.com/v1/ticker.do?symbol=all');
    }
}