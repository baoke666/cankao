<?php
namespace app\common\bourse;

use Exception;

class Okcoin
{
    public function __construct()
    {
        $this->auth = [
            'url' => config('okcoin_url'),
        ];
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
    	$url  = $this->auth['url'] . 'instruments/ticker';
    	return curl_request($url, 'get');
    }
}