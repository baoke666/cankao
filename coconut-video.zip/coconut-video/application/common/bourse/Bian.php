<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/29 0029
 * Time: 下午 5:09
 */

namespace app\common\bourse;

class Bian
{

    function getMillisecond() {
        list($s1, $s2) = explode(' ', microtime());
        return (float)sprintf('%.0f', (floatval($s1) + floatval($s2)) * 1000);
    }

    public function testBian(){
        $headers = [
            'X-MBX-APIKEY: GDweUNLt1XWTl4zvLQp0XGbIDPZXZNwp5iuwDNF0YEb0M0hTOKtm00nCAiCTcsIc',
        ];
        //date_default_timezone_set("Etc/GMT+0");
        $timestamp = $this->getMillisecond();
        $signature = hash_hmac('sha256', "recvWindow=100000&timestamp={$timestamp}", 'u2adzZP0LrzTsOqPhlm8p4chpTO1kct5SYkb5rkaHJz33ZxiSPYBm27lsFsRzO7C');
        $url = "https://api.binance.com/api//v3/account?recvWindow=100000&timestamp={$timestamp}&signature={$signature}";
        //$url = "https://api.binance.com/api/v1/time";

        //初始化
        $curl = curl_init();
        //设置抓取的url
        curl_setopt($curl, CURLOPT_URL, $url);
        //设置头文件的信息作为数据流输出
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); //不验证证书下同
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); //
        //设置获取的信息以文件流的形式返回，而不是直接输出。
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_PROXY, '127.0.0.1:1080');
        curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        //执行命令
        $data = curl_exec($curl);
        $info = curl_getinfo($curl);
        //关闭URL请求
        curl_close($curl);
        //显示获得的数据
        echo($data);
        //var_dump($data);
    }
}