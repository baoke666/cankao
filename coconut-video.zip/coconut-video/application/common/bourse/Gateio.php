<?php
namespace app\common\bourse;

use Exception;

class Gateio
{
    public function __construct()
    {
        date_default_timezone_set('UTC');
        $this->auth = [
            'url'    => config('gateio_url'),
            'key'    => config('gateio_key'),
            'secret' => config('gateio_secret'),
        ];
    }

    private function signature($params = array())
    {
        // generate a nonce as microtime, with as-string handling to avoid problems with 32bits systems
        $secret = $this->auth['secret'];
        $mctime = explode(' ', microtime());
        $nonce  = $mctime[1] . substr($mctime[0], 2, 6);

        // generate the POST data string and the sign string
        $data = http_build_query(array_merge($params, ['nonce' => $nonce]), '', '&');
        $sign = hash_hmac('sha512', urldecode($data), $secret);

        return ['data' => $data, 'sign' => $sign];
    }

    private function curl_query($path, $key, $sign, $data = '')
    {
        // generate the extra headers
        $headers = array(
            'KEY: ' . $key,
            'SIGN: ' . $sign,
            'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
        );
        static $ch = null;
        if (is_null($ch)) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36');
        }
        curl_setopt($ch, CURLOPT_URL, $path);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        // run the query
        $res = curl_exec($ch);
        // $getinfo = curl_getinfo($ch);
        if ($res === false) {
            throw new Exception('Could not get reply: ' . curl_error($ch));
        }
        $dec = json_decode($res, true);
        if (!$dec) {
            throw new Exception('Invalid data received, please make sure connection is working and requested API exists: ' . $res);
        }

        date_default_timezone_set(config('default_timezone'));
        return $dec;
    }

    private function curl_file_get_contents($path)
    {
        // our curl handle (initialize if required)
        static $ch = null;
        if (is_null($ch)) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT,
                'Mozilla/4.0 (compatible; gate PHP bot; ' . php_uname('a') . '; PHP/' . phpversion() . ')'
            );
        }
        curl_setopt($ch, CURLOPT_URL, $path);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        // run the query
        $res = curl_exec($ch);
        if ($res === false) {
            throw new Exception('Could not get reply: ' . curl_error($ch));
        }

        $dec = json_decode($res, true);
        if (!$dec) {
            throw new Exception('Invalid data: ' . $res);
        }

        date_default_timezone_set(config('default_timezone'));
        return $dec;
    }

    /**
     * get_pairs
     * 获取系统支持的交易对
     *
     * @access public
     * @return array
     */
    public function get_pairs()
    {
        $url  = $this->auth['url'] . '1/pairs';
        $json = $this->curl_file_get_contents($url);
        return $json;
    }

    /**
     * get_marketlist
     * 获取交易市场行情
     *
     * @access public
     * @return array
     */
    public function get_marketlist()
    {
        $url  = $this->auth['url'] . '1/marketlist';
        $json = $this->curl_file_get_contents($url);
        return $json;
    }

    /**
     * get_tickers
     * 获取所有交易对
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
        $url  = $this->auth['url'] . '1/tickers';
        $json = $this->curl_file_get_contents($url);
        return $json;
    }

    /**
     * get_tickers
     * 获取单项交易对
     *
     * @access public
     * @param string $current_pairs 需要查看的币种
     * @return array
     */
    public function get_ticker($current_pairs)
    {
        $url  = $this->auth['url'] . '1/ticker/' . strtoupper($current_pairs);
        $json = $this->curl_file_get_contents($url);
        return $json;
    }

    /**
     * get_tickers
     * 获取单项交易对
     *
     * @access public
     * @param string $current_pairs 需要查看的币种
     * @return array
     */
    public function get_cny($symbol = '')
    {
        if (!$symbol) {
            return null;
        }

        $symbol = strtolower($symbol);
        $toUsdt = '1';
        if ($symbol !== 'usdt') {
            $ticker = $this->get_ticker("{$symbol}_usdt");
            if ($ticker && $ticker['result'] == 'true') {
                $toUsdt = $ticker['last'];
            }
        }
        $toCny = $this->get_ticker("usdt_cny");
        if ($toCny && $toCny['result'] == 'true') {
            return bcmul($toUsdt, $toCny['last'], 2);
        }
        return 0;
    }

    /**
     * get_balances
     * 获取帐号资金余额
     *
     * @access public
     * @return array
     */
    public function get_balances()
    {
        $signature = $this->signature();
        return $this->curl_query($this->auth['url'] . '1/private/balances', $this->auth['key'], $signature['sign'], $signature['data']);
    }

    /**
     * get_deposite_address
     * 获取充币地址
     *
     * @access public
     * @param string $currency 币种 如(BTC, LTC)
     * @return array
     */
    public function get_deposite_address($currency)
    {
        $signature = $this->signature([
            'currency' => $currency,
        ]);
        return $this->curl_query($this->auth['url'] . '1/private/depositAddress', $this->auth['key'], $signature['sign'], $signature['data']);
    }

    /**
     * get_deposites_withdrawals
     * 获取充值提现历史
     *
     * @access public
     * @param string $start 起始UNIX时间(如 1469092370)
     * @param string $end 终止UNIX时间(如 1469713981)
     * @return array
     */
    public function get_deposites_withdrawals($start, $end)
    {
        $signature = $this->signature([
            'start' => $start,
            'end'   => $end,
        ]);
        return $this->curl_query($this->auth['url'] . '1/private/depositsWithdrawals', $this->auth['key'], $signature['sign'], $signature['data']);
    }

    /**
     * do_withdraw
     * 申请提币
     *
     * @access public
     * @param string $currency 提现币种(如:btc)
     * @param string $amount 提现数量
     * @param string $address 提现地址
     * @return array
     */
    public function do_withdraw($currency, $amount, $address)
    {
        $signature = $this->signature([
            'currency' => $currency,
            'amount'   => $amount,
            'address'  => $address,
        ]);
        return $this->curl_query($this->auth['url'] . '1/private/withdraw', $this->auth['key'], $signature['sign'], $signature['data']);
    }

    /**
     * get_deposit_address
     * 获取充值地址
     *
     * @access public
     * @param string $currency 币种:如(BTC, LTC)
     * @return array
     */
    public function get_deposit_address($currency)
    {
        $signature = $this->signature([
            'currency' => strtoupper($currency),
        ]);
        return $this->curl_query($this->auth['url'] . '1/private/depositAddress', $this->auth['key'], $signature['sign'], $signature['data']);
    }

    /**
     * withdraw
     * 提现
     *
     * @access public
     * @param string $currency 提现币种(如:btc)
     * @param string $amount 提现数量
     * @param string $address 提现地址
     * @return array
     */
    public function withdraw($currency, $amount, $address)
    {
        $signature = $this->signature([
            'currency' => strtoupper($currency),
            'amount'   => $amount,
            'address'  => $address,
        ]);
        return $this->curl_query($this->auth['url'] . '1/private/withdraw', $this->auth['key'], $signature['sign'], $signature['data']);
    }
}
