<?php
namespace app\common\bourse;

class Bhex
{
    public function __construct()
    {
        $this->auth = [
            'url' => config('bhex_url'),
        ];
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
        $url = $this->auth['url'] . 'quote/v1/ticker/24hr';
        return curl_request($url, 'get');
    }
}
