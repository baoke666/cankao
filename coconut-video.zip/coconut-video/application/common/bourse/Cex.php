<?php
namespace app\common\bourse;

use Exception;

class Cex
{
    public function __construct()
    {
        $this->auth = [
            'url' => config('cex_url'),
        ];
    }

    private function curl_query($path)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->auth['url'] . $path);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($curl);
        if ($res === false) {
            throw new Exception('Could not get reply: ' . curl_error($curl));
        }
        $dec = json_decode($res, true);
        if (!$dec) {
            throw new Exception('Invalid data received, please make sure connection is working and requested API exists: ' . $res);
        }
        return $dec;
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
        return $this->curl_query('tickerall');
    }

    /**
     * get_tickers
     * 获取最新k线信息
     *
     * @access public
     * @return array
     */
    public function get_kline($pair)
    {
        return $this->curl_query('kline.do?type=1d&size=1&symbol=' . $pair);
    }
}