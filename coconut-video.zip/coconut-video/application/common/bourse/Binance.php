<?php
namespace app\common\bourse;

use Exception;

class Binance
{
    public function __construct()
    {
        $this->auth = [
            'url'    => config('binance_url'),
            'key'    => config('binance_key'),
            'secret' => config('binance_secret'),
        ];
    }

    private function signature($params = array())
    {
        $recvWindow = '1000000';
        $timestamp  = timestamp();
        $queryStr   = http_build_query(array_merge([
            'recvWindow' => "$recvWindow",
            'timestamp'  => "$timestamp",
        ], $params), '&');
        $sign = hash_hmac('sha256', $queryStr, $this->auth['secret']);
        return http_build_query([
            'recvWindow' => $recvWindow,
            'timestamp'  => $timestamp,
            'signature'  => $sign,
        ]);
    }

    private function curl_query($path, $sign = '', $postdata = array())
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->auth['url'] . $path . '?' . $sign);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['X-MBX-APIKEY: ' . $this->auth['key']]);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 不验证证书
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); // 同上
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($curl, CURLOPT_PROXY, '127.0.0.1:1080');
        curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        if ($postdata) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
        }
        $res = curl_exec($curl);
        if ($res === false) {
            throw new Exception('Could not get reply: ' . curl_error($curl));
        }
        $dec = json_decode($res, true);
        if (!$dec) {
            throw new Exception('Invalid data received, please make sure connection is working and requested API exists: ' . $res);
        }
        return $dec;
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_tickers()
    {
        return $this->curl_query('api/v1/ticker/24hr');
    }

    /**
     * get_account
     * 获取账户信息
     *
     * @access public
     * @return array
     */
    public function get_account()
    {
        return $this->curl_query('api/v3/account', $this->signature());
    }
}
