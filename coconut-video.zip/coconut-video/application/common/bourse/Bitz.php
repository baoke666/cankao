<?php
namespace app\common\bourse;

class Bitz
{
    public function __construct()
    {
        $this->auth = [
            'url'    => config('bitz_url'),
            'key'    => config('bitz_key'),
            'secret' => config('bitz_secret'),
        ];
    }

    /**
     * 获取所有牌价数据
     * @param symbols  选填  string
     * @return array
     */
    public function tickerall(array $parms)
    {
        $sendData = $this->getData($parms);
        $url      = $this->auth['url'] . 'Market/tickerall?' . http_build_query($sendData);
        return $this->httpRequest($url);
    }

    /**
     * 获取当前法币汇率信息
     * @param symbols  选填  string
     * @return array
     */
    public function currencyRate(array $parms)
    {
        $sendData = $this->getData($parms);
        $url      = $this->auth['url'] . 'Market/currencyRate?' . http_build_query($sendData);
        return $this->httpRequest($url);
    }

    /**
     * 获取虚拟货币法币汇率信息
     * @param coins  选填  string
     * @return array
     */
    public function currencyCoinRate(array $parms)
    {
        $sendData = $this->getData($parms);
        $url      = $this->auth['url'] . 'Market/currencyCoinRate?' . http_build_query($sendData);
        return $this->httpRequest($url);
    }

    /**
     * 获取币种对应汇率信息
     * @param coins  选填  string
     * @return array
     */
    public function coinRate(array $parms)
    {
        $sendData = $this->getData($parms);
        $url      = $this->auth['url'] . 'Market/coinRate?' . http_build_query($sendData);
        return $this->httpRequest($url);
    }

    /**
     * 获取个人资产
     * @return array
     */
    public function getUserAssets()
    {
        $sendData = $this->getData();
        $url      = $this->auth['url'] . 'Assets/getUserAssets';
        return $this->httpRequest($url, $sendData);
    }

    protected function getData($data = null)
    {
        $baseArr = array(
            'timeStamp' => time(),
            'nonce'     => $this->getRandomString(6),
            'apiKey'    => $this->auth['key'],
        );
        if (isset($data)) {
            $sendData = array_merge($baseArr, $data);
        } else {
            $sendData = $baseArr;
        }
        $sendData['sign'] = $this->getSign($sendData);
        return $sendData;
    }

    protected function getSign($data)
    {
        ksort($data);
        $dataStr = '';
        foreach ($data as $k => $v) {
            $dataStr .= $k . '=' . $v . "&";
        }

        return md5(trim($dataStr, "&") . $this->auth['secret']);
    }

    protected function getRandomString($len, $chars = null)
    {
        if (is_null($chars)) {
            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        }

        for ($i = 0, $str = '', $lc = strlen($chars) - 1; $i < $len; $i++) {
            $str .= $chars[mt_rand(0, $lc)];
        }
        return $str;
    }

    protected function httpRequest($url, $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        if (!empty($data)) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return json_decode($output,true);
    }
}
