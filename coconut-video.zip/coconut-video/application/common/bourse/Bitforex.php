<?php
namespace app\common\bourse;

use Exception;

class Bitforex
{
    public function __construct()
    {
        $this->auth = [
            'url' => config('bitforex_url'),
        ];
    }

    /**
     * get_tickers
     * 获取所有支持的交易对
     *
     * @access public
     * @return array
     */
    public function get_pairs()
    {
    	$url = $this->auth['url'] . 'symbols';
    	$res = file_get_contents($url);
    	return json_decode($res, true);
    }

    /**
     * get_tickers
     * 获取最新行情
     *
     * @access public
     * @return array
     */
    public function get_ticker($symbol)
    {
    	$url = $this->auth['url'] . 'ticker';
    	$res = file_get_contents("{$url}?symbol={$symbol}");
    	return json_decode($res, true);
    }

    /**
     * get_kline
     * 获取k线信息
     *
     * @access public
     * @return array
     */
    public function get_kline($symbol)
    {
        $url = $this->auth['url'] . 'kline';
        $res = file_get_contents("{$url}?symbol={$symbol}&ktype=1day");
        return json_decode($res, true);
    }
}