<?php

namespace app\common\library;

use app\common\library\token\Driver;
use com\easy\Random;
use think\App;
use think\Config;
use think\Log;
use think\Cache;

/**
 * Token操作类
 */
class Token
{
    /**
     * 新建一个token
     */
    public static function create($user_id){
        $token = Random::uuid();

        $prefix = Config::get('token.prefix');
        $expire = Config::get('token.expire');
        $expire = empty($expire) ? '3600' : $expire;
        cache($prefix.$token, ['token' => $token, 'user_id' => $user_id, 'expire' => $expire]);
        return ['token' => $token, 'expire' => $expire];

    }

    /**
     * 新建一个token
     */
    public static function refresh($old){
        $prefix = Config::get('token.prefix');
        $oldItem = cache($prefix.$old);
        $user_id = $oldItem['user_id'];
        cache($old, null);
        $token = Random::uuid();
        $prefix = Config::get('token.prefix');
        $expire = Config::get('token.expire');
        $expire = empty($expire) ? '3600' : $expire;
        cache($prefix.$token, ['token' => $token, 'user_id' => $user_id, 'expire' =>  $expire]);
        return ['token' => $token, 'expire' => $expire];
    }


    /**
     * 判断Token是否可用
     * @param string $token Token标识
     * @return bool
     */
    public static function check($token)
    {
        $prefix = Config::get('token.prefix');
        $tokenItem = cache($prefix.$token);
        if (!$tokenItem) return false;
        return true;
    }

    /**
     * 读取Token
     * @access public
     * @param  string $token Token标识
     * @param  mixed $default 默认值
     * @return mixed
     */
    public static function get($token, $default = false)
    {
        return self::init()->get($token, $default);
    }

    /**
     * 写入Token
     * @access public
     * @param  string $token Token标识
     * @param  mixed $user_id 存储数据
     * @param  int|null $expire 有效时间 0为永久
     * @return boolean
     */
    public static function set($token, $user_id, $expire = null)
    {
        return self::init()->set($token, $user_id, $expire);
    }

    /**
     * 删除Token
     * @param string $token 标签名
     * @return bool
     */
    public static function delete($token)
    {
        $prefix = Config::get('token.prefix');
        cache($prefix.$token, null);
    }

    /**
     * 清除Token
     * @access public
     * @param  string $token Token标记
     * @return boolean
     */
    public static function clear($user_id = null)
    {
        return self::init()->clear($user_id);
    }

}
