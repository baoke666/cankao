<?php

namespace app\index\model;

use app\admin\model\Common;
use com\easy\Random;
use think\Db;
use think\Exception;

class Trustee extends Common
{
    protected $name = 'trustee';

    /**
     * 受理托管订单
     *
     * @access public
     * @return array
     */
    public function doAccept($param, $userInfo)
    {
        $config = Db::name('coin_info')->where('symbol', $param['symbol'])->find();
        $netAmt = bcsub($param['amount'], $config['trustee_fee'], 4);
        if (floatval($netAmt) < floatval($config['trustee_minimum'])) {
            return ['error' => '托管数额太小(扣除手续费)'];
        }

        $condition = ['user_id' => $userInfo['id'], 'symbol' => $param['symbol']];
        $tableName = 'user_capital';
        $capital   = Db::name($tableName)->where($condition)->find();
        if (floatval($capital['available']) < floatval($param['amount'])) {
            return ['error' => '可用资产不足'];
        }

        // 启动事务
        Db::startTrans();
        try {

            $crud1 = 0;
            $crud2 = 0;

            // 修改资产
            $cnyModel  = model('SymbolCny');
            $available = bcsub($capital['available'], $param['amount'], 4);
            $freeze    = bcadd($capital['freeze'], $param['amount'], 4);

            // 修改资产
            $crud1 = Db::name($tableName)
                ->where($condition)
                ->setDec([
                    'available'     => $available,
                    'available_cny' => $cnyModel->convertSymbolToCny($param['symbol'], $available),
                    'freeze'        => $freeze,
                    'freeze_cny'    => $cnyModel->convertSymbolToCny($param['symbol'], $freeze),
                ]);

            // 生成托管订单
            $time      = time();
            $startDate = date('Ymd', strtotime('+1 day'));
            $stopDate  = get_trustee_stopdate($startDate, $param['type']);
            $crud2     = Db::name('trustee')->insertGetId([
                'user_id'      => $userInfo['id'],
                'orderid'      => make_orderid($time, 'trustee'),
                'symbol'       => $param['symbol'],
                'amount'       => $netAmt,
                'type'         => $param['type'],
                'fee'          => $config['trustee_fee'],
                'double_throw' => $param['type'] == '随托随取' ? 0 : 1,
                'auto_renewal' => $param['type'] == '随托随取' ? 0 : $param['auto_renewal'],
                'start_date'   => $startDate,
                'stop_date'    => $stopDate,
                'create_time'  => $time,
            ]);

            // 记录平台收益
            $crud3 = Db::name('income_plat')->insert([
                'order_id'    => $crud2,
                'symbol'      => $param['symbol'],
                'amount'      => bcadd('0', $config['trustee_fee'], 8),
                'type'        => 1,
                'create_time' => $time,
            ]);

            // 检测所有操作是否都正常执行
            if (!$crud1 || !$crud2 || !$crud3) {
                throw new Exception("未知错误", 1);
            }

            // 提交事务
            Db::commit();
            return ['data' => $crud2];

        } catch (\Exception $e) {

            // 回滚事务
            Db::rollback();
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * 取消托管订单
     *
     * @access public
     * @return array
     */
    public function doCancel($id)
    {
        // 订单信息
        $order = $this->get($id);

        // 收益截止日期
        $yesterday = date('Ymd', strtotime('-1 day'));

        // 结算托管收益,定义更新需要的表名
        $table1 = config('database.prefix') . 'income_daily';
        $table2 = config('database.prefix') . 'user_capital';
        $table3 = config('database.prefix') . 'income_user';
        $table4 = config('database.prefix') . 'income_inviter';
        $table5 = config('database.prefix') . 'income_plat';
        $table6 = config('database.prefix') . 'trustee';

        // 更新每日收益表SQL模板
        $template1 = "update {$table1} set status=1 where trustee_id=%s";
        // 更新用户资产表SQL模板
        $template2 = "update {$table2} set available=available+%s,income=income+%s,freeze=freeze-%s,ver='%s' where id=%s and ver='%s'";
        // 更新用户收益表SQL模板
        $template3 = "insert into {$table3} (user_id,trustee_id,amount,date,create_time) values (%s,%s,%s,%s,%s)";
        // 更新邀请人收益表SQL模板
        $template4 = "insert into {$table4} (inviter_id,trustee_id,amount,date,create_time) values (%s,%s,%s,%s,%s)";
        // 更新平台收益表SQL模板
        $template5 = "insert into {$table5} (amount,date,create_time,order_id,symbol) values (%s,%s,%s,%s,'%s')";
        // 更新托管订单表SQL模板
        $template6 = "update {$table6} set status=(case `type` when '随托随取' then 2 else 0 end) where id=%s";

        // 人民币换算模型
        $cnyModel = model('SymbolCny');

        // 需要执行的SQL语句
        $sqlSet = array();
        // 修改托管订单状态为已取消
        array_push($sqlSet, sprintf($template6, $id));

        if ($order['type'] !== '随托随取') {

            // 查询是否易产生收益
            $where = ['trustee_id' => $id, 'status' => 0];
            $exist = Db::name('income_daily')->where($where)->count();
            if ($exist) {
                // 有收益

                // 按最低收益率结算收益
                $map    = ['symbol' => $order['symbol'], 'type' => $order['type']];
                $rate   = Db::name('trustee_config')->where($map)->value('income_rate_min');
                $daily  = bcmul($order['amount'], $rate / 100, 8);
                $income = floatval(bcmul($daily, $exist, 8));

                // 计算收益分成
                $inviter = Db::name('user')->where('id', $order['user_id'])->value('inviter_id');
                if ($inviter) {
                    // 邀请人收益
                    $ivticm = $income * 0.2;
                    array_push($sqlSet, sprintf($template4, $inviter, $order['id'], $ivticm, $yesterday, time()));
                    // 受益人资产变更
                    $ivtcpt = Db::name('user_capital')
                        ->where(['user_id' => $inviter, 'symbol' => $order['symbol']])
                        ->find();
                    $newVar = Random::uuid();
                    array_push($sqlSet, sprintf($template2, $ivticm, $ivticm, 0, $newVar, $ivtcpt['id'], $ivtcpt['ver']));
                    // 平台收益
                    array_push($sqlSet, sprintf($template5, $income * 0.1, $yesterday, time(), $order['id'], $order['symbol']));

                } else {
                    // 平台收益
                    array_push($sqlSet, sprintf($template5, $income * 0.3, $yesterday, time(), $order['id'], $order['symbol']));
                }

                // 用户个人收益
                $usericm = $income * 0.7;
                array_push($sqlSet, sprintf($template3, $order['user_id'], $order['id'], $usericm, $yesterday, time()));

                // 修改收益记录结算状态
                array_push($sqlSet, sprintf($template1, $order['id']));

                // 启动事务
                Db::startTrans();
                try {
                    foreach ($sqlSet as $v) {
                        $att = Db::execute($v);
                        if (!$att) {
                            throw new Exception("未知错误", 1);
                        }
                    }

                    // 用户资产变更(将订单本金和收益计入用户可用资产和收益资产，释放冻结资产)
                    $capital = Db::name('user_capital')
                        ->where(['user_id' => $order['user_id'], 'symbol' => $order['symbol']])
                        ->find();
                    $newVar = Random::uuid();
                    $lastec = sprintf($template2, floatval(bcadd($order['amount'], $usericm, 8)), $usericm, floatval($order['amount']), $newVar, $capital['id'], $capital['ver']);
                    $att    = Db::execute($lastec);
                    if (!$att) {
                        throw new Exception("未知错误", 1);
                    }

                    // 计算人民币数额
                    $capital = Db::name('user_capital')->find($capital['id']);
                    $att     = Db::name('user_capital')->update([
                        'id'            => $capital['id'],
                        'available_cny' => $cnyModel->convertSymbolToCny($order['symbol'], $capital['available']),
                        'freeze_cny'    => $cnyModel->convertSymbolToCny($order['symbol'], $capital['freeze']),
                        'income_cny'    => $cnyModel->convertSymbolToCny($order['symbol'], $capital['income']),
                    ]);
                    if (!$att) {
                        throw new Exception("未知错误", 1);
                    }

                    // 提交事务
                    Db::commit();
                    return ['data' => ''];
                } catch (\Exception $e) {
                    // 回滚事务
                    Db::rollback();
                    return ['error' => $e->getMessage()];
                }
            }
        }

        // 用户资产变更(将订单本金计入用户可用资产，释放冻结资产)
        $capital = Db::name('user_capital')
            ->where(['user_id' => $order['user_id'], 'symbol' => $order['symbol']])
            ->find();
        $newVar = Random::uuid();
        array_push($sqlSet, sprintf($template2, floatval($order['amount']), 0, floatval($order['amount']), $newVar, $capital['id'], $capital['ver']));

        // 启动事务
        Db::startTrans();
        try {
            foreach ($sqlSet as $v) {
                $att = Db::execute($v);
                if (!$att) {
                    throw new Exception("未知错误", 1);
                }
            }

            // 计算人民币数额
            $capital = Db::name('user_capital')->find($capital['id']);
            $att     = Db::name('user_capital')->update([
                'id'            => $capital['id'],
                'available_cny' => $cnyModel->convertSymbolToCny($order['symbol'], $capital['available']),
                'freeze_cny'    => $cnyModel->convertSymbolToCny($order['symbol'], $capital['freeze']),
                'income_cny'    => $cnyModel->convertSymbolToCny($order['symbol'], $capital['income']),
            ]);
            if (!$att) {
                throw new Exception("未知错误", 1);
            }

            // 提交事务
            Db::commit();
            return ['data' => ''];
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * 托管订单详情
     *
     * @access public
     * @return array
     */
    public function getDetail($id)
    {
        // 查找订单
        $order = $this->get($id);
        if (!$order) {
            return ['error' => '订单错误'];
        }

        $order['title']       = strtoupper($order['symbol']);
        $order['create_time'] = date('Y-m-d H:i:s', $order['create_time']);

        // 匹配收益率
        $trusteeConf = Db::name('trustee_config')
            ->where(['symbol' => $order['symbol'], 'type' => $order['type']])
            ->find();
        if ($order['status'] == 0) {
            $order['income_rate'] = $trusteeConf['income_rate_min'];
        } else {
            $order['income_rate'] = [$trusteeConf['income_rate_min'], $trusteeConf['income_rate_max']];
        }

        // 计算托管期
        $order['period'] = $trusteeConf['period'];
        if ($order['status'] == 0 || $order['type'] == '随托随取') {
            $order['period'] = Db::name('income_daily')
                ->where(['trustee_id' => $order['id']])
                ->count();
        }

        // 计算托管订单收益
        $order['income'] = $this->getIncome($order);

        return ['data' => $order];
    }

    /**
     * 计算昨日收益和累计收益
     *
     * @access public
     * @param array $order 托管订单信息
     * @return array
     */
    public function getIncome($order)
    {
        // 计算人民币换算模型
        $cnyModel = model('\app\index\model\SymbolCny');

        // 计算昨日收益和累计收益
        if ($order['status'] == 0 || $order['status'] == 2 || $order['type'] == '随托随取') {
            $yesterday = Db::name('income_daily')
                ->where([
                    'trustee_id' => $order['id'],
                    'date'       => date('Ymd', strtotime('-1 day')),
                ])->value('amount');
            $total = Db::name('income_user')
                ->where(['trustee_id' => $order['id']])
                ->sum('amount');
            return [
                'type'          => 1,
                'yesterday'     => format_symbol_amount($yesterday, 6),
                'yesterday_cny' => $cnyModel->convertSymbolToCny($order['symbol'], $yesterday, 2),
                'total'         => format_symbol_amount($total, 6),
                'total_cny'     => $cnyModel->convertSymbolToCny($order['symbol'], $total, 2),
            ];
        } else {
            $yesterday = Db::name('income_daily')
                ->where([
                    'trustee_id' => $order['id'],
                    'date'       => date('Ymd', strtotime('-1 day')),
                ])->value('amount');
            $yesterday = bcmul($yesterday, '0.700000', 6);

            $todayRate = Db::name('trustee_config')
                ->where(['symbol' => $order['symbol'], 'type' => $order['type']])
                ->value('income_rate_latest');
            $todayIncome = bcmul($order['amount'], $todayRate / 100, 6);
            $totalIncome = bcmul(bcmul($todayIncome, $order['period'], 6), '0.700000', 6);
            return [
                'type'          => 0,
                'yesterday'     => $yesterday,
                'yesterday_cny' => $cnyModel->convertSymbolToCny($order['symbol'], $yesterday, 2),
                'total'         => $totalIncome,
                'total_cny'     => $cnyModel->convertSymbolToCny($order['symbol'], $totalIncome, 2),
            ];
        }
    }
}
