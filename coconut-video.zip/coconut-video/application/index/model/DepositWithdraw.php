<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/5
 * Time: 下午 2:37
 */

namespace app\index\model;

use app\admin\model\Common;
use app\common\bourse\Gateio;
use think\Db;
use think\Log;

class DepositWithdraw extends Common
{
    protected $name = 'user_deposit';

    /**
     * deposit_withdraw_save
     * 更新最新充币提币记录
     *
     * @access public
     * @return array
     */
    public function deposit_withdraw_save()
    {
        $start      = $this->order('id desc')->value('timestamp');
        $end        = time();
        $unfinished = array();
        $addressArr = Db::name('coin_info')->column('symbol,deposit_addr');

        if (!$start) {
            $start = strtotime('2019-01-01');
        } else {
            $unfinished = $this->where('status', 'neq', 'DONE')->order('id')->select();
            if ($unfinished) {
                $start = $unfinished[0]['timestamp'];
            } else {
                $start++;
            }
        }

        $bourse   = new Gateio();
        $response = $bourse->get_deposites_withdrawals($start, $end);
        if (!$response || ($response['result'] != 'true')) {
            // 获取失败
            Log::write('更新最新充币提币记录:failed', 'info');
            return ['error' => '充币提币记录更新失败: ' . ($response ? $response['message'] : 'unknown error')];
        }

        $orders = array();
        if ($response['deposits']) {
            $deposits = $response['deposits'];
            foreach ($deposits as $k => $v) {
                array_push($orders, array_merge($v, [
                    'type'    => 'deposit',
                    'address' => $addressArr[$v['symbol']],
                ]));
            }
        }
        if ($response['withdraws']) {
            $withdraws = $response['withdraws'];
            foreach ($withdraws as $k => $v) {
                array_push($orders, array_merge($v, ['type' => 'withdraw']));
            }
        }

        $sortOrders = array();
        $orderTimes = array_column($orders, 'timestamp');
        sort($orderTimes);
        foreach ($orderTimes as $orderTime) {
            foreach ($orders as $k => $v) {
                if ($v['timestamp'] == $orderTime) {
                    array_push($sortOrders, $v);
                    unset($orders[$k]);
                    break;
                }
            }
        }

        // 更新已保存过的状态不是DONE的历史记录
        if ($unfinished) {
            $messages = array();
            foreach ($unfinished as $k => $v) {
                foreach ($sortOrders as $kk => $vv) {
                    if ($vv['id'] == $v['raw_id']) {
                        $unfinished[$k] = [
                            'id'     => $v['id'],
                            'status' => $vv['status'],
                        ];
                        if (($v['user_id'] != 0) && $vv['status'] == 'DONE') {
                            array_push($messages, [
                                'user_id' => $v['user_id'],
                                'title'   => '充币到账提醒',
                                'content' => sprintf("亲爱的用户，您于%s充值%s个%s已经到账!", date('Y-m-d H:i:s', $v['timestamp']), $v['amount'], $v['symbol']),
                            ]);
                        }
                        unset($sortOrders[$kk]);
                        break;
                    }
                }
            }
            Db::name('user_message')->insertAll($messages);
            $this->saveAll($unfinished);
        }

        // 储存新纪录
        if ($sortOrders) {
            $orders = copy_properties($sortOrders, ['currency' => 'symbol', 'id' => 'raw_id']);
            array_walk($orders, function (&$item) {
                $item['symbol']  = strtolower($item['symbol']);
                $item['orderid'] = make_orderid($item['timestamp'], $item['type']);
            });
            $this->saveAll($orders);
        }

        // 更新记录写入日志
        Log::write('更新最新充币提币记录:success', 'info');
        return [
            'update' => count($unfinished),
            'insert' => count($orders),
            'start' => $start,
            'end' => $end,
        ];
    }
}
