<?php

namespace app\index\model;

use app\admin\model\Common;
use com\easy\Random;
use think\Db;
use think\Exception;
use app\common\bourse\Gateio;

class UserCapital extends Common
{
    protected $name = 'user_capital';

    public function getDetail($userId, $symbol)
    {
        $base = [
            'symbol'      => $symbol,
            'symbol_txt'  => strtoupper($symbol),
            'available'   => '0.00000',
            'availablec'  => '0.00000',
            'freeze'      => '0.00000',
            'freezec'     => '0.00000',
            'income'      => '0.00000',
            'incomec'     => '0.00000',
            'income_pend' => '0.00000',
            'sum'         => '0.00000',
            'to_cny'      => '0.00000',
        ];

        $dbrec = $this->where(['user_id' => $userId, 'symbol' => $symbol])->find();
        if (!$dbrec) {
            return $base;
        }

        $sum       = bcadd($dbrec['available'], $dbrec['freeze'], 5);
        $available = format_symbol_amount($dbrec['available'], 5);
        $freeze    = format_symbol_amount($dbrec['freeze'], 5);
        $income    = format_symbol_amount($dbrec['income'], 5);
        $cnyRate   = $this->getCnyRate($symbol);
        $toCny     = bcmul($sum, $cnyRate, 2);
        return array_merge($base, [
            'available'   => $available,
            'availablec'  => bcmul($available, $cnyRate, 2),
            'freeze'      => $freeze,
            'freezec'     => bcmul($freeze, $cnyRate, 2),
            'income'      => $income,
            'incomec'     => bcmul($income, $cnyRate, 2),
            'sum'         => $sum,
            'to_cny'      => bcmul($sum, $cnyRate, 2),
        ]);
    }

    public function getCnyRate($symbol)
    {
        $worthCny = model('SymbolCny')->latest_data();
        foreach ($worthCny as $wc) {
            if ($wc['symbol'] == $symbol) {
                return $wc['cny'];
            }
        }
    }

    public function doWithdraw($param, $userInfo)
    {
        $symbol  = $param['symbol'];
        $address = $param['address'];
        $amount  = $param['amount'];

        // 启动事务
        Db::startTrans();
        try {

            $crud1 = 0;
            $crud2 = 0;

            $where     = ['user_id' => $userInfo['id'], 'symbol' => $symbol];
            $capital   = Db::name('user_capital')->where($where)->find();
            $available = bcsub($capital['available'], $amount, 30);
            $newVer    = Random::uuid();
            $cnyModel  = model('SymbolCny');
            $fee       = Db::name('coin_info')->where('symbol', $symbol)->value('withdraw_fee');

            // 可用资产不足
            if (floatval($capital['available']) < floatval($amount)) {
                throw new Exception("可用资产不足", 1);
            }
            $crud1 = Db::name('user_capital')
                ->where(['id' => $capital['id'], 'ver' => $capital['ver']])
                ->update([
                'available'     => $available,
                'available_cny' => $cnyModel->convertSymbolToCny($symbol, $available),
                'ver'           => $newVer,
            ]);

            $time  = time();
            $crud2 = Db::name('user_withdraw')->insertGetId([
                'user_id'     => $userInfo['id'],
                'orderid'     => make_orderid($time, 'withdraw'),
                'symbol'      => $symbol,
                'amount'      => $amount,
                'address'     => $address,
                'fee'         => $fee,
                'create_time' => $time,
            ]);

            $bourse   = new Gateio();
            $response = $bourse->do_withdraw($symbol, $amount, $address);
            if ($response['result'] == 'false') {
                throw new Exception('提币失败:' . $response['message'], 1);
            }

            // 检测所有操作是否都正常执行
            if (!$crud1 || !$crud2) {
                throw new Exception('未知错误', 1);
            }

            // 提交事务
            Db::commit();
            return ['data' => $crud2];

        } catch (\Exception $e) {

            // 回滚事务
            Db::rollback();
            return ['error' => $e->getMessage()];
        }
    }

    public function doTranslate($param, $userInfo)
    {
        $symbol  = $param['symbol'];
        $transTo = $param['trans_to'];
        $amount  = $param['amount'];
        $toCny1  = model('SymbolCny')->where(['symbol' => $symbol])->value('cny');
        $toCny2  = model('SymbolCny')->where(['symbol' => $transTo])->value('cny');
        $fee     = Db::name('coin_info')->where('symbol', $symbol)->value('trans_fee');
        $raise   = bcdiv(bcmul(bcsub($amount, $fee ?: '0'), $toCny1, 30), $toCny2, 30);
        if (floatval(bcadd($raise, '0', 4)) < 0.0001) {
            return ['error' => '转换数额太小(目标火币不足0.0001)'];
        }

        // 启动事务
        Db::startTrans();
        try {

            $baseMap   = ['user_id' => $userInfo['id']];
            $tableName = 'user_capital';
            $capital   = Db::name($tableName)->where(array_merge($baseMap, ['symbol' => $symbol]))->find();
            $capitalt  = Db::name($tableName)->where(array_merge($baseMap, ['symbol' => $transTo]))->find();
            $newVer    = Random::uuid();
            $newVert   = Random::uuid();
            $cnyModel  = model('SymbolCny');

            // 被转换可用资产不足
            if (floatval($capital['available']) < floatval($amount)) {
                throw new Exception("可用资产不足", 1);
            }

            $crud1 = 0;
            $crud2 = 0;
            $crud3 = 0;

            // 新增或更新转换至币种资产
            if (!$capitalt) {
                $crud1 = Db::name($tableName)->insert([
                    'user_id'       => $userInfo['id'],
                    'symbol'        => $transTo,
                    'available'     => $raise,
                    'available_cny' => $cnyModel->convertSymbolToCny($transTo, $raise),
                ]);
            } else {
                $available = bcadd($capitalt['available'], $raise, 30);
                $crud1     = Db::name($tableName)
                    ->where(['id' => $capitalt['id'], 'ver' => $capitalt['ver']])
                    ->update([
                        'available'     => $available,
                        'available_cny' => $cnyModel->convertSymbolToCny($transTo, $available),
                        'ver'           => $newVert,
                    ]);
            }

            // 更新被转换币种资产
            $available = bcsub($capital['available'], $amount, 30);
            $crud2     = Db::name($tableName)
                ->where(['id' => $capital['id'], 'ver' => $capital['ver']])
                ->update([
                    'available'     => $available,
                    'available_cny' => $cnyModel->convertSymbolToCny($symbol, $available),
                    'ver'           => $newVer,
                ]);

            // 生成转换订单
            $time  = time();
            $crud3 = Db::name('translate')->insertGetId([
                'user_id'      => $userInfo['id'],
                'orderid'      => make_orderid(time(), 'translate'),
                'symbol'       => $symbol,
                'amount'       => bcsub($amount, $fee ?: 0, 30),
                'trans_to'     => $transTo,
                'trans_amount' => $raise,
                'fee'          => $fee ?: '0',
                'create_time'  => $time,
            ]);

            // 记录平台收益
            $crud4 = Db::name('income_plat')->insert([
                'order_id'    => $crud3,
                'symbol'      => $symbol,
                'amount'      => bcadd('0', $fee ?: 0, 8),
                'type'        => 2,
                'create_time' => $time,
            ]);

            // 检测所有操作是否都正常执行
            if (!$crud1 || !$crud2 || !$crud3 || !$crud4) {
                throw new Exception("未知错误", 1);
            }

            // 提交事务
            Db::commit();
            return ['data' => $crud3];

        } catch (\Exception $e) {

            // 回滚事务
            Db::rollback();
            return ['error' => $e->getMessage()];
        }
    }
}
