<?php

namespace app\index\model;

use app\admin\model\Common;
use app\common\bourse\Gateio;
use think\Db;
use think\Log;

class SymbolCny extends Common
{
    /**
     * gateio_save
     * 获取各币种兑换人民币最新数据
     *
     * @access public
     * @return array
     */
    public function latest_data($symbol = '')
    {
        if (!$symbol) {
            return $this->select();
        }

        return $this->where(['symbol' => $symbol])->select();
    }

    /**
     * gateio_save
     * 更新gateio各币种兑换人民币最新数据
     *
     * @access public
     * @return array
     */
    public function gateio_save()
    {
        $bourse  = new Gateio();
        $symbols = array_merge(config('support_symbol'), config('symbol_compare'));
        $before  = Db::name($this->name)->where('bourse', 'gateio')->select();
        if (!$before) {
            $new = array();
            foreach ($symbols as $symbol) {
                $time = time();
                $cny  = $bourse->get_cny($symbol);
                array_push($new, [
                    'bourse'      => 'gateio',
                    'symbol'      => $symbol,
                    'cny'         => $cny,
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'symbol');

            foreach ($symbols as $symbol) {
                $time = time();
                $cny  = $bourse->get_cny($symbol);
                if (in_array($symbol, $pos)) {
                    $idex = array_keys($pos, $symbol)[0];
                    $item = array_merge($before[$idex], [
                        'cny'         => $cny,
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    array_push($new, [
                        'bourse'      => 'gateio',
                        'symbol'      => $symbol,
                        'cny'         => $cny,
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新gateio最新各币种兑换人民币数据【gateio】:success', 'info');

        return true;
    }

    public function convertSymbolToCny($symbol, $amount, $floatLen = null)
    {
        $rates = $this->where(['bourse' => 'gateio'])->select();
        foreach ($rates as $rate) {
            if ($rate['symbol'] == $symbol) {
                return bcmul($rate['cny'], $amount, $floatLen ?: 30);
            }
        }
    }
}
