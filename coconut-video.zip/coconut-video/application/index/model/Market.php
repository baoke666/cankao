<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/27 0027
 * Time: 下午 4:33
 */

namespace app\index\model;

use app\admin\model\Common;
use app\common\bourse\Bitforex;
use app\common\bourse\Cex;
use app\common\bourse\Gateio;
use think\Db;
use think\Log;

class Market extends Common
{
    /**
     * huobi_save
     * 更新最新行情数据【huobi】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function huobi_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'close');

        foreach ($market as $k => $v) {
            if (!in_array($v['symbol'], $haystack, true)) {
                unset($market[$k]);
            }
        }
        array_walk($market, function (&$item) {
            $item['open'] = sctonum($item['open']);
            $item['close'] = sctonum($item['close']);
            unset($item['high']);
            unset($item['low']);
        });

        $before = Db::name($this->name)->where('bourse', 'huobi')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $v) {
                $time = time();
                $skey = array_search($v['symbol'], $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'huobi',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['amount'],
                    'price' => $v['close'],
                    'percent_change' => get_percent_change($v['close'], $v['open']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');
            array_walk($pos, function (&$item) {
                $item = implode('', explode('_', $item));
            });

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($v['symbol'], $pos, true)) {
                    $idex = array_keys($pos, $v['symbol'])[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['amount'],
                        'price' => $v['close'],
                        'percent_change' => get_percent_change($v['close'], $v['open']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($v['symbol'], $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'huobi',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['amount'],
                        'price' => $v['close'],
                        'percent_change' => get_percent_change($v['close'], $v['open']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【huobi】:success', 'info');

        return true;
    }

    /**
     * gateio_save
     * 更新最新行情数据【gateio】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function gateio_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');

        foreach ($market as $k => $v) {
            if (!in_array($k, $haystack, true)) {
                unset($market[$k]);
            }
        }

        $before = Db::name($this->name)->where('bourse', 'gateio')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $k => $v) {
                $time = time();
                $skey = array_search($k, $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'gateio',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['quoteVolume'],
                    'price' => $v['last'],
                    'percent_change' => $v['percentChange'],
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($k, $pos, true)) {
                    $idex = array_keys($pos, $k)[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['quoteVolume'],
                        'price' => $v['last'],
                        'percent_change' => $v['percentChange'],
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($k, $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'gateio',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['quoteVolume'],
                        'price' => $v['last'],
                        'percent_change' => $v['percentChange'],
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【gateio】:success', 'info');

        return true;
    }

    /**
     * binance_save
     * 更新最新行情数据【binance】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function binance_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'close');

        array_walk($market, function (&$item) {
            $item['symbol'] = strtolower($item['symbol']);
        });
        foreach ($market as $k => $v) {
            if (!in_array($v['symbol'], $haystack, true)) {
                unset($market[$k]);
            }
        }

        $before = Db::name($this->name)->where('bourse', 'binance')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $k => $v) {
                $time = time();
                $skey = array_search($v['symbol'], $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'binance',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['volume'],
                    'price' => $v['lastPrice'],
                    'percent_change' => $v['priceChangePercent'],
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');
            array_walk($pos, function (&$item) {
                $item = implode('', explode('_', $item));
            });

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($v['symbol'], $pos, true)) {
                    $idex = array_keys($pos, $v['symbol'])[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['volume'],
                        'price' => $v['lastPrice'],
                        'percent_change' => $v['priceChangePercent'],
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($v['symbol'], $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'binance',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['volume'],
                        'price' => $v['lastPrice'],
                        'percent_change' => $v['priceChangePercent'],
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【binance】:success', 'info');

        return true;
    }

    /**
     * cex_save
     * 更新最新行情数据【cex】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function cex_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');

        $cex = new Cex();
        foreach ($market as $k => $v) {
            if (!in_array($k, $haystack, true)) {
                unset($market[$k]);
            }
        }
        foreach ($market as $k => $v) {
            $kline = $cex->get_kline($k);
            $market[$k] = array_merge($v, [
                'open' => $kline['kline'][0]['open'],
            ]);
        }

        $before = Db::name($this->name)->where('bourse', 'cex')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $k => $v) {
                $time = time();
                $skey = array_search($k, $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'cex',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['vol'],
                    'price' => $v['last'],
                    'percent_change' => get_percent_change($v['last'], $v['open']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($k, $pos, true)) {
                    $idex = array_keys($pos, $k)[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['vol'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $v['open']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($k, $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'cex',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['vol'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $v['open']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【cex】:success', 'info');

        return true;
    }

    /**
     * bitz_save
     * 更新最新行情数据【bitz】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function bitz_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');

        foreach ($market as $k => $v) {
            if (!in_array($k, $haystack, true)) {
                unset($market[$k]);
            }
        }

        $before = Db::name($this->name)->where('bourse', 'bitz')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $k => $v) {
                $time = time();
                $skey = array_search($k, $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'bitz',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['volume'],
                    'price' => $v['now'],
                    'percent_change' => $v['priceChange24h'],
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($k, $pos, true)) {
                    $idex = array_keys($pos, $k)[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['volume'],
                        'price' => $v['now'],
                        'percent_change' => $v['priceChange24h'],
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($k, $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'bitz',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['volume'],
                        'price' => $v['now'],
                        'percent_change' => $v['priceChange24h'],
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【bitz】:success', 'info');

        return true;
    }

    /**
     * bcex_save
     * 更新最新行情数据【bcex】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function bcex_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');

        foreach ($market as $k => $v) {
            $pair = strtolower($v['token'] . '_' . $v['market']);
            if (!in_array($pair, $haystack, true)) {
                unset($market[$k]);
            }
        }

        $before = Db::name($this->name)->where('bourse', 'bcex')->select();
        if (!$before) {

            $new = array();
            foreach ($market as $v) {
                $time = time();
                $skey = array_search(strtolower($v['token'] . '_' . $v['market']), $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'bcex',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['amount'],
                    'price' => $v['latest_price'],
                    'percent_change' => ($v['is_up'] == '1') ? abs($v['percent_change']) : '-' . abs($v['percent_change']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $v) {
                $time = time();
                if (in_array(strtolower($v['token'] . '_' . $v['market']), $pos, true)) {
                    $idex = array_keys($pos, strtolower($v['token'] . '_' . $v['market']))[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['amount'],
                        'price' => $v['latest_price'],
                        'percent_change' => ($v['is_up'] == '1') ? abs($v['percent_change']) : '-' . abs($v['percent_change']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search(strtolower($v['token'] . '_' . $v['market']), $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'bcex',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['amount'],
                        'price' => $v['latest_price'],
                        'percent_change' => ($v['is_up'] == '1') ? abs($v['percent_change']) : '-' . abs($v['percent_change']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【bcex】:success', 'info');

        return true;
    }

    /**
     * bitforex_save
     * 更新最新行情数据【bitforex】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function bitforex_save($market)
    {
        $bourse = new Bitforex();
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');

        $before = Db::name($this->name)
            ->where('bourse', 'bitforex')
            ->select();
        if (!$before) {

            $new = array();
            foreach ($market as $k => $v) {
                $time = time();
                $skey = array_search($k, $haystack);
                $pair = $require[$skey];
                $kline = $bourse->get_kline('coin-' . implode('-', array_reverse(explode('_', $k))));
                array_push($new, [
                    'bourse' => 'bitforex',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['vol'],
                    'price' => $v['last'],
                    'percent_change' => get_percent_change($v['last'], $kline['data'][0]['open']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $k => $v) {
                $time = time();
                if (in_array($k, $pos, true)) {
                    $idex = array_keys($pos, $k)[0];
                    $kline = $bourse->get_kline('coin-' . implode('-', array_reverse(explode('_', $k))));
                    $item = array_merge($before[$idex], [
                        'volume' => $v['vol'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $kline['data'][0]['open']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($k, $haystack);
                    $pair = $require[$skey];
                    $kline = $bourse->get_kline('coin-' . implode('-', array_reverse(explode('_', $k))));
                    array_push($new, [
                        'bourse' => 'bitforex',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['vol'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $kline['data'][0]['open']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【bitforex】:success', 'info');

        return true;
    }

    /**
     * lbank_save
     * 更新最新行情数据【lbank】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function lbank_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');
        foreach ($market as $k => $v) {
            if (!in_array($v['symbol'], $haystack, true)) {
                unset($market[$k]);
            }
        }

        $before = Db::name($this->name)
            ->where('bourse', 'lbank')
            ->select();
        if (!$before) {

            $new = array();
            foreach ($market as $v) {
                $time = time();
                $skey = array_search($v['symbol'], $haystack);
                $pair = $require[$skey];
                array_push($new, [
                    'bourse' => 'lbank',
                    'pair' => $pair['cut'],
                    'pair_l' => $pair['left'],
                    'pair_r' => $pair['right'],
                    'volume' => $v['ticker']['vol'],
                    'price' => $v['ticker']['latest'],
                    'percent_change' => $v['ticker']['change'],
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $v) {
                $time = time();
                if (in_array($v['symbol'], $pos, true)) {
                    $idex = array_keys($pos, $v['symbol'])[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['ticker']['vol'],
                        'price' => $v['ticker']['latest'],
                        'percent_change' => $v['ticker']['change'],
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    $skey = array_search($v['symbol'], $haystack);
                    $pair = $require[$skey];
                    array_push($new, [
                        'bourse' => 'lbank',
                        'pair' => $pair['cut'],
                        'pair_l' => $pair['left'],
                        'pair_r' => $pair['right'],
                        'volume' => $v['ticker']['vol'],
                        'price' => $v['ticker']['latest'],
                        'percent_change' => $v['ticker']['change'],
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【lbank】:success', 'info');

        return true;
    }

    /**
     * okcoin_save
     * 更新最新行情数据【okcoin】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function okcoin_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'cut');
        array_walk($market, function (&$item) {
            $item['symbol'] = implode('_', explode('-', strtolower($item['product_id'])));
        });
        foreach ($market as $k => $v) {
            if (!in_array($v['symbol'], $haystack, true)) {
                unset($market[$k]);
            }
        }
        array_walk($market, function (&$item) use ($require, $haystack) {
            $item['symbol'] = $require[array_keys($haystack, strtolower($item['symbol']))[0]];
        });

        $before = Db::name($this->name)
            ->where('bourse', 'okcoin')
            ->select();
        if (!$before) {

            $new = array();
            foreach ($market as $v) {
                $time = time();
                array_push($new, [
                    'bourse' => 'okcoin',
                    'pair' => $v['symbol']['cut'],
                    'pair_l' => $v['symbol']['left'],
                    'pair_r' => $v['symbol']['right'],
                    'volume' => $v['base_volume_24h'],
                    'price' => $v['last'],
                    'percent_change' => get_percent_change($v['last'], $v['open_24h']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $v) {
                $time = time();
                if (in_array($v['symbol']['cut'], $pos, true)) {
                    $idex = array_keys($pos, $v['symbol']['cut'])[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['base_volume_24h'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $v['open_24h']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    array_push($new, [
                        'bourse' => 'okcoin',
                        'pair' => $v['symbol']['cut'],
                        'pair_l' => $v['symbol']['left'],
                        'pair_r' => $v['symbol']['right'],
                        'volume' => $v['base_volume_24h'],
                        'price' => $v['last'],
                        'percent_change' => get_percent_change($v['last'], $v['open_24h']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【okcoin】:success', 'info');

        return true;
    }

    /**
     * bhex_save
     * 更新最新行情数据【bhex】
     *
     * @access public
     * @param array $market 行情数据
     * @return array
     */
    public function bhex_save($market)
    {
        $require = get_support_pairs();
        $haystack = array_column($require, 'close');
        array_walk($market, function (&$item) use ($haystack) {
            $item['symbol'] = strtolower($item['symbol']);
        });
        foreach ($market as $k => $v) {
            if (!in_array($v['symbol'], $haystack, true)) {
                unset($market[$k]);
            }
        }
        array_walk($market, function (&$item) use ($require, $haystack) {
            $item['symbol'] = $require[array_keys($haystack, strtolower($item['symbol']))[0]];
        });

        $before = Db::name($this->name)
            ->where('bourse', 'bhex')
            ->select();
        if (!$before) {

            $new = array();
            foreach ($market as $v) {
                $time = time();
                array_push($new, [
                    'bourse' => 'bhex',
                    'pair' => $v['symbol']['cut'],
                    'pair_l' => $v['symbol']['left'],
                    'pair_r' => $v['symbol']['right'],
                    'volume' => $v['volume'],
                    'price' => $v['lastPrice'],
                    'percent_change' => get_percent_change($v['lastPrice'], $v['openPrice']),
                    'create_time' => $time,
                ]);
            }

            $this->saveAll($new);

        } else {

            $new = array();
            $old = array();
            $pos = array_column($before, 'pair');

            foreach ($market as $v) {
                $time = time();
                if (in_array($v['symbol']['cut'], $pos, true)) {
                    $idex = array_keys($pos, $v['symbol']['cut'])[0];
                    $item = array_merge($before[$idex], [
                        'volume' => $v['volume'],
                        'price' => $v['lastPrice'],
                        'percent_change' => get_percent_change($v['lastPrice'], $v['openPrice']),
                        'update_time' => $time,
                    ]);
                    array_push($old, $item);
                } else {
                    array_push($new, [
                        'bourse' => 'bhex',
                        'pair' => $v['symbol']['cut'],
                        'pair_l' => $v['symbol']['left'],
                        'pair_r' => $v['symbol']['right'],
                        'volume' => $v['volume'],
                        'price' => $v['lastPrice'],
                        'percent_change' => get_percent_change($v['lastPrice'], $v['openPrice']),
                        'create_time' => $time,
                    ]);
                }
            }

            if ($old) {
                $this->saveAll($old);
            }

            if ($new) {
                $this->saveAll($new);
            }
        }

        // 更新记录写入日志
        Log::write('更新最新行情数据【bhex】:success', 'info');

        return true;
    }

    /**
     * latest_data
     * 获取最新行情数据
     *
     * @access public
     * @return array
     */
    public function latest_data($param)
    {
        if (!$param['symbol']) {
            return null;
        }

        $symbol = $param['symbol'];
        $order = $param['order'] ?: 'pair';
        $rule = $param['rule'] ?: 'asc';
        $market = $this->where('pair_l', $symbol)->order($order . ' ' . $rule)->select();
        $cny = model('SymbolCny')->where(['bourse' => 'gateio'])->select();

        $data = array();
        foreach ($market as $v) {

            $updown = floatval($v['percent_change']);
            $status = ($updown >= 0) ? 'up' : 'down';
            $updown = (($updown < 0) ? '' : '+') . $v['percent_change'];
            $item = [
                'bourse' => $v['bourse'],
                'pair_l' => strtoupper($v['pair_l']),
                'pair_r' => strtoupper($v['pair_r']),
                'volume' => bcadd($v['volume'], '0.00000', 5),
                'price' => bcadd($v['price'], '0.00000000', 8),
                'percent_change' => $updown,
                'status' => $status,
                'cny' => '0.00',
            ];
            foreach ($cny as $c) {
                // 找到相应交易所的人民币数据，暂时都使用gateio
                if ($c['symbol'] == $v['pair_r']) {
                    $item['cny'] = bcmul($v['price'], $c['cny'], 5);
                    break;
                }
            }
            array_push($data, $item);
        }

        return $data;
    }
}
