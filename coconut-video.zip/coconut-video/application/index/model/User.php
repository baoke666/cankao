<?php

namespace app\index\model;

use app\admin\model\Common;
use app\index\model\Smscode;
use com\verify\HonrayVerify;
use think\Db;
use think\Exception;
use com\easy\Random;

class User extends Common
{
    protected $name = 'user';

    public function login($param)
    {
        $username   = $param['username'];
        $password   = $param['password'];
        $gesture    = $param['gesture'];
        $verifyCode = !empty($param['verify_code']) ? $param['verify_code'] : '';
        $verifyKey  = !empty($param['verify_key']) ? $param['verify_key'] : '';

        if (!$gesture) {
            if (empty($username)) {
                $this->error = '帐号不能为空';
                return false;
            }

            if (empty($password) && empty($gesture)) {
                $this->error = '密码不能为空';
                return false;
            }

            if (!$verifyCode) {
                $this->error = '验证码不能为空';
                return false;
            }

            $captcha = new HonrayVerify(config('captcha'));
            if (!$captcha->check($verifyCode, $verifyKey)) {
                $this->error = '验证码错误';
                return false;
            }
        }

        $pwd      = $password ? $password : $gesture;
        $pwdField = $password ? 'password' : 'gesture';
        $userInfo = $this->where('phone', $username)->whereOr('username', $username)->find();
        if (!$userInfo) {
            $this->error = '帐号不存在';
            return false;
        }
        if (user_md5($pwd) !== $userInfo[$pwdField]) {
            $this->error = '密码错误';
            return false;
        }
        // if ($userInfo['status'] === 0) {
        //     $this->error = '帐号已被禁用';
        //     return false;
        // }

        // 判断是否首次登录
        $isFirst = $userInfo['last_login_time'] ? false : true;

        // 更新最后一次登录时间
        $time = time();
        $userInfo->save(['last_login_time' => $time]);

        // 保存缓存
        $authKey = user_md5($userInfo['phone']
            . $userInfo['username'] . $time . mt_rand(1234, 9999));
        $info = [
            'authKey'  => $authKey,
            'userInfo' => $userInfo,
        ];
        cache('Auth_' . $authKey, null);
        cache('Auth_' . $authKey, $info, config('LOGIN_SESSION_VALID'));

        return [
            'authKey' => $authKey,
            'phone'   => $userInfo['phone'],
            'isFirst' => $isFirst
        ];
    }

    public function register($param)
    {
        $po = [];
        $ks = array_keys($param);
        array_push($po, 'verify_key', 'invite_code');

        $temp = array_filter($param, function ($k) use ($po) {
            return !in_array($k, $po);
        }, ARRAY_FILTER_USE_KEY);
        foreach ($temp as $v) {
            if ($v === '') {
                $this->error = '信息不完整';
                return false;
            }
        }

        // 手机号唯一
        if ($this->where('phone', $param['phone'])->find()) {
            $this->error = '手机号已被注册';
            return false;
        }

        // 用户名唯一
        if ($this->where('username', $param['username'])->find()) {
            $this->error = '用户名已存在';
            return false;
        }

        // // 两次密码相同
        // if ($param['password'] !== $param['password2']) {
        //     $this->error = '密码输入不一致';
        //     return false;
        // }

        // 图片验证码
        $verifyCode = !empty($param['verify_code']) ? $param['verify_code'] : '';
        $verifyKey  = !empty($param['verify_key']) ? $param['verify_key'] : '';
        $captcha    = new HonrayVerify(config('captcha'));
        if (!$captcha->check($verifyCode, $verifyKey)) {
            $this->error = '图片验证码错误';
            return false;
        }

        // 短信验证码
        if (!model('Smscode')->checkCode($param['phone'], $param['sms_code'])) {
            $this->error = '短信验证码错误';
            return false;
        }

        $time = time();
        array_push($po, 'verify_code', 'sms_code');
        $data = array_filter($param, function ($k) use ($po) {
            return !in_array($k, $po);
        }, ARRAY_FILTER_USE_KEY);
        $data['password']    = user_md5($data['password']);
        $data['create_time'] = $time;

        Db::startTrans();
        try {

            // 查询邀请人
            $inviterId = 0;
            if ($data['invite_code']) {
                $inviterId = Db::name('user')->where('invite_code', $data['invite_code'])->value('id');
            }

            // 生成邀请码
            $inviteCode = create_invite_code();
            while (Db::name('user')->where('invite_code', $inviteCode)->value('id')) {
                $inviteCode = create_invite_code();
            }

            // 新增用户记录
            $uid = Db::name('user')->insertGetId([
                'phone'       => $data['phone'],
                'username'    => $data['username'],
                'password'    => $data['password'],
                'inviter_id'  => intval($inviterId),
                'invite_code' => $inviteCode,
                'create_time' => time(),
            ]);

            // 初始化用户资产
            $capital = array();
            $symbols = config('support_symbol');
            foreach ($symbols as $symbol) {
                array_push($capital, [
                    'user_id' => $uid,
                    'symbol'  => $symbol,
                    'ver'     => Random::uuid(),
                ]);
            }
            Db::name('user_capital')->insertAll($capital);

            // 修改短信验证码过期时间
            Db::name('sms_code')
                ->where(['phone' => $param['phone']])
                ->update(['expire_time' => $time]);

            // 提交事务
            Db::commit();
            return true;

        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            $this->error = $e->getMessage();
            return false;
        }        
    }

    public function latest($uid)
    {
        if (!$uid) {
            return false;
        } else {
            $data = $this->find($uid);
            $cert = Db::name('user_certificate')->where('user_id', $uid)->find();
            return [
                'serial'          => $data['serial'],
                'username'        => $data['username'],
                'phone'           => $data['phone'],
                'head'            => $data['head'],
                'gesture'         => $data['gesture'] ? 'yes' : 'no',
                'trader'          => $data['trader'] ? 'yes' : 'no',
                'certificate'     => $cert ? $cert['status'] : 'no',
                'certificate_msg' => $cert ? $cert['remark'] : '',
                'status'          => $data['status'],
            ];
        }
    }

    public function certificate($uid, $cert)
    {
        $accept  = array_keys($cert);
        $require = ['realname', 'id_number', 'id_card_front', 'id_card_back', 'id_card_in_hand'];
        foreach ($require as $k) {
            if (!in_array($k, $accept) || !$cert[$k]) {
                return ['error' => '参数不完整'];
            }
        }

        // 插入数据表
        $att = Db::name('user_certificate')->insert([
            'user_id'         => $uid,
            'realname'        => $cert['realname'],
            'id_number'       => $cert['id_number'],
            'id_card_front'   => $cert['id_card_front'],
            'id_card_back'    => $cert['id_card_back'],
            'id_card_in_hand' => $cert['id_card_in_hand'],
            'create_time'     => time(),
        ]);
        if (!$att) {
            return ['error' => '未知错误'];
        }
        return ['data' => ''];
    }
}
