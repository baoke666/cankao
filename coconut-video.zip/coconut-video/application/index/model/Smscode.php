<?php

namespace app\index\model;

use think\Model;
use com\easy\Random;

class Smscode extends Model
{
    protected $name = 'sms_code';

    public function checkCode($phone, $code)
    {
    	$time = time();
        $rec  = $this->where('phone', $phone)->order('id desc')->find();
        if ($code !== $rec['code'] || $rec['expire_time'] <= $time) {
            return false;
        }
        $rec->save(['expire_time' => $time]);
        $uuid = Random::uuid();
        cache('Sms_' . $uuid, $phone, 1200);
        return ['token' => $uuid];
    }
}
