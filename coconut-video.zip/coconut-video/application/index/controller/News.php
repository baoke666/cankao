<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 下午 5:01
 */

namespace app\index\controller;

use app\common\controller\Common;
use think\Db;

class News extends Common
{
    public function refresh()
    {
        $news = file_get_contents('https://unidemo.dcloud.net.cn/api/news');
        $news = json_decode($news, true);
        array_walk($news, function (&$item) {
            $item = [
                'type'         => (mt_rand(0, 1) == 0) ? 'news' : 'message',
                'title'        => $item['title'],
                'index_img'    => $item['cover'],
                'content'      => $item['content'],
                'display_time' => strtotime($item['published_at']),
                'create_time'  => strtotime($item['created_at']),
                'update_time'  => strtotime($item['updated_at']),
            ];
        });
        Db::name('news')->insertAll($news);
    }

    // 分页获取资讯列表
    public function getInformations()
    {
        $type  = $this->param['type'] ?: 'news';
        $start = $this->param['start'] ?: 0;
        $size  = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map   = ['type' => $type, 'status' => 0];
        $total = Db::name('news')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('news')
            ->field('id,title,index_img,display_time')
            ->where($map)
            ->order('id desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) {
            $item['display_time'] = date('Y-m-d H:i:s', $item['display_time']);
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    // 获取资讯详情
    public function getInformationDetail()
    {
        $record = Db::name('news')
            ->field('title,content,index_img,display_time')
            ->where('id', $this->param['id'])
            ->find();
        if (!$record || $record['status'] != 0) {
            return resultArray(['error' => '资讯不存在']);
        }
        $record['display_time'] = date('Y-m-d H:i:s', $record['display_time']);
        return resultArray(['data' => $record]);
    }
}
