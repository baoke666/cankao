<?php
// +----------------------------------------------------------------------
// | Description: Api基础类，验证权限
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\index\controller;

use think\Request;
use think\Db;
use app\common\adapter\AuthAdapter;
use app\common\controller\Common;
use app\index\model\User;

class ApiCommon extends Common
{
    public function _initialize()
    {
        parent::_initialize();
        
        $userInfo = $this->getUserInfo();
        if ($userInfo === false) {
            header('Content-Type:application/json; charset=utf-8');
            exit(json_encode(['code' => 101, 'error' => '账号未登录或登录失效']));
        }

        // 检查账号有效性
        // $map = ['id' => $userInfo['id'], 'status' => 1];
        // if (!User::where($map)->value('id')) {
        //     header('Content-Type:application/json; charset=utf-8');
        //     exit(json_encode(['code' => 103, 'error' => '账号已被删除或禁用']));
        // }
    }

    protected function getUserInfo()
    {
        $header  = Request::instance()->header();
        $authKey = $header['authkey'];
        $cache   = cache('Auth_' . $authKey);
        // 校验authKey和账号登录缓存数据
        if (empty($authKey) || empty($cache)) {
            return false;
        }

        // 更新缓存
        cache('Auth_' . $authKey, $cache, config('LOGIN_SESSION_VALID'));

        return $cache['userInfo'];
    }
}
