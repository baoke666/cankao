<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 下午 7:22
 */

namespace app\index\controller;

use think\Db;
use com\easy\Random;

class Home extends ApiCommon
{
    /**
     * 获取用户个人基本信息
     *
     * @return \think\Response
     */
    public function profile()
    {
        $userInfo = $this->getUserInfo();
        return resultArray(['data' => model('User')->latest($userInfo['id'])]);
    }

    /**
     * 获取用户邀请码
     *
     * @return \think\Response
     */
    public function getInviteCode()
    {
        $userInfo = $this->getUserInfo();
        $linkUrl  = 'http://m.coincobo.cn/#/pages/login-reg/reg/reg?invite_code=' . $userInfo['invite_code'];
        return resultArray(['data' => [
            'qrcode' => create_qrcode($userInfo['id'] . '_invite_code', $linkUrl),
            'code'   => $userInfo['invite_code'],
        ]]);
    }

    /**
     * 设置手势密码
     *
     * @return \think\Response
     */
    public function setGesture()
    {
        $userInfo = $this->getUserInfo();
        $password = $this->param['gesture'];

        $att = model('User')->update(['id' => $userInfo['id'], 'gesture' => user_md5($password)]);
        if ($att) {
            return resultArray(['data' => '']);
        } else {
            return resultArray(['error' => '未知错误']);
        }
    }

    /**
     * 设置交易密码
     *
     * @return \think\Response
     */
    public function setTrader()
    {
        $userInfo = $this->getUserInfo();
        $password = $this->param['trader'];
        
        $att = model('User')->update([
            'id'     => $userInfo['id'],
            'trader' => user_md5($password)
        ]);
        if ($att) {
            return resultArray(['data' => '']);
        } else {
            return resultArray(['error' => '未知错误']);
        }
    }

    /**
     * 校验交易密码
     *
     * @return \think\Response
     */
    public function checkTrader()
    {
        $userInfo = $this->getUserInfo();
        $password = $this->param['trader'];

        $rec = model('User')->find($userInfo['id']);
        if ($rec['trader'] == user_md5($password)) {

            $uuid = Random::uuid();
            cache('Trader_' . $uuid, '1', 600);
            return resultArray(['data' => ['token' => $uuid]]);

        } else {
            return resultArray(['error' => '密码错误']);
        }
    }

    /**
     * 设置登录密码
     *
     * @return \think\Response
     */
    public function setPassword()
    {
        $param = $this->param;
        if (!$param['password']) {
            return resultArray(['error' => '参数有误']);
        }

        // 读取缓存数据(身份令牌)
        $token = cache('Password_' . $param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Password_' . $param['token'], null);

        // 设置密码
        $userInfo = $this->getUserInfo();
        $att      = model('User')->update([
            'id'       => $userInfo['id'],
            'password' => user_md5($param['password'])
        ]);
        if ($att) {
            return resultArray(['data' => '']);
        } else {
            return resultArray(['error' => '未知错误']);
        }
    }

    /**
     * 校验登录密码
     *
     * @return \think\Response
     */
    public function checkPassword()
    {
        $userInfo = $this->getUserInfo();
        $password = $this->param['password'];

        $rec = model('User')->find($userInfo['id']);
        if ($rec['password'] == user_md5($password)) {

            $uuid = Random::uuid();
            cache('Password_' . $uuid, '1', 600);
            return resultArray(['data' => ['token' => $uuid]]);

        } else {
            return resultArray(['error' => '密码错误']);
        }
    }

    /**
     * 设置用户头像
     *
     * @return \think\Response
     */
    public function setHead()
    {
        $userInfo = $this->getUserInfo();
        $head     = $this->param['head'];

        $att = model('User')->update([
            'id'   => $userInfo['id'],
            'head' => $head,
        ]);
        if ($att) {
            return resultArray(['data' => '']);
        } else {
            return resultArray(['error' => '未知错误']);
        }
    }

    /**
     * 设置实名认证
     *
     * @return \think\Response
     */
    public function certificate()
    {
        $userInfo = $this->getUserInfo();
        return resultArray(model('User')->certificate($userInfo['id'], $this->param));
    }

    /**
     * 上传图片
     *
     * @return \think\Response
     */
    public function upimg()
    {
        // 获取表单上传文件
        $file = request()->file('image');
        return resultArray(save_img($file));
    }

    /**
     * 获取消息提醒
     *
     * @return \think\Response
     */
    public function getMessageNotice()
    {
        $userInfo  = $this->getUserInfo();
        $newMsgCnt = Db::name('user_message')
            ->where(['user_id' => $userInfo['id'], 'status' => 0])
            ->count();
        $newFeedback = Db::name('feedback')
            ->where('user_id', $userInfo['id'])
            ->where('pid', '<>', '0')
            ->where('type', '=', '0')
            ->where('status', '=', '0')
            ->group('pid')
            ->count();
        return resultArray(['data' => $newMsgCnt + $newFeedback]);
    }

    /**
     * 获取消息列表
     *
     * @return \think\Response
     */
    public function getMessages()
    {
        $userInfo = $this->getUserInfo();
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map   = ['user_id' => $userInfo['id']];
        $total = Db::name('user_message')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('user_message')
            ->field('id,title,content,status,create_time')
            ->where($map)
            ->order('status,id desc')
            ->limit("{$start},{$size}")
            ->select();
        if ($start == 0) {
            $newFeedback = Db::name('feedback')
                ->where('user_id', $userInfo['id'])
                ->where('pid', '<>', '0')
                ->where('type', '=', '0')
                ->where('status', '=', '0')
                ->group('pid')
                ->count('pid');
            if ($newFeedback) {
                array_unshift($list, [
                    'id'          => 0,
                    'title'       => '工单回复提醒',
                    'content'     => '你有新的工单回复',
                    'status'      => 0,
                    'create_time' => time(),
                ]);
            }
        }
        array_walk($list, function (&$item) {
            $item = array_merge($item, [
                'create_time' => date('Y-m-d H:i:s', $item['create_time']),
            ]);
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 读取消息详情
     *
     * @return \think\Response
     */
    public function readMessage()
    {
        $userInfo = $this->getUserInfo();
        $record = Db::name('user_message')->where('id', $this->param['id'])->find();
        if (!$record || $record['user_id'] != $userInfo['id']) {
            return resultArray(['error' => '消息不存在']);
        }
        if ($record['status'] == 0) {
            Db::name('user_message')->update([
                'id'     => $record['id'],
                'status' => 1,
            ]);
        }
        return resultArray(['data' => [
            'title'   => $record['title'],
            'content' => $record['content'],
            'date'    => date('Y-m-d', $record['create_time']),
            'time'    => date('Y-m-d H:i:s', $record['create_time']),
        ]]);
    }

    /**
     * 核对充币记录
     *
     * @return \think\Response
     */
    public function confirmDeposit()
    {
        $userInfo = $this->getUserInfo();
        $txid     = $this->param['txid'];
        $map      = [
            'txid' => $txid,
            'type' => 'deposit',
        ];
        $record = Db::name('user_deposit')->where($map)->find();
        if (!$record || ($record['user_id'] != 0 && $record['user_id'] != $userInfo['id'])) {
            return resultArray(['error' => '找不到记录']);
        }
        if ($record['status'] != 'DONE') {
            return resultArray(['error' => '订单正在确认中，请稍后再试~']);
        }
        if ($record['user_id'] == $userInfo['id']) {
            return resultArray(['error' => '已经核对过啦~']);
        }

        // 开启事务
        Db::startTrans();
        try {

            $time = time();
            $addr = Db::name('coin_info')
                ->where(['symbol' => $record['symbol']])
                ->value('deposit_addr');
            $att = Db::name('user_deposit')
                ->where(['id' => $record['id']])
                ->update([
                    'user_id'     => $userInfo['id'],
                    'address'     => $addr,
                    'update_time' => $time,
                ]);
            if (!$att) {
                throw new Exception("未知错误", 1);
            }

            if ($record['status'] == 'DONE') {
                $att = Db::name('user_message')->insert([
                    'user_id' => $userInfo['id'],
                    'title'   => '充币到账提醒',
                    'content' => sprintf("亲爱的用户，您于%s充值%s个%s已经到账!", date('Y-m-d H:i:s', $record['timestamp']), $record['amount'], $record['symbol']),
                ]);
                if (!$att) {
                    throw new Exception("未知错误", 1);
                }
            }

            $rate    = model('SymbolCny')->latest_data($record['symbol']);
            $capital = Db::name('user_capital')
                ->where(['user_id' => $userInfo['id'], 'symbol' => $record['symbol']])
                ->find();
            $saveData = [];
            if (!$capital) {
                $saveData = [
                    'user_id'       => $userInfo['id'],
                    'symbol'        => $record['symbol'],
                    'available'     => $record['amount'],
                    'available_cny' => bcmul($record['amount'], $rate['cny']),
                    'freeze'        => 0,
                    'freeze_cny'    => 0,
                    'income'        => 0,
                    'income_cny'    => 0,
                    'ver'           => Random::uuid(),
                ];
            } else {
                $available = bcadd($capital['available'], $record['amount'], 30);
                $newVer    = Random::uuid();
                $saveData  = [
                    'available'     => $available,
                    'available_cny' => bcmul($available, $rate[0]['cny'], 2),
                    'ver'           => $newVer,
                ];
            }

            $att = $capital
                ? Db::name('user_capital')->where(['id' => $capital['id'], 'ver' => $capital['ver']])->update($saveData)
                : Db::name('user_capital')->insert($saveData);
            if (!$att) {
                throw new Exception("未知错误", 1);
            }

            // 提交事务
            Db::commit();
            return resultArray(['data' => [
                'txid'        => $record['txid'],
                'symbol'      => strtoupper($record['symbol']),
                'orderid'     => $record['orderid'],
                'address'     => $addr,
                'amount'      => bcadd($record['amount'], '0.0000', 4),
                'create_time' => date('Y-m-d H:i:s', $record['timestamp']),
                'update_time' => date('Y-m-d H:i:s', $time),
                'status'      => $record['status'],
            ]]);

        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return resultArray(['error' => $e->getMessage()]);
        }   
    }

    /**
     * 获取邀请受益汇总信息
     *
     * @return \think\Response
     */
    public function getInviteCounting()
    {
        $userInfo = $this->getUserInfo();
        $cnyModel = model('SymbolCny');
        // 真实的邀请受益人数
        $ivCntReal = Db::name('user')->where(['inviter_id' => $userInfo['id']])->count();
        // 后台设置的受益人数
        $ivCntFake = Db::name('fake_invite')->where(['user_id' => $userInfo['id']])->value('count');
        // 真实的受益记录
        $ivListReal = Db::name('income_inviter')
            ->alias('a')
            ->field('a.amount,b.symbol')
            ->join('trustee b', 'a.trustee_id=b.id')
            ->where('a.inviter_id', $userInfo['id'])
            ->select();
        // 真实的受益累计数额(人民币)
        $ivAmtReal = '0';
        foreach ($ivListReal as $v) {
            $ivAmtReal = bcadd($ivAmtReal, $cnyModel->convertSymbolToCny($v['symbol'], $v['amount'], 2), 2);
        }
        // 后台设置的受益累计数额(人民币)
        $ivAmtFake = Db::name('fake_invite')->where(['user_id' => $userInfo['id']])->value('amount');
        // 后台设置的受益记录(人民币)
        $ivAmtFake2 = Db::name('fake_income')->where(['user_id' => $userInfo['id']])->sum('amount');

        return resultArray([
            'data' => [
                'count'  => bcadd($ivCntReal, $ivCntFake ?: '0'),
                'amount' => bcadd(bcadd($ivAmtReal, $ivAmtFake2, 2), $ivAmtFake ?: '0', 2),
            ]
        ]);
    }

    /**
     * 获取邀请受益记录
     *
     * @return \think\Response
     */
    public function getInviteIncomes()
    {
        $userInfo = $this->getUserInfo();
        $cnyModel = model('SymbolCny');
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $realIncomes = Db::name('income_inviter')
            ->alias('a')
            ->field('u.phone,b.symbol,sum(a.amount) amount,max(a.create_time) create_time')
            ->join('trustee b', 'a.trustee_id=b.id')
            ->join('user u', 'b.user_id=u.id')
            ->where(['a.inviter_id' => $userInfo['id']])
            ->group('trustee_id')
            ->buildSql();
        $fakeIncomes = Db::name('fake_income')
            ->field("phone,'cny' symbol,amount,create_time")
            ->where('user_id', $userInfo['id'])
            ->buildSql();
        $subQuery = Db::table($realIncomes . ' r')
            ->union($fakeIncomes)
            ->buildSql();
        $total = Db::table($subQuery . ' s')->count();
        $list  = Db::table($subQuery . ' s')
            ->order('create_time desc')
            ->limit("{$start},{$size}")
            ->select();
        foreach ($list as $k => $v) {
            if ($v['symbol'] != 'cny') {
                $list[$k]['amount'] = $cnyModel->convertSymbolToCny($v['symbol'], $v['amount'], 4);
            } else {
                $list[$k]['amount'] = format_symbol_amount($v['amount'], 4);
            }
            $list[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
            unset($list[$k]['symbol']);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }

        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 提交工单
     *
     * @return \think\Response
     */
    public function addFeedback()
    {
        $userInfo = $this->getUserInfo();
        $param    = $this->param;
        if (!$param['content']) {
            return resultArray(['error' => '参数错误']);
        }

        $fid = Db::name('feedback')->insertGetId([
            'user_id'     => $userInfo['id'],
            'content'     => $param['content'],
            'evidence'    => $param['evidence'],
            'type'        => 1,
            'create_time' => time(),
        ]);
        return resultArray($fid ? ['data' => $fid] : ['error' => '工单提交失败']);
    }

    /**
     * 获取工单列表
     *
     * @return \think\Response
     */
    public function getFeedbacks()
    {
        $userInfo = $this->getUserInfo();
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map   = ['user_id' => $userInfo['id'], 'pid' => 0];
        $total = Db::name('feedback')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('feedback')
            ->field('id,content,create_time,evidence,0 new_replay')
            ->where($map)
            ->order('status,id desc')
            ->limit("{$start},{$size}")
            ->select();
        $replay = Db::name('feedback')
            ->field('pid,count(1) cnt')
            ->where('type', 0)
            ->where('status', 0)
            ->where('pid', 'in', array_column($list, 'id'))
            ->group('pid')
            ->select();
        array_walk($list, function (&$item) use ($replay) {
            $item['create_time'] = date('Y-m-d H:i:s', $item['create_time']);
            foreach ($replay as $r) {
                if ($r['pid'] == $item['id']) {
                    $item['new_replay'] = 1;
                    break;
                }
            }
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取工单详情
     *
     * @return \think\Response
     */
    public function getFeedbackDetail()
    {
        $userInfo = $this->getUserInfo();
        $fbId     = $this->param['id'];
        $map      = [
            'id'      => $fbId,
            'user_id' => $userInfo['id'],
        ];
        $feedback = Db::name('feedback')->where($map)->find();
        if (!$feedback) {
            return resultArray(['error' => '工单不存在']);
        }

        Db::name('feedback')->where('pid', $fbId)->update(['status' => 1]);
        $list = Db::name('feedback')
            ->field('content,create_time,type,evidence')
            ->where('id', '=', $feedback['id'])
            ->whereOr('pid', '=', $feedback['id'])
            ->order('id desc')
            ->select();
        array_walk($list, function (&$item) use ($symbol) {
            $item = array_merge($item, [
                'create_time' => date('Y-m-d H:i:s', $item['create_time']),
            ]);
        });
        return resultArray(['data' => $list]);
    }

    /**
     * 工单留言
     *
     * @return \think\Response
     */
    public function replyFeedback()
    {
        $userInfo = $this->getUserInfo();
        $param    = $this->param;
        if (!$param['feedback_id'] || !$param['content']) {
            return resultArray(['error' => '参数错误']);
        }

        $fid = Db::name('feedback')->insertGetId([
            'user_id'     => $userInfo['id'],
            'content'     => $param['content'],
            'pid'         => $param['feedback_id'],
            'create_time' => time(),
            'type'        => 1,
        ]);
        return resultArray($fid ? ['data' => '留言成功'] : ['error' => '留言失败']);
    }
}
