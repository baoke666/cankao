<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 下午 4:55
 */

namespace app\index\controller;

use app\common\bourse\Binance;
use app\common\bourse\Bitz;
use app\common\bourse\Cex;
use app\common\bourse\Gateio;
use app\common\bourse\Huobi;
use app\common\bourse\Bcex;
use app\common\bourse\Bitforex;
use app\common\bourse\Lbank;
use app\common\bourse\Okcoin;
use app\common\bourse\Bhex;
use app\common\controller\Common;
use com\easy\Random;
use think\Db;
use think\Exception;
use think\Log;

class Market extends Common
{
    public function _initialize()
    {
        parent::_initialize();
    }

    /**
     * 获取系统支持的币种列表
     *
     * @return \think\Response
     */
    public function getSupportSymbol()
    {
        return resultArray(['data' => get_support_symbols()]);
    }

    /**
     * 更新最新行情数据【huobi】
     *
     * @return \think\Response
     */
    public function updateHuobiMarket()
    {
        $bourse = new Huobi();
        $market = $bourse->get_tickers();
        if (!$market || $market["status"] == 'error') {
            // 更新记录写入日志
            $error = $market['err-code'] . "::" . $market['err-msg'];
            Log::write('更新最新行情数据【huobi】:failed ' . $error, 'info');
            return resultArray(['error' => $error]);
        }

        $model = model('Market');
        return resultArray(['data' => $model->huobi_save($market['data'])]);
    }

    /**
     * 更新最新行情数据【gateio】
     *
     * @return \think\Response
     */
    public function updateGateioMarket()
    {
        $bourse = new Gateio();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【gateio】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->gateio_save($market)]);
    }

    /**
     * 更新各币种兑换人民币最新数据【gateio】
     *
     * @return \think\Response
     */
    public function updateGateioCny()
    {
        $model = model('SymbolCny');
        return resultArray(['data' => $model->gateio_save()]);
    }

    /**
     * 更新最新行情数据【binance】
     *
     * @return \think\Response
     */
    public function updateBinanceMarket()
    {
        $bourse = new Binance();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【binance】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->binance_save($market)]);
    }

    /**
     * 更新最新行情数据【cex】
     *
     * @return \think\Response
     */
    public function updateCexMarket()
    {
        $bourse = new Cex();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【cex】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->cex_save($market)]);
    }

    /**
     * 更新最新行情数据【bitz】
     *
     * @return \think\Response
     */
    public function updateBitzMarket()
    {
        $bourse = new Bitz();
        $market = $bourse->tickerall([]);
        if (!$market || $market['status'] != '200') {
            // 更新记录写入日志
            Log::write('更新最新行情数据【bitz】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->bitz_save($market['data'])]);
    }

    /**
     * 更新最新行情数据【bcex】
     *
     * @return \think\Response
     */
    public function updateBcexMarket()
    {
        $bourse = new Bcex();
        $market = $bourse->get_tickers();
        if (!$market || $market['code'] != '0') {
            // 更新记录写入日志
            Log::write('更新最新行情数据【bcex】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        $mdata = [];
        foreach (config('symbol_compare') as $cSymbol) {
            $mdata = array_merge($mdata, $market['data']['main'][strtoupper($cSymbol)]);
        }
        return resultArray(['data' => $model->bcex_save($mdata)]);
    }

    /**
     * 更新最新行情数据【bitforex】
     *
     * @return \think\Response
     */
    public function updateBitforexMarket()
    {
        $require  = get_support_pairs();
        $haystack = array_column($require, 'cut');
        
        $market  = array();
        $bourse  = new Bitforex();
        $symbols = $bourse->get_pairs();
        if (!$symbols || !$symbols['success']) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【bitforex】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }
        array_walk($symbols['data'], function (&$item) {
            $split = explode('-', $item['symbol']);
            array_splice($split, 0, 1);
            $item['pair'] = implode('_', array_reverse($split));
        });
        foreach ($symbols['data'] as $v) {
            if (in_array($v['pair'], $haystack, true)) {
                $getapi = $bourse->get_ticker($v['symbol']);
                $market[$v['pair']] = $getapi['data'];
            }
        }

        $model = model('Market');
        return resultArray(['data' => $model->bitforex_save($market)]);
    }

    /**
     * 更新最新行情数据【lbank】
     *
     * @return \think\Response
     */
    public function updateLbankMarket()
    {
        $bourse = new Lbank();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【lbank】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->lbank_save($market)]);
    }

    /**
     * 更新最新行情数据【okcoin】
     *
     * @return \think\Response
     */
    public function updateOkcoinMarket()
    {
        $bourse = new Okcoin();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【okcoin】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->okcoin_save($market)]);
    }

    /**
     * 更新最新行情数据【bhex】
     *
     * @return \think\Response
     */
    public function updateBhexMarket()
    {
        $bourse = new Bhex();
        $market = $bourse->get_tickers();
        if (!$market) {
            // 更新记录写入日志
            Log::write('更新最新行情数据【bhex】:failed', 'info');
            return resultArray(['error' => 'failed']);
        }

        $model = model('Market');
        return resultArray(['data' => $model->bhex_save($market)]);
    }

    /**
     * 获取最新行情数据
     *
     * @return \think\Response
     */
    public function refreshMarket()
    {
        $model = model('Market');
        return resultArray(['data' => $model->latest_data($this->param)]);
    }

    /**
     * 更新最新虚拟货币充提记录
     *
     * @return \think\Response
     */
    public function updateDepositWithdraw()
    {
        $model = model('DepositWithdraw');
        return resultArray(['data' => $model->deposit_withdraw_save()]);
    }

    /**
     * 计算托管收益
     *
     * @return \think\Response
     */
    public function calcIncome()
    {
        $begintime = explode('.', get_mtimestamp(true));
        $today     = date('Ymd', strtotime('-0 day'));
        $yesterday = date('Ymd', strtotime($today . ' -1 day'));
        $result    = ['query' => array(), 'log' => array()];

        /****************** 每日收益 ******************/

        // 查询托管订单并生成每日收益记录
        $table   = config('database.prefix') . 'income_daily';
        $sqlTpl  = "insert into `{$table}` (`trustee_id`,`amount`,`type`,`date`) values (%s,%s,%s,%s)";
        $trustee = Db::name('trustee')
            ->where(function ($query) use ($today, $yesterday) {
                $query->where(['type' => ['neq', '随托随取'], 'start_date' => ['lt', $today], 'stop_date' => ['egt', $yesterday], 'status' => 1]);
            })->whereOr(function ($query) use ($today, $yesterday) {
            $query->where(['type' => '随托随取', 'start_date' => ['lt', $today], 'status' => 1]);
        })->buildSql();
        $existIncome = Db::name('income_daily')->where('date', $yesterday)->buildSql();
        $subQuery    = Db::table($trustee . ' a')
            ->field('a.id,a.user_id,a.symbol,a.amount,a.type,a.double_throw,c.income_rate_latest')
            ->where('b.id', null)
            ->join([$existIncome => 'b'], 'a.id=b.trustee_id', 'left')
            ->join('trustee_config c', 'a.symbol=c.symbol and a.type=c.type')
            ->buildSql();
        $total = Db::table($subQuery . ' s')->count();

        $parse = 0;
        $timer = 0;
        while ($parse < $total) {
            $batch = Db::table($subQuery . ' s')
                ->limit("{$parse},100")
                ->select();
            $incomeSet = array();
            foreach ($batch as $v) {

                // 随机产生收益率并计算收益
                $rate   = bcdiv($v['income_rate_latest'], '100', 4);
                $income = floatval(bcmul($v['amount'], $rate, 8));
                if ($v['double_throw'] == '1') {
                    // 计算复投托管收益
                    $pend   = Db::name('income_daily')->where('trustee_id', $v['id'])->sum('amount');
                    $income = floatval(bcmul(bcadd($v['amount'], $pend, 8), $rate, 8));
                }
                $sql = sprintf($sqlTpl, $v['id'], $income, ($v['type'] == '随托随取') ? 1 : 2, $yesterday);
                array_push($incomeSet, $sql);
                $parse += 1;
            }

            $toexec = implode(';', $incomeSet) . ';';
            array_push($result['query'], $toexec);

            Db::startTrans();
            try {

                $tempTimer = 0;
                foreach ($incomeSet as $v) {
                    $exec = Db::execute($v);
                    if ($exec) {
                        $tempTimer++;
                    } else {
                        throw new Exception("未知错误", 1);
                    }
                }
                // 提交事务
                Db::commit();
                $timer += $tempTimer;
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                array_push($result['log'], '【插入收益记录批次失败!!!】 批次开始托管id:' . $batch[0]['id'] . '批次结束托管id:' . end($batch)['id'] . ' error:' . $e->getMessage());
            }
        }

        $logTpl = '【计算每日收益统计信息】 收益日期:%s, 本次计算托管订单数量:%s, 产生收益记录条数:%s。 ';
        array_push($result['log'], sprintf($logTpl, $yesterday, $total, $timer));

        /****************** 结算收益(随托随取) ******************/

        // 结算托管收益,定义更新需要的表名
        $table1 = config('database.prefix') . 'income_daily';
        $table2 = config('database.prefix') . 'user_capital';
        $table3 = config('database.prefix') . 'income_user';
        $table4 = config('database.prefix') . 'income_inviter';
        $table5 = config('database.prefix') . 'income_plat';
        $table6 = config('database.prefix') . 'trustee';

        // 更新每日收益表SQL模板
        $template1 = "update {$table1} set status=1 where id=%s";
        // 更新用户资产表SQL模板
        $template2 = "update {$table2} set available=available+%s,income=income+%s,freeze=freeze-%s,ver='%s' where id=%s and ver='%s'";
        // 更新用户收益表SQL模板
        $template3 = "insert into {$table3} (user_id,trustee_id,amount,date,create_time) values (%s,%s,%s,%s,%s)";
        // 更新邀请人收益表SQL模板
        $template4 = "insert into {$table4} (inviter_id,trustee_id,amount,date,create_time) values (%s,%s,%s,%s,%s)";
        // 更新平台收益表SQL模板
        $template5 = "insert into {$table5} (amount,date,create_time,order_id,symbol) values (%s,%s,%s,%s,'%s')";
        // 更新托管订单表SQL模板
        $template6 = "update {$table6} set status=2 where id=%s";

        // 计数器
        $timer1 = 0;
        $timer2 = 0;
        $timer3 = 0;
        $timer4 = 0;
        $timer5 = 0;
        $timer6 = 0;

        // 查询订单
        $trustee = Db::name('trustee')
            ->where(['type' => '随托随取', 'status' => 1])
            ->buildSql();
        $subQuery = Db::table($trustee . ' a')
            ->field('a.user_id,a.symbol,b.id,b.trustee_id,b.amount')
            ->where(['b.date' => $yesterday, 'b.status' => 0])
            ->join('income_daily b', 'a.id=b.trustee_id')
            ->buildSql();
        $total = Db::table($subQuery . ' s')->count();
        $parse = 0;
        while ($parse < $total) {

            $sqlSet1 = array(); // 每日收益记录SQL集
            $sqlSet2 = array(); // 用户资产变更SQL集
            $sqlSet3 = array(); // 用户收益分成SQL集
            $sqlSet4 = array(); // 邀请人收益分成SQL集
            $sqlSet5 = array(); // 平台收益分成SQL集
            $sqlSet6 = array(); // 邀请人资产变更SQL集

            // 用户资产变更数据
            $updusr = array();
            // 邀请人资产变更数据
            $updivt = array();
            $batch  = Db::table($subQuery . ' s')
                ->limit("{$parse},100")
                ->select();
            foreach ($batch as $v) {

                // 收益记录状态改为已结算【SQL】
                array_push($sqlSet1, sprintf($template1, $v['id']));

                $income    = floatval($v['amount']);
                $inviterId = Db::name('user')->where('id', $v['user_id'])->value('inviter_id');
                // 记录邀请人和平台收益分成
                if ($inviterId) {
                    $ivticm = $income * 0.2;
                    $iicKey = $inviterId . '_' . $v['symbol'];
                    if (!$updivt[$iicKey]) {
                        $updivt[$iicKey] = $ivticm;
                    } else {
                        $updivt[$iicKey] += $ivticm;
                    }
                    // 记录邀请人收益【SQL】
                    array_push($sqlSet4, sprintf($template4, $inviterId, $v['trustee_id'], $ivticm, $yesterday, time()));
                    // 记录平台收益【SQL】
                    array_push($sqlSet5, sprintf($template5, $income * 0.1, $yesterday, time(), $v['trustee_id'], $v['symbol']));
                } else {
                    // 记录平台收益【SQL】
                    array_push($sqlSet5, sprintf($template5, $income * 0.3, $yesterday, time(), $v['trustee_id'], $v['symbol']));
                }

                // 记录用户个人收益【SQL】
                $userIncome = $income * 0.7;
                array_push($sqlSet3, sprintf($template3, $v['user_id'], $v['trustee_id'], $userIncome, $yesterday, time()));

                $uicKey = $v['user_id'] . '_' . $v['symbol'];
                if (!$updusr[$uicKey]) {
                    $updusr[$uicKey] = $userIncome;
                } else {
                    $updusr[$uicKey] += $userIncome;
                }

                $parse += 1;
            }

            // 记录用户资产变更【SQL】
            foreach ($updusr as $k => $v) {
                $idsymbol = explode('_', $k);
                $capital  = Db::name('user_capital')->where(['user_id' => $idsymbol[0], 'symbol' => $idsymbol[1]])->find();
                $newVar   = Random::uuid();
                array_push($sqlSet2, sprintf($template2, $v, $v, 0, $newVar, $capital['id'], $capital['ver']));
            }

            $toexec = implode(';', $sqlSet1) . ';';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet2) . ';';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet3) . ';';
            array_push($result['query'], $toexec);
            $toexec = $sqlSet4 ? implode(';', $sqlSet4) . ';' : 'inviter income 0 insert';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet5) . ';';
            array_push($result['query'], $toexec);

            Db::startTrans();
            try {

                $tempTimer1 = 0;
                $tempTimer2 = 0;
                $tempTimer3 = 0;
                $tempTimer4 = 0;
                $tempTimer5 = 0;
                $tempTimer6 = 0;
                for ($i = 1; $i <= 5; $i++) {
                    $sqlQueue = 'sqlSet' . $i;
                    $tmrQueue = 'tempTimer' . $i;
                    if ($$sqlQueue) {
                        foreach ($$sqlQueue as $v) {
                            $exec = Db::execute($v);
                            if ($exec) {
                                $$tmrQueue++;
                            } else {
                                throw new Exception("未知错误" . $v, 1);
                            }
                        }
                    }
                }

                // 记录邀请人资产变更【SQL】
                foreach ($updivt as $k => $v) {
                    $idsymbol = explode('_', $k);
                    $capital  = Db::name('user_capital')->where(['user_id' => $idsymbol[0], 'symbol' => $idsymbol[1]])->find();
                    $newVar   = Random::uuid();
                    array_push($sqlSet6, sprintf($template2, $v, $v, 0, $newVar, $capital['id'], $capital['ver']));
                }
                $toexec = $sqlSet6 ? implode(';', $sqlSet6) . ';' : 'inviter capital 0 update';
                array_push($result['query'], $toexec);
                if ($sqlSet6) {
                    foreach ($sqlSet6 as $v) {
                        $exec = Db::execute($v);
                        if ($exec) {
                            $tempTimer6++;
                        } else {
                            throw new Exception("未知错误" . $v, 1);
                        }
                    }
                }

                // 提交事务
                Db::commit();
                $timer1 += $tempTimer1;
                $timer2 += $tempTimer2;
                $timer3 += $tempTimer3;
                $timer4 += $tempTimer4;
                $timer5 += $tempTimer5;
                $timer6 += $tempTimer6;
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                array_push($result['log'], '【随托随取结算批次失败!!!】 批次开始托管id:' . $batch[0]['id'] . '批次结束托管id:' . end($batch)['id'] . ' error:' . $e->getMessage());
            }
        }

        $logTpl = '【随托随取结算统计信息】 收益截止日期:%s, 参与本次计算托管订单数量:%s, 更新收益状态记录:%s, 用户收益%s笔, 邀请人收益%s笔, 平台收益%s笔, 用户资产变更%s笔, 邀请人资产变更%s笔。 ';
        array_push($result['log'], sprintf($logTpl, $yesterday, $total, $timer1, $timer3, $timer4, $timer5, $timer2, $timer6));

        /****************** 结算收益(非随托随取) ******************/

        // 修改收益表SQL模板
        $template1 = "update {$table1} set status=1 where trustee_id=%s";

        // 计数器清零
        $timer1 = 0;
        $timer2 = 0;
        $timer3 = 0;
        $timer4 = 0;
        $timer5 = 0;
        $timer6 = 0;
        $timer7 = 0;
        $timer8 = 0;

        // 查询订单
        $trustee = Db::name('trustee')
            ->field('id,user_id,type,symbol,amount,fee,auto_renewal')
            ->where(['type' => ['neq', '随托随取'], 'stop_date' => $yesterday, 'status' => 1])
            ->buildSql();
        $subQuery = Db::table($trustee . ' a')
            ->field('a.*')
            ->where(['b.date' => $yesterday, 'b.status' => 0])
            ->join('income_daily b', 'a.id=b.trustee_id')
            ->buildSql();
        $total = Db::table($subQuery . ' s')->count();
        $parse = 0;
        while ($parse < $total) {

            $sqlSet1 = array(); // 每日收益记录SQL集
            $sqlSet2 = array(); // 用户资产变更SQL集
            $sqlSet3 = array(); // 用户收益分成SQL集
            $sqlSet4 = array(); // 邀请人收益分成SQL集
            $sqlSet5 = array(); // 平台收益分成SQL集
            $sqlSet6 = array(); // 托管订单状态变更SQL集
            $sqlSet7 = array(); // 邀请人资产变更SQL集

            // 生成自动续托订单数据
            $autoRenewals = array();

            // 用户资产变更数据
            $updusr = array();
            // 邀请人资产变更数据
            $updivt = array();
            $batch  = Db::table($subQuery . ' s')
                ->limit("{$parse},100")
                ->select();
            foreach ($batch as $v) {
                $income = Db::name('income_daily')
                    ->where('trustee_id', $v['id'])
                    ->sum('amount');
                $inviterId = Db::name('user')->where('id', $v['user_id'])->value('inviter_id');
                // 记录邀请人和平台收益分成
                if ($inviterId) {
                    $ivticm = $income * 0.2;
                    $iicKey = $inviterId . '_' . $v['symbol'];
                    if (!$updivt[$iicKey]) {
                        $updivt[$iicKey] = $ivticm;
                    } else {
                        $updivt[$iicKey] += $ivticm;
                    }
                    array_push($sqlSet4, sprintf($template4, $inviterId, $v['id'], $ivticm, $yesterday, time()));
                    array_push($sqlSet5, sprintf($template5, $income * 0.1, $yesterday, time(), $v['id'], $v['symbol']));
                } else {
                    array_push($sqlSet5, sprintf($template5, $income * 0.3, $yesterday, time(), $v['id'], $v['symbol']));
                }

                $userIncome = $income * 0.7;
                array_push($sqlSet3, sprintf($template3, $v['user_id'], $v['id'], $userIncome, $yesterday, time()));
                array_push($sqlSet1, sprintf($template1, $v['id']));
                array_push($sqlSet6, sprintf($template6, $v['id']));

                // 用户资产累加收益数据
                $uicKey = $v['user_id'] . '_' . $v['symbol'];
                if (!$updusr[$uicKey]) {
                    $updusr[$uicKey] = [
                        'benjin' => floatval($v['amount']),
                        'shouyi' => $userIncome,
                    ];
                } else {
                    $updusr[$uicKey]['benjin'] += floatval($v['amount']);
                    $updusr[$uicKey]['shouyi'] += $userIncome;
                }

                // 自动续托订单数据
                if ($v['auto_renewal'] == 1) {
                    array_push($autoRenewals, [
                        'user_id'      => $v['user_id'],
                        'orderid'      => make_orderid(time(), 'trustee'),
                        'type'         => $v['type'],
                        'symbol'       => $v['symbol'],
                        'amount'       => bcsub(bcadd($v['amount'], $userIncome, 4), $v['fee'], 4),
                        'fee'          => 0,
                        'start_date'   => date('Ymd'),
                        'stop_date'    => get_trustee_stopdate(date('Ymd'), $v['type']),
                        'create_time'  => time(),
                        'auto_renewal' => 1,
                        'is_renewal'   => 1,
                    ]);
                    $result['auto_renewals'] = $autoRenewals;
                }

                $parse += 1;
            }

            // 组装用户资产变更SQL集
            foreach ($updusr as $k => $v) {
                $idsymbol = explode('_', $k);
                $capital  = Db::name('user_capital')
                    ->where(['user_id' => $idsymbol[0], 'symbol' => $idsymbol[1]])
                    ->find();
                $newVar = Random::uuid();
                array_push($sqlSet2, sprintf($template2, bcadd($v['benjin'], $v['shouyi'], 8), $v['shouyi'], $v['benjin'], $newVar, $capital['id'], $capital['ver']));
            }

            $toexec = implode(';', $sqlSet1) . ';';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet2) . ';';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet3) . ';';
            array_push($result['query'], $toexec);
            $toexec = $sqlSet4 ? implode(';', $sqlSet4) . ';' : 'inviter income 0 insert';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet5) . ';';
            array_push($result['query'], $toexec);
            $toexec = implode(';', $sqlSet6) . ';';
            array_push($result['query'], $toexec);

            // 启动事务
            Db::startTrans();
            try {

                $tempTimer1 = 0;
                $tempTimer2 = 0;
                $tempTimer3 = 0;
                $tempTimer4 = 0;
                $tempTimer5 = 0;
                $tempTimer6 = 0;
                $tempTimer7 = 0;
                $tempTimer8 = 0;

                for ($i = 1; $i <= 6; $i++) {
                    $sqlQueue = 'sqlSet' . $i;
                    $tmrQueue = 'tempTimer' . $i;
                    if ($$sqlQueue) {
                        foreach ($$sqlQueue as $v) {
                            $exec = Db::execute($v);
                            if ($exec) {
                                $$tmrQueue++;
                            } else {
                                throw new Exception("未知错误", 1);
                            }
                        }
                    }
                }

                // 组装邀请人资产变更SQL集
                foreach ($updivt as $k => $v) {
                    $idsymbol = explode('_', $k);
                    $capital  = Db::name('user_capital')->where(['user_id' => $idsymbol[0], 'symbol' => $idsymbol[1]])->find();
                    $newVar   = Random::uuid();
                    array_push($sqlSet7, sprintf($template2, $v, $v, 0, $newVar, $capital['id'], $capital['ver']));
                }
                $toexec = $sqlSet7 ? implode(';', $sqlSet7) . ';' : 'inviter capital 0 update';
                array_push($result['query'], $toexec);
                if ($sqlSet7) {
                    foreach ($sqlSet7 as $v) {
                        $exec = Db::execute($v);
                        if ($exec) {
                            $tempTimer7++;
                        } else {
                            throw new Exception("邀请人资产变更出错", 1);
                        }
                    }
                }

                // 生成自动续托订单并记录平台所得托管手续费
                if ($autoRenewals) {
                    foreach ($autoRenewals as $v) {
                        $newTid = Db::table($table6)->insertGetId($v);
                        if (!$newTid) {
                            throw new Exception("自动续托出错", 1);
                        } else {
                            $tempTimer8++;
                        }
                    }
                }

                // 提交事务
                Db::commit();
                $timer1 += $tempTimer1;
                $timer2 += $tempTimer2;
                $timer3 += $tempTimer3;
                $timer4 += $tempTimer4;
                $timer5 += $tempTimer5;
                $timer6 += $tempTimer6;
                $timer7 += $tempTimer7;
                $timer8 += $tempTimer8;
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                array_push($result['log'], '【非随托随取结算批次失败!!!】 批次开始托管id:' . $batch[0]['id'] . '批次结束托管id:' . end($batch)['id'] . ' error:' . $e->getMessage());
            }
        }

        $logTpl = '【非随托随取结算统计信息】 收益截止日期:%s, 参与本次计算托管订单数量:%s, 订单状态变更数量:%s, 更新收益状态记录:%s, 用户收益%s笔, 邀请人收益%s笔, 平台收益%s笔, 用户资产变更%s笔, 邀请人资产变更%s笔, 新增自动续托订单数量:%s。';
        array_push($result['log'], sprintf($logTpl, $yesterday, $total, $timer6, $timer1, $timer3, $timer4, $timer5, $timer2, $timer7, $timer8));

        // 更新资产人民币价值
        $timer9 = 0;
        Db::startTrans();
        try {
            $cnyRates = model('SymbolCny')->where('bourse', 'gateio')->select();
            foreach ($cnyRates as $rate) {
                $att = Db::execute("update {$table2} set available_cny=available*{$rate['cny']},freeze_cny=freeze*{$rate['cny']},income_cny=income*{$rate['cny']} where symbol='{$rate['symbol']}'");
                if ($att === false) {
                    throw new Exception("未知错误", 1);
                }
                $timer9 += $att;
            }

            // 提交事务
            Db::commit();

        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            array_push($result['log'], '【更新资产人民币价值失败!!!】 error:' . $e->getMessage());
        }
        array_push($result['log'], '【更新资产人民币价值】 共更新' . $timer9 . '条资产记录');

        // 任务执行情况总结
        $endtime = explode('.', get_mtimestamp(true));
        array_push($result['log'], '【任务开始时间】' . date('Y-m-d H:i:s.', $begintime[0]) . $begintime[1]);
        array_push($result['log'], '【任务结束时间】' . date('Y-m-d H:i:s.', $endtime[0]) . $endtime[1]);

        $log = implode('<br/>', $result['log']);
        Db::name('task_log')->insert([
            'name'        => '统计托管受益',
            'target'      => $yesterday,
            'result'      => $log,
            'create_time' => time(),
            'status'      => (strpos($log, '失败') === false) ? 1 : 0,
        ]);

        // 更新当日收益率
        $incomeConf = Db::name('trustee_config')
            ->where(['income_rate_latest_date' => ['<>', $today]])
            ->select();
        foreach ($incomeConf as $k => $v) {
            Db::name('trustee_config')->where('id', $v['id'])->update([
                'income_rate_latest'      => get_daily_income_rate($v['income_rate_min'], $v['income_rate_max']),
                'income_rate_latest_date' => $today,
            ]);
        }
    }
}
