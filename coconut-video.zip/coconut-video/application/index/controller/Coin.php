<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 下午 7:21
 */

namespace app\index\controller;

use app\common\bourse\Gateio;
use think\Db;

class Coin extends ApiCommon
{
    /**
     * 获取个人资产
     *
     * @return \think\Response
     */
    public function getCapitalProfile()
    {
        $param    = $this->param;
        $userInfo = $this->getUserInfo();
        $symbols  = $param['symbol'] ? [['id' => $param['symbol']]] : get_support_symbols();
        $model    = model('UserCapital');
        $list     = array();
        foreach ($symbols as $s) {
            array_push($list, $model->getDetail($userInfo['id'], $s['id']));
        }

        $sum   = get_cny_sum($list, 'to_cny');
        $rete  = model('SymbolCny')->where(['symbol' => 'btc'])->value('cny');
        $toBtc = bcdiv($sum, $rete, 6);
        $data  = ['data' => [
            'all'  => ['to_btc' => $toBtc, 'to_cny' => $sum],
            'sub'  => [
                'available' => get_cny_sum($list, 'availablec'),
                'freeze'    => get_cny_sum($list, 'freezec'),
                'income'    => get_cny_sum($list, 'incomec'),
            ],
            'list' => $list,
        ]];

        array_walk($data['data']['list'], function (&$item) {
            unset($item['availablec']);
            unset($item['freezec']);
            unset($item['incomec']);
        });

        return resultArray($data);
    }

    /**
     * 获取币种简介
     *
     * @return \think\Response
     */
    public function getSymboProfile()
    {
        $symbol = $this->param['symbol'];
        $info   = Db::name('coin_info')->where(['symbol' => $symbol])->value('profile');
        return resultArray(['data' => $info ?: '']);
    }

    /**
     * 获取充值提示信息
     *
     * @return \think\Response
     */
    public function getDepositTips()
    {
        $table  = 'coin_info';
        $symbol = $this->param['symbol'];
        $config = Db::name($table)->where(['symbol' => $symbol])->find();
        if (!$config || !$config['deposit_addr']) {
            $bourse = new Gateio();
            $getApi = $bourse->get_deposite_address($symbol);
            if (!$getApi) {
                return resultArray(['error' => '获取充币地址失败，请稍后再试']);
            } elseif (strpos($getApi['addr'], 'New address') !== false) {
                return resultArray(['error' => '正在生成充币地址，请稍后刷新页面']);
            } else {
                if ($config) {
                    Db::name($table)->where('id', $config['id'])->update(['deposit_addr' => $getApi['addr']]);
                }
                $config = ['deposit_addr' => $getApi['addr']];
            }
        }

        $address = $config['deposit_addr'];
        return resultArray(['data' => [
            'qrcode' => create_qrcode($symbol, $address),
            'addr'   => $address,
            'notice' => $config['deposit_notice'] ?: '',
        ]]);
    }

    /**
     * 获取提币提示信息
     *
     * @return \think\Response
     */
    public function getWithdrawTips()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $capital  = Db::name('user_capital')->where(['user_id' => $userInfo['id'], 'symbol' => $symbol])->find();
        $config   = Db::name('coin_info')->where(['symbol' => $symbol])->find();
        if (!$config) {
            return resultArray(['error' => '(不可操作)提币功能未设置']);
        }

        // 查询当日已提币数量
        $map = [
            'user_id'     => $userInfo['id'],
            'create_time' => ['between', [strtotime(date('Y-m-d', time())), time()]],
        ];
        $list = Db::name('user_withdraw')
            ->where($map)
            ->select();
        $limitUsed = $list ? array_sum(array_column($list, 'amount')) : 0;

        $model = model('UserCapital');
        return resultArray(['data' => array_merge([
            'notice'    => $config['withdraw_notice'],
            'minimum'   => floatval($config['withdraw_minimum']),
            'maxmum'    => floatval($config['withdraw_maxmum']),
            'surplus'   => floatval($config['withdraw_maxmum']) - $limitUsed,
            'available' => $capital ? format_symbol_amount($capital['available'], 6) : '0.000000',
            'fee'       => $config['withdraw_fee'],
            'fee_cny'   => bcmul($config['withdraw_fee'], $model->getCnyRate($symbol), 2),
        ], ['certificate_threshold' => floatval($config['certificate_threshold'])])]);
    }

    /**
     * 获取转换提示信息
     *
     * @return \think\Response
     */
    public function getTransTips()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $transTo  = $this->param['trans_to'];
        $capital  = Db::name('user_capital')->where(['user_id' => $userInfo['id'], 'symbol' => $symbol])->find();
        $config   = Db::name('coin_info')->where(['symbol' => $symbol])->find();
        if (!$symbol || !$transTo || ($symbol == $transTo)) {
            return resultArray(['error' => '转换参数有误']);
        }
        if (!$config) {
            return resultArray(['error' => '(不可操作)转换功能未设置']);
        }

        $toCny1  = model('SymbolCny')->where(['symbol' => $symbol])->value('cny');
        $toCny2  = model('SymbolCny')->where(['symbol' => $transTo])->value('cny');
        $minimum = floatval(bcdiv('0.0001', bcdiv($toCny1, $toCny2, 6), 4));
        if ($minimum < 0.0001) {
            $minimum = 0.0001;
        }

        return resultArray(['data' => [
            'notice'    => $config['trans_notice'],
            'fee'       => $config['trans_fee'],
            'minimum'   => bcadd($minimum, '0', 4),
            'available' => $capital ? format_symbol_amount($capital['available'], 6) : '0.000000',
        ]]);
    }

    /**
     * 获取托管提示信息
     *
     * @return \think\Response
     */
    public function getTrusteeTips()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $capital  = Db::name('user_capital')->where(['user_id' => $userInfo['id'], 'symbol' => $symbol])->find();
        $info     = Db::name('coin_info')->where(['symbol' => $symbol])->find();
        $config   = Db::name('trustee_config')->where(['symbol' => $symbol])->select();
        if (!$info || !$config) {
            return resultArray(['error' => '(不可操作)该币种托管功能未设置']);
        }
        array_walk($config, function (&$item) {
            unset($item['id']);
            unset($item['income_rate_latest_date']);
        });

        $incomeYesterday = Db::name('income_daily')
            ->alias('a')
            ->join('trustee b', 'a.trustee_id=b.id')
            ->where([
                'a.date'    => date('Ymd', strtotime('-1 day')),
                'b.symbol'  => $symbol,
                'b.user_id' => $userInfo['id'],
            ])->sum('a.amount');
        $incomeTotal = Db::name('income_daily')
            ->alias('a')
            ->join('trustee b', 'a.trustee_id=b.id')
            ->where([
                'b.symbol'  => $symbol,
                'b.user_id' => $userInfo['id'],
            ])->sum('a.amount');
        $cnyModel = model('SymbolCny');

        return resultArray(['data' => [
            'income'    => [
                'yesterday'     => format_symbol_amount($incomeYesterday, 6),
                'yesterday_cny' => $cnyModel->convertSymbolToCny($symbol, $incomeYesterday, 2),
                'total'         => format_symbol_amount($incomeTotal, 6),
                'total_cny'     => $cnyModel->convertSymbolToCny($symbol, $incomeTotal, 2),
            ],
            'available' => $capital ? format_symbol_amount($capital['available'], 6) : '0.000000',
            'minimum'   => bcadd($info['trustee_minimum'], '0', 4),
            'notice'    => $info['trustee_notice'],
            'fee'       => $info['trustee_fee'],
            'types'     => $config,
        ]]);
    }

    /**
     * 提币
     *
     * @return \think\Response
     */
    public function withdraw()
    {
        $userInfo = $this->getUserInfo();
        if (!Db::name('user')->where('id', $userInfo['id'])->value('status')) {
            return resultArray(['error' => '您已被禁用，不能进行托管操作']);
        }

        $param = $this->param;
        if (!$param['symbol'] || !$param['amount'] || !$param['address']) {
            return resultArray(['error' => '提币参数有误']);
        }

        $config = Db::name('coin_info')->where(['symbol' => $param['symbol']])->find();
        if (!$config || is_null($config['withdraw_fee'])) {
            return ['error' => '(不可操作)该币种提币功能未设置'];
        }

        // 读取缓存数据(身份令牌)
        $token = cache('Trader_' . $param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Trader_' . $param['token'], null);
        return resultArray(model('UserCapital')->doWithdraw($param, $userInfo));
    }

    /**
     * 转换
     *
     * @return \think\Response
     */
    public function translate()
    {
        $param = $this->param;
        if (!$param['symbol'] || !$param['trans_to'] ||
            !$param['amount'] || ($param['symbol'] == $param['trans_to'])) {
            return resultArray(['error' => '转换参数有误']);
        }

        $config = Db::name('coin_info')->where(['symbol' => $param['symbol']])->find();
        if (!$config) {
            return ['error' => '(不可操作)该币种转换功能未设置'];
        }

        // 读取缓存数据(身份令牌)
        $token = cache('Trader_' . $param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Trader_' . $param['token'], null);

        $userInfo = $this->getUserInfo();
        return resultArray(model('UserCapital')->doTranslate($param, $userInfo));
    }

    /**
     * 获取充值记录
     *
     * @return \think\Response
     */
    public function getDeposits()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = ['user_id' => $userInfo['id'], 'type' => 'deposit'];
        if ($symbol) {
            $map['symbol'] = $symbol;
        }

        $total = Db::name('user_deposit')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('user_deposit')
            ->field('id,txid,orderid,symbol,amount,address,status,timestamp')
            ->where($map)
            ->order('id desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) {
            $item = array_merge($item, [
                'amount'      => format_symbol_amount($item['amount'], 5),
                'title'       => strtoupper($item['symbol']),
                'create_time' => date('Y-m-d H:i:s', $item['timestamp']),
                'update_time' => date('Y-m-d H:i:s', $item['update_time']),
            ]);
            unset($item['symbol']);
            unset($item['timestamp']);
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取充值详情
     *
     * @return \think\Response
     */
    public function getDepositDetail()
    {
        $record = Db::name('user_deposit')->find($this->param['id']);
        if (!$record || $record['user_id'] == 0) {
            return resultArray(['error' => '找不到记录']);
        }

        unset($record['user_id']);
        unset($record['raw_id']);
        unset($record['txid']);
        unset($record['type']);
        $record['amount']      = format_symbol_amount($record['amount'], 8);
        $record['create_time'] = date('Y-m-d H:i:s', $record['timestamp']);
        $record['update_time'] = date('Y-m-d H:i:s', $record['update_time']);

        return resultArray(['data' => $record]);
    }

    /**
     * 获取提币记录
     *
     * @return \think\Response
     */
    public function getWithdraws()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = [
            'user_id' => $userInfo['id'],
            'symbol'  => $symbol,
        ];
        $total = Db::name('user_withdraw')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('user_withdraw')
            ->field('id,amount,create_time')
            ->where($map)
            ->order('id desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) use ($symbol) {
            $item['title']       = strtoupper($symbol);
            $item['amount']      = format_symbol_amount($item['amount'], 5);
            $item['create_time'] = date('Y-m-d H:i:s', $item['create_time']);
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取提币详情
     *
     * @return \think\Response
     */
    public function getWithdrawDetail()
    {
        $record = Db::name('user_withdraw')->find($this->param['id']);
        if (!$record) {
            return resultArray(['error' => '找不到记录']);
        }

        unset($record['user_id']);
        $record['amount']      = format_symbol_amount($record['amount'], 8);
        $record['create_time'] = date('Y-m-d H:i:s', $record['create_time']);
        
        return resultArray(['data' => $record]);
    }

    /**
     * 获取转换记录
     *
     * @return \think\Response
     */
    public function getTranslates()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = [
            'user_id' => $userInfo['id'],
            'symbol'  => $symbol,
        ];
        $total = Db::name('translate')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('translate')
            ->field('id,amount,symbol,trans_to,create_time')
            ->where($map)
            ->order('id desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) {
            $item = array_merge($item, [
                'title'        => strtoupper($item['symbol']) . '转换为' . strtoupper($item['trans_to']),
                'amount'       => format_symbol_amount($item['amount'],5),
                'create_time'  => date('Y-m-d H:i:s', $item['create_time']),
            ]);
        });
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取转换详情
     *
     * @return \think\Response
     */
    public function getTranslateDetail()
    {
        $record = Db::name('translate')->find($this->param['id']);
        if (!$record) {
            return resultArray(['error' => '找不到记录']);
        }

        unset($record['user_id']);
        $record['title']        = strtoupper($record['symbol']) . '转换为' . strtoupper($record['trans_to']);
        $record['amount']       = format_symbol_amount($record['amount'], 8);
        $record['create_time']  = date('Y-m-d H:i:s', $record['create_time']);
        $record['trans_amount'] = format_symbol_amount($record['trans_amount'], 8);

        return resultArray(['data' => $record]);
    }

    /**
     * 托管
     *
     * @return \think\Response
     */
    public function trustee()
    {
        $userInfo = $this->getUserInfo();
        if (!Db::name('user')->where('id', $userInfo['id'])->value('status')) {
            return resultArray(['error' => '您已被禁用，不能进行托管操作']);
        }

        $param  = $this->param;
        $info   = Db::name('coin_info')->where(['symbol' => $param['symbol']])->find();
        $config = Db::name('trustee_config')->where(['symbol' => $param['symbol']])->select();
        if (!$param['symbol'] || !$param['amount'] || !$param['type']) {
            return resultArray(['error' => '托管参数有误']);
        }
        if (!$info || !$config) {
            return resultArray(['error' => '(不可操作)该币种托管功能未设置']);
        }

        // 读取缓存数据(身份令牌)
        $token = cache('Trader_' . $param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Trader_' . $param['token'], null);

        $model = model('Trustee');
        return resultArray($model->doAccept($param, $userInfo));
    }

    /**
     * 取消托管
     *
     * @return \think\Response
     */
    public function cancelTrustee()
    {
        // 读取用户信息
        $userInfo = $this->getUserInfo();

        // 读取缓存数据(身份令牌)
        $token = cache('Trader_' . $this->param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Trader_' . $param['token'], null);

        $model = model('Trustee');
        $order = $model->where([
            'id'      => $this->param['id'],
            'user_id' => $userInfo['id'],
            'status'  => 1,
        ])->count();
        if (!$order) {
            return resultArray(['error' => '订单错误']);
        }
        return resultArray($model->doCancel($this->param['id']));
    }

    /**
     * 取消自动续托
     *
     * @return \think\Response
     */
    public function disableAutoRenewal()
    {
        // 读取用户信息
        $userInfo = $this->getUserInfo();

        // 读取缓存数据(身份令牌)
        $token = cache('Trader_' . $this->param['token']);
        if ($token === false) {
            return resultArray(['error' => '令牌无效']);
        }

        // 清除令牌
        cache('Trader_' . $param['token'], null);

        $model = model('Trustee');
        $order = $model->get($this->param['id']);
        if (!$order || $order->user_id != $userInfo['id'] || $order->status != 1 || $order->auto_renewal != 1) {
            return resultArray(['error' => '订单错误']);
        }

        $result = $model->save(['auto_renewal' => 0], ['id' => $order->id]);
        return resultArray($result ? ['data' => 'OK'] : ['error' => '服务器繁忙']);
    }

    /**
     * 获取托管历史记录
     *
     * @return \think\Response
     */
    public function getTrustees()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $type     = $this->param['type'];
        $status   = $this->param['status'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = ['user_id' => $userInfo['id']];
        if ($symbol) {
            $map['symbol'] = $symbol;
        }
        if ($type) {
            $map['type'] = $type;
        }
        if (strlen($status) > 0) {
            $map['status'] = ['in', explode(',', $status)];
        }
        
        $total = Db::name('trustee')
            ->where($map)
            ->count();
        if ($start >= $total) {
            return resultArray(['data' => []]);
        }

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }
        $list = Db::name('trustee')
            ->where($map)
            ->order('id desc')
            ->limit("{$start},{$size}")
            ->column('id');
        foreach ($list as $k => $v) {
            $detail   = model('Trustee')->getDetail($v);
            $list[$k] = $detail['data'];
            unset($list[$k]['period']);
            unset($list[$k]['income_rate']);
        }
        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取托管详情
     *
     * @return \think\Response
     */
    public function getTrusteeDetail()
    {
        return resultArray(model('Trustee')->getDetail($this->param['id']));
    }

    /**
     * 获取到账收益记录
     *
     * @return \think\Response
     */
    public function getIncomes()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $ivticm = Db::name('income_inviter')
            ->alias('a')
            ->field('a.trustee_id,a.amount,a.create_time')
            ->join('trustee b', ['a.trustee_id=b.id', "a.inviter_id={$userInfo['id']}", "b.symbol='{$symbol}'"])
            ->buildSql();
        $usricm = Db::name('income_user')
            ->alias('c')
            ->field('c.trustee_id,c.amount,c.create_time')
            ->join('trustee d', ['c.trustee_id=d.id', "c.user_id={$userInfo['id']}", "d.symbol='{$symbol}'"])
            ->buildSql();
        $subQuery = Db::table($ivticm . ' e')
            ->union($usricm)
            ->buildSql();
        $total = Db::table($subQuery . ' s')->field('trustee_id,sum(amount) amount')->count();
        $list  = Db::table($subQuery . ' s')
            ->field('trustee_id,sum(amount) amount,max(create_time) create_time')
            ->group('trustee_id')
            ->order('create_time desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) use ($symbol) {
            $item['title']       = strtoupper($symbol);
            $item['amount']      = format_symbol_amount($item['amount'], 5);
            $item['create_time'] = date('Y-m-d H:i:s', $item['create_time']);
        });

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }

        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取收益详情
     *
     * @return \think\Response
     */
    public function getIncomeDetail()
    {
        $userInfo = $this->getUserInfo();
        $ivticm   = Db::name('income_inviter')
            ->field('trustee_id,amount,create_time')
            ->where(['trustee_id' => $this->param['id']])
            ->buildSql();
        $usricm = Db::name('income_user')
            ->field('trustee_id,amount,create_time')
            ->where(['trustee_id' => $this->param['id']])
            ->buildSql();
        $subQuery = Db::table($ivticm . ' a')
            ->union($usricm)
            ->buildSql();
        if (!Db::table($subQuery . ' s')->find()) {
            return resultArray(['error' => '收益不存在']);
        }

        $record = Db::table($subQuery . ' s')
            ->field('sum(amount) amount,max(create_time) create_time')
            ->find();
        $trustee = Db::name('trustee')->find($this->param['id']);
        unset($trustee['start_date']);
        $trustee['stop_date']     = date('Y-m-d H:i:s', $record['create_time']);
        $trustee['create_time']   = date('Y-m-d H:i:s', $trustee['create_time']);
        $trustee['income_amount'] = format_symbol_amount($record['amount'], 8);

        return resultArray(['data' => $trustee]);
    }

    /**
     * 获取在途收益记录
     *
     * @return \think\Response
     */
    public function getPendIncomes()
    {
        $userInfo = $this->getUserInfo();
        $symbol   = $this->param['symbol'];
        $start    = $this->param['start'] ?: 0;
        $size     = $this->param['size'] ?: config('paginate.list_rows');
        if ($start < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $subQuery = Db::name('income_daily')
            ->alias('a')
            ->field('a.trustee_id,sum(a.amount) amount, max(a.date) date')
            ->join('trustee b', 'a.trustee_id=b.id')
            ->where(['b.user_id' => $userInfo['id'], 'b.symbol' => $symbol, 'b.type' => ['neq', '随托随取'], 'b.status' => 1])
            ->group('trustee_id')
            ->order('trustee_id desc')
            ->buildSql();
        $total = Db::table($subQuery . ' s')->count();
        $list  = Db::table($subQuery . ' s')
            ->order('date desc')
            ->limit("{$start},{$size}")
            ->select();
        array_walk($list, function (&$item) use ($symbol) {
            $item['date']   = date('Y-m-d H:i:s', strtotime($item['date']));
            $item['title']  = strtoupper($symbol);
            $item['amount'] = bcmul($item['amount'], '0.70000', 5);
        });

        $nextStart = $start + $size;
        if ($nextStart >= $total) {
            $nextStart = -1;
        }

        return resultArray(['data' => [
            'next' => $nextStart,
            'list' => $list,
        ]]);
    }

    /**
     * 获取在途收益详情
     *
     * @return \think\Response
     */
    public function getPendIncomeDetail()
    {
        $subQuery = Db::name('income_daily')
            ->where(['trustee_id' => $this->param['id']])
            ->buildSql();
        if (!Db::table($subQuery . ' s')->find()) {
            return resultArray(['error' => '收益不存在']);
        }
        $record = Db::table($subQuery . ' s')
            ->field('sum(amount) amount, max(date) date')
            ->find();
        $trustee = Db::name('trustee')->find($this->param['id']);
        unset($trustee['start_date']);
        $trustee['stop_date']     = date('Y-m-d 23:59:59', strtotime($trustee['stop_date']));
        $trustee['create_time']   = date('Y-m-d H:i:s', $trustee['create_time']);
        $trustee['income_amount'] = bcmul($record['amount'], '0.70000', 5);

        return resultArray(['data' => $trustee]);
    }
}
