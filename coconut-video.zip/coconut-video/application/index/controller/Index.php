<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 下午 5:07
 */

namespace app\index\controller;

use app\common\controller\Common;
use app\index\model\Smscode;
use com\verify\HonrayVerify;
use think\Db;

class Index extends Common
{
    public function index(){
        return;
    }
    /**
     * 用户登录
     *
     * @return \think\Response
     */
    public function login()
    {
        $model = model('User');
        $check = $model->login($this->param);
        if (!$check) {
            return resultArray(['error' => $model->getError()]);
        }
        return resultArray(['data' => $check]);
    }

    /**
     * 用户注册
     *
     * @return \think\Response
     */
    public function register()
    {
        $model = model('User');
        $check = $model->register($this->param);
        if (!$check) {
            return resultArray(['error' => $model->getError()]);
        }
        return resultArray(['data' => $check]);
    }

    /**
     * 获取短信验证码
     *
     * @return \think\Response
     */
    public function getSms()
    {
        $time  = time();
        $code  = mt_rand(123456, 999999);
        $phone = $this->param['phone'];

        $statusStr = [
            "0"  => "短信发送成功",
            "-1" => "参数不全",
            "-2" => "服务器空间不支持,请确认支持curl或者fsocket，联系您的空间商解决或者更换空间！",
            "30" => "密码错误",
            "40" => "账号不存在",
            "41" => "余额不足",
            "42" => "帐户已过期",
            "43" => "IP地址限制",
            "50" => "内容含有敏感词",
        ];
        $api     = config('smsbao_api');
        $user    = config('smsbao_user'); // 短信平台帐号
        $pass    = md5(config('smsbao_pass')); // 短信平台密码
        $content = sprintf(config('smsbao_sign'), $code, 10); // 要发送的短信内容
        $sendurl = $api . "sms?u=" . $user . "&p=" . $pass . "&m=" . $phone . "&c=" . urlencode($content);
        $result  = file_get_contents($sendurl);
        if ($result === '0') {
            Smscode::update(['expire_time' => $time], ['phone' => $phone, 'expire_time' => ['egt', $time]]);
            Smscode::create(['phone' => $phone, 'code' => $code, 'send_time' => $time, 'expire_time' => $time + 600]);
            return resultArray(['data' => '']);
        }
        return resultArray(['error' => '发送失败，请稍后再试']);
    }

    /**
     * 校验短信验证码
     *
     * @return \think\Response
     */
    public function checkSms()
    {
        $code  = $this->param['code'];
        $phone = $this->param['phone'];

        if (!$code || !$phone) {
            return resultArray(['error' => '参数错误']);
        }

        $check = model('Smscode')->checkCode($phone, $code);
        return resultArray($check ? ['data' => $check] : ['error' => '短信验证码错误']);
    }

    /**
     * 获取图片验证码
     *
     * @return \think\Response
     */
    public function getVerify()
    {
        ob_clean();
        $veriKey = $this->param['verify_key'];
        $captcha = new HonrayVerify(config('captcha'));
        return $captcha->entry($veriKey);
    }

    /**
     * 检查验证码是否正确
     *
     * @return \think\Response
     */
    public function checkVerify()
    {
        $key   = $this->param['verify_key'];
        $code  = $this->param['verify_code'];
        $error = '';
        if (!$code) {
            $error = '验证码不能为空';
        }
        $captcha = new HonrayVerify(config('captcha'));
        if (!$captcha->check($code, $key)) {
            $error = '验证码错误';
        }
        if ($error !== '') {
            return resultArray(['error' => $error]);
        }
        return resultArray(['data' => 'OK']);
    }

    /**
     * 检查手机号是否存在
     *
     * @return \think\Response
     */
    public function phoneUnique()
    {
        $phone = $this->param['phone'];
        if (model('User')->where('phone', $phone)->find()) {
            return resultArray(['error' => '手机号已被注册']);
        }
        return resultArray(['data' => 'OK']);
    }

    /**
     * 检查用户名是否存在
     *
     * @return \think\Response
     */
    public function usernameUnique()
    {
        $username = $this->param['username'];
        if (model('User')->where('username', $username)->find()) {
            return resultArray(['error' => '用户名已存在']);
        }
        return resultArray(['data' => 'OK']);
    }

    /**
     * 获取最新版本号
     *
     * @return \think\Response
     */
    public function getLatestVer()
    {
        $latest = Db::name('app_version')
            ->order('id desc')
            ->find();
        $latest['create_time'] = date('Y-m-d H:i:s', $latest['create_time']);
        return resultArray(['data' => $latest]);
    }

    /**
     * 忘记密码
     *
     * @return \think\Response
     */
    public function forgetPassword()
    {
        // 接受参数
        $param = $this->param;

        // 参数校验
        $rule = [
            'token'    => 'require',
            'password' => 'require|alphaDash|length:6,12',
        ];
        $message = [
            'token'    => '身份不明',
            'password' => '密码非法',
        ];
        $check = $this->validate([
            'token'    => $param['token'],
            'password' => $param['password'],
        ], $rule, $message);
        if (true !== $check) {
            return resultArray(['error' => $check]);
        }

        // 读取缓存数据(身份令牌)
        $phone = cache('Sms_' . $param['token']);
        if ($phone === false) {
            return resultArray(['error' => '令牌失效']);
        }

        // 清除令牌
        cache('Sms_' . $param['token'], null);

        // 重置密码
        $reset = model('User')
            ->where(['phone' => $phone])
            ->update(['password' => user_md5($param['password'])]);

        return resultArray(($reset === false) ? ['error' => '操作失败'] : ['data' => '']);
    }

    public function test()
    {
        return resultArray(['data' => date('Y-m-d H:i:s')]);
    }
}
