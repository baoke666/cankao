<?php

/**
 * 行为绑定
 */
\think\Hook::add('app_init', 'app\\common\\behavior\\InitConfigBehavior');

/**
 * 返回对象
 * @param $array 响应数据
 */
function resultArray($array)
{
    if (isset($array['data'])) {
        $array['error'] = '';
        $code           = 200;
    } elseif (isset($array['error'])) {
        $code          = 400;
        $array['data'] = '';
    }
    return [
        'code'  => $code,
        'data'  => $array['data'],
        'error' => $array['error'],
    ];
}

/**
 * 调试方法
 * @param  array   $data  [description]
 */
function p($data, $die = 1)
{
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    if ($die) {
        die;
    }

}

/**
 * 用户密码加密方法
 * @param  string $str      加密的字符串
 * @param  [type] $auth_key 加密符
 * @return string           加密后长度为32的字符串
 */
function user_md5($str, $auth_key = '')
{
    return '' === $str ? '' : md5(sha1($str) . $auth_key);
}

/**
 * 获取系统支持的货币
 * @return array
 */
function get_support_symbols()
{
    $list = config('support_symbol');
    $data = array();
    foreach ($list as $v) {
        array_push($data, [
            'id'  => $v,
            'txt' => strtoupper($v),
        ]);
    }
    return $data;
}

/**
 * 组合系统需要展示的交易对
 * @return array
 */
function get_support_pairs()
{
    $symbols = config('support_symbol');
    $compare = config('symbol_compare');
    $require = array();

    foreach ($symbols as $s) {
        foreach ($compare as $c) {
            if ($s == $c) {
                continue;
            }
            array_push($require, [
                'close' => $s . $c,
                'cut'   => $s . '_' . $c,
                'left'  => $s,
                'right' => $c,
            ]);
        }
    }

    return $require;
}

/**
 * 获取当前毫秒级时间戳
 * @return long
 */
function timestamp()
{
    list($s1, $s2) = explode(' ', microtime());
    return (float) sprintf('%.0f', (floatval($s1) + floatval($s2)) * 1000);
}

/**
 * 科学计数法转化正常数值
 * @param $num         科学计数法字符串  如 2.1E-5
 * @param int $double  小数点保留位数 默认6位
 * @return string
 */
function sctonum($num, $double = 10)
{
    if (false !== stripos($num, "e")) {
        $a = explode("e", strtolower($num));
        return bcmul($a[0], bcpow(10, $a[1], $double), $double);
    }
    return strval($num);
}

/**
 * 计算价格涨跌百分比
 * @param  string $close 收盘价
 * @param  string $open  开盘价
 * @return string
 */
function get_percent_change($close, $open)
{
    $result = '0.00';
    if ($open != 0) {
        $result = bcmul(bcdiv(bcsub($close, $open, 10), $open, 4), 100, 2);
    }
    return $result;
}

/**
 * 生成币种充值地址二维码并返回图片路径
 * @param  string $symbol 币种
 * @param  string $addr   充值地址
 * @return string
 */
function create_qrcode($symbol, $addr)
{
    if (!$addr) {
        return '';
    }

    $path = ROOT_PATH . 'public'  . DS . 'assets' . DS . 'temp' . DS . 'qrcode';
    if (!is_dir($path)) {
        // 若目录不存在则创建之
        mkdir($path, 0777, true);
    }

    vendor('phpqrcode.phpqrcode');
    $outfile = $path . DS . "{$symbol}.jpg";
    $level   = 'L';
    $size    = 7.6;
    $QRcode  = new \QRcode();
    ob_start();
    $QRcode->png($addr, $outfile, $level, $size, 2);
    ob_end_clean();

    $start = strpos($outfile, 'assets' . DS . 'temp');
    return str_replace(DS, '/', substr($outfile, $start));
}

/**
 * 保存图片
 * @param  string $symbol 币种
 * @param  string $addr   充值地址
 * @return string
 */
function save_img($file)
{
    if (!$file) {
        return ['error' => '参数错误'];
    }

    $path = ROOT_PATH . 'public' . DS . 'uploads';
    if (!is_dir($path)) {
        // 若目录不存在则创建之
        mkdir($path, 0777, true);
    }

    $info = $file->move($path);
    if ($info) {
        // 成功上传
        return ['data' => str_replace(DS, '/', $info->getSaveName())];
    } else {
        // 成功失败
        return ['error' => '图片上传失败'];
    }
}

/**
 * 将二维数组元素组合返回新的二维数组
 * @param  string $in  原数组
 * @param  string $relation  键的对应关系
 * @param  string $ignore  忽略的键
 * @param  string $fixed 固定赋值
 * @return array
 */
function copy_properties($in, $relation, $ignore = array(), $fixed = array())
{
    $out = array();
    foreach ($in as $item) {
        $new = array();
        foreach ($item as $k => $v) {
            if (in_array($k, $ignore)) {
                continue;
            }
            if (array_key_exists($k, $relation)) {
                $new[$relation[$k]] = $v;
            } else {
                $new[$k] = $v;
            }
        }
        array_push($out, $new);
    }
    if ($fixed) {
        foreach ($out as $k => $v) {
            $out[$k] = array_merge($v, $fixed);
        }
    }
    return $out;
}

/**
 * 将资产数额长数字保留6位小数
 * @param  string   $in  长数字
 * @return string
 */
function format_symbol_amount($in, $floatLen)
{
    return bcmul($in, '1.00000', $floatLen);
}

/**
 * 计算资产累计价值人民币数额(保留2位小数)
 * @param  array   $in  资产列表
 * @param  string  $field  资产名目
 * @return string
 */
function get_cny_sum($in, $field)
{
    $sum = '';
    foreach ($in as $i) {
        $sum = bcadd($sum, $i[$field], 2);
    }
    return $sum;
}

/**
 * 获取托管订单收益截止日期
 * @param  string  $startDate  收益开始日期
 * @param  string  $type  托管类型
 * @return string
 */
function get_trustee_stopdate($startDate, $type)
{
    $stopDate = '';
    switch ($type) {
        case '30天定托':
            $stopDate = date('Ymd', strtotime("{$startDate} +29 days"));
            break;
        case '90天定托':
            $stopDate = date('Ymd', strtotime("{$startDate} +89 days"));
            break;
        case '180天定托':
            $stopDate = date('Ymd', strtotime("{$startDate} +179 days"));
            break;
        default:
            break;
    }
    return $stopDate;
}

/**
 * 生成订单号
 * @param  string  $timestamp  订单时间戳
 * @param  string  $type  订单类型(deposit:充币,withdraw:提币,translate:转换,trustee:托管)
 * @return string
 */
function make_orderid($timestamp, $type)
{
    $orderid = date('YmdHis', $timestamp);
    switch ($type) {
        case 'deposit':
            $orderid .= '1' . mt_rand(10000, 99999);
            break;
        case 'withdraw':
            $orderid .= '2' . mt_rand(10000, 99999);
            break;
        case 'translate':
            $orderid .= '3' . mt_rand(10000, 99999);
            break;
        case 'trustee':
            $orderid .= '4' . mt_rand(10000, 99999);
            break;
        default:
            break;
    }
    return $orderid;
}

/**
 * 获取带毫秒时间戳
 * @param  string  $withPoint  是否带点好分割
 * @return string
 */
function get_mtimestamp($withPoint = false)
{
    $mtime = sprintf("%.3f", microtime(true));
    return $withPoint ? $mtime : implode('', explode('.', $mtime));
}

/**
 * 获取每日收益率
 * @param  string  $min  最低收益率
 * @param  string  $max  最高收益率
 * @return string
 */
function get_daily_income_rate($min, $max)
{
    return rand($min * 100, $max * 100) / 100;
}

function create_invite_code()
{

    $length = 6;
    $chars  = '0123456789abcdefghijklmnopqrstuvwxyz';

    $code  = '';
    $timer = 0;
    while ($timer < $length) {
        $index = mt_rand(0, 35);
        if (mt_rand(0, 1)) {
            $code = strtoupper($chars[$index]) . $code;
        } else {
            $code = strtolower($chars[$index]) . $code;
        }
        $timer++;
    }

    return $code;
}

/**
 * 使用curl通过get方式请求数据
 * @param  string  $url    接口地址
 * @param  string  $type   接口地址
 * @param  array   $data   请求参数
 * @param  array   $header 请求头信息
 * @param  boolean $proxy  是否使用代理
 * @return array
 */
function curl_request($url, $type = 'get', $data = [], $header = [], $proxy = false)
{
    // if ($type == 'get') {
    //     $tail = $data ? '?' . http_build_query($data) : '';
    //     $json = file_get_contents($url . $tail);
    //     return json_decode($json, true);
    // }

    $curl = curl_init();
    if ($header) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
        ]);
    }
    if ($type == 'get') {
        $tail = $data ? '?' . http_build_query($data) : '';
        curl_setopt($curl, CURLOPT_URL, $url . $tail);
    } else {
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    if ($proxy) {
        curl_setopt($ch, CURLOPT_PROXY, '127.0.0.1:1080');
    }
    $output = curl_exec($curl);
    curl_close($curl);
    return json_decode($output, true);
}
