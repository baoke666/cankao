<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/15 0015
 * Time: 下午 2:47
 */

namespace app\admin\validate;


use think\Validate;

class Trustee extends Validate
{
    protected $rule = array(
        'id'  		                => 'require',
        'symbol'                    => 'require',
        'income_rate_min'      	    => 'require',
        'income_rate_max'  		    => 'require'
    );
    protected $message = array(
        'id.require'    	=> 'id编号不能为空',
        'symbol.require'    	    => '币种名称不能为空',
        'income_rate_min.require'    	=> '日收益最小值不能为空',
        'income_rate_max.require'    	=> '日收益最大值不能为空'
    );
    // 自定义验证规则
    protected function checkMin($value, $rule, $data)
    {
        $withdraw_mins = array(
            'btc'  => 0.01100,
            'ltc'  => 0.10200,
            'eth'  => 0.10300,
            'ada'  => 1.10000,
            'neo'  => 1.00000,
            'xmr'  => 0.15000,
            'eos'  => 0.20000,
            'xlm'  => 1.10000,
            'bch'  => 0.10100,
            'xrp'  => 26.00000
        );
        $trans_min = 0.00010;
        $trustee_min = 0.00010;

        $symbol = $data['symbol'];
        if ($rule == 'wd_min') {
            $wd_min = $withdraw_mins[$symbol];
            if (bccomp($wd_min, $value, 5) == 1)
                return $data['symbol'].'最小提现数量不能低于'.$wd_min;
        } else if ($rule == 'tra_min') {
            if (bccomp($trans_min, $value, 5) == 1)
                return $data['symbol'].'最小转换数量不能低于'.$trans_min;
        } else if ($rule == 'tru_min') {
            if (bccomp($trustee_min, $value, 5) == 1)
                return $data['symbol'].'最小托管数量不能低于'.$trustee_min;
        }

        return true;
    }

    // 自定义验证规则
    protected function checkMax($value,$rule,$data)
    {
        $withdraw_maxs = array(
            'btc'  => 100.00000,
            'ltc'  => 10000.00000,
            'eth'  => 3000.00000,
            'ada'  => 500000.00000,
            'neo'  => 2000.00000,
            'xmr'  => 200.00000,
            'eos'  => 20000.00000,
            'xlm'  => 100000.00000,
            'bch'  => 500.00000,
            'xrp'  => 80000.00000
        );

        $symbol = $data['symbol'];
        $wd_max = $withdraw_maxs[$symbol];
        if (bccomp($value, $wd_max, 5) == 1)
            return $data['symbol'].'最大提现数量不能大于'.$wd_max;
        return true;
    }
}