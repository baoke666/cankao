<?php
// +----------------------------------------------------------------------
// | Description: 充币记录
// +----------------------------------------------------------------------
// | Author: ligugouo <641785852@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Deposit extends ApiCommon
{
	// 分页查询充币记录
    public function getList()
    {
        $symbol  = $this->param['symbol'];
        $phone   = $this->param['phone'];
        $orderid = $this->param['orderid'];

        $page = $this->param['page'] ?: 1;
        $size = $this->param['limit'] ?: config('paginate.list_rows');
        if ($page < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = ['user_id' => ['>', 0]];
        if ($phone) {
        	$user = model('\app\index\model\User')->where('phone', $phone)->find();
        	if ($user) {
        		$map['user_id'] = $user->id;
        	} else {
        		$map['user_id'] = -1;
        	}
        }
        if ($orderid) {
        	$map['orderid'] = $orderid;
        }
        if ($symbol) {
        	$map['symbol'] = $symbol;
        }

        $limit = (($page - 1) * $size) . ',' . $size;
        $total = Db::name('user_deposit')
            ->where($map)
            ->count();
        $list = Db::name('user_deposit')
            ->field('id,user_id,orderid,symbol,amount,address,status,timestamp')
            ->where($map)
            ->order('id desc')
            ->limit($limit)
            ->select();
        array_walk($list, function (&$item) {
        	$user = Db::name('user')->find($item['user_id']);
            $item = array_merge($item, [
                'amount'      => format_symbol_amount($item['amount'], 5),
                'title'       => strtoupper($item['symbol']),
                'create_time' => date('Y-m-d H:i:s', $item['timestamp']),
                'update_time' => date('Y-m-d H:i:s', $item['update_time']),
                'username'    => $user['username'],
                'phone'       => $user['phone'],
            ]);
            unset($item['symbol']);
            unset($item['timestamp']);
        });
        return resultArray(['data' => [
            'total' => $total,
            'list'  => $list,
        ]]);
    }

    // 查询充币详情
    public function getDetail()
    {
        $record = Db::name('user_deposit')->find($this->param['id']);
        if (!$record || $record['user_id'] == 0) {
            return resultArray(['error' => '找不到记录']);
        }
        $user = Db::name('user')->find($record['user_id']);
        unset($record['raw_id']);
        unset($record['txid']);
        unset($record['type']);
        $record['username']    = $user['username'];
        $record['phone']       = $user['phone'];
        $record['amount']      = format_symbol_amount($record['amount'], 8);
        $record['create_time'] = date('Y-m-d H:i:s', $record['timestamp']);
        $record['update_time'] = date('Y-m-d H:i:s', $record['update_time']);

        return resultArray(['data' => $record]);
    }
}
