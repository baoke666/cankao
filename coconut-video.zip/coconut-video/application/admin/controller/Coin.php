<?php
// +----------------------------------------------------------------------
// | Description: 系统用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Coin extends ApiCommon
{

    public function index()
    {
        return resultArray(['data' => Db::name('coin_info')->order('update_time desc')->select()]);
    }

    public function update(){

        $param = $this->param;

        $data = array(
            'id' => $param['id'],
            'symbol' => $param['symbol'],
            'profile' => $param['profile'],
            'deposit_addr' => $param['deposit_addr'],
            'deposit_notice' => $param['deposit_notice'],
            'withdraw_minimum' => $param['withdraw_minimum'],
            'withdraw_maxmum' => $param['withdraw_maxmum'],
            'withdraw_notice' => $param['withdraw_notice'],
            'withdraw_fee' => $param['withdraw_fee'],
            'certificate_threshold' => $param['certificate_threshold'],
            'trans_fee' => $param['trans_fee'],
            'trans_notice' => $param['trans_notice'],
            'trustee_minimum' => $param['trustee_minimum'],
            'trustee_fee' => $param['trustee_fee'],
            'trustee_notice' => $param['trustee_notice'],
            'update_time' => time()
        );

        $result = $this->validate($data, 'Coin');

        if (true !== $result) {
            return resultArray(['error' => $result]);
        }

        Db::name('coin_info')->update($data);
        return resultArray(['data' => '修改成功']);
    }
    
}
 