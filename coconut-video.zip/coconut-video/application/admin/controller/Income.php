<?php
// +----------------------------------------------------------------------
// | Description: 提币记录
// +----------------------------------------------------------------------
// | Author: ligugouo <641785852@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Income extends ApiCommon
{
    // 分页查询用户邀请收益概览列表
    public function getList()
    {
        $phone = $this->param['phone'];
        $page  = $this->param['page'] ?: 1;
        $size  = $this->param['limit'] ?: config('paginate.list_rows');
        if ($page < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = array();
        if ($phone) {
            $map['phone'] = $phone;
        }

        $limit = (($page - 1) * $size) . ',' . $size;
        $total = Db::name('user')->where($map)->count();
        $list  = Db::name('user')
            ->where($map)
            ->order('id desc')
            ->limit($limit)
            ->select();
        $cnyModel = model('\app\index\model\SymbolCny');
        foreach ($list as $k => $v) {
            // 真实的邀请受益人数
            $ivCntReal = Db::name('user')->where(['inviter_id' => $v['id']])->count();
            // 后台设置的受益人数
            $ivCntFake = Db::name('fake_invite')->where(['user_id' => $v['id']])->value('count');
            // 真实的受益记录
            $ivListReal = Db::name('income_inviter')
                ->alias('a')
                ->field('a.amount,b.symbol')
                ->join('trustee b', 'a.trustee_id=b.id')
                ->where('a.inviter_id', $v['id'])
                ->select();
            // 真实的受益累计数额(人民币)
            $ivAmtReal = '0';
            foreach ($ivListReal as $iv) {
                $ivAmtReal = bcadd($ivAmtReal, $cnyModel->convertSymbolToCny($iv['symbol'], $iv['amount'], 2), 2);
            }
            // 后台设置的受益累计数额(人民币)
            $ivAmtFake = Db::name('fake_invite')->where(['user_id' => $v['id']])->value('amount');
            // 后台设置的受益记录(人民币)
            $ivAmtFake2 = Db::name('fake_income')->where(['user_id' => $v['id']])->sum('amount');
            $list[$k]   = [
                'user_id'  => $v['id'],
                'username' => $v['username'],
                'phone'    => $v['phone'],
                'count'    => bcadd($ivCntReal, $ivCntFake ?: '0'),
                'amount'   => bcadd(bcadd($ivAmtReal, $ivAmtFake2, 2), $ivAmtFake ?: '0', 2),
            ];
        }

        return resultArray(['data' => [
            'total' => $total,
            'list'  => $list,
        ]]);
    }

    // 设置邀请人数和收益
    public function setFakeCounting()
    {
        $param  = $this->param;
        $record = Db::name('fake_invite')->where('user_id', $param['user_id'])->find();
        if (!$record) {
            Db::name('fake_invite')->insert([
                'user_id' => $param['user_id'],
                'count'   => $param['count'],
                'amount'  => $param['amount'],
            ]);
        } else {
            Db::name('fake_invite')->update([
                'id'      => $record['id'],
                'user_id' => $param['user_id'],
                'count'   => $param['count'],
                'amount'  => $param['amount'],
            ]);
        }
        return resultArray(['data' => true]);
    }

    // 设置邀请返佣记录
    public function setFakeRecord()
    {
        Db::name('fake_income')->insert([
            'user_id'     => $this->param['user_id'],
            'phone'       => $this->param['phone'],
            'amount'      => $this->param['amount'],
            'create_time' => time(),
        ]);        
        return resultArray(['data' => true]);
    }

    // 分页查询用户收益明细列表
    public function getDetailList()
    {
        $phone = $this->param['phone'];
        $page  = $this->param['page'] ?: 1;
        $size  = $this->param['limit'] ?: config('paginate.list_rows');
        if ($page < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = array();
        if ($phone) {
            $map['phone'] = $phone;
        }

        $inviter = $map ? Db::name('user')->where($map)->find() : false;
        if (!$inviter && $inviter !== false) {
            return resultArray(['data' => [
                'total' => 0,
                'list'  => [],
            ]]);
        }

        $real = Db::name('income_inviter')
            ->field('inviter_id,trustee_id,"unknow" trustee_phone,amount,create_time')
            ->where($inviter === false ? [] : ['inviter_id' => $inviter['id']])
            ->buildSql();
        $fake = Db::name('fake_income')
            ->field('user_id inviter_id,0 trustee_id,phone trustee_phone,amount,create_time')
            ->where($inviter === false ? [] : ['user_id' => $inviter['id']])
            ->buildSql();
        $subQuery = Db::table($real . ' a')
            ->union($fake)
            ->buildSql();

        $limit = (($page - 1) * $size) . ',' . $size;
        $total = Db::table($subQuery . ' s')->count();
        $list  = Db::table($subQuery . ' s')
            ->order('create_time desc')
            ->limit($limit)
            ->select();

        $cnyModel = model('\app\index\model\SymbolCny');
        foreach ($list as $k => $v) {

            // 查询邀请人信息
            $inviter = Db::name('user')
                ->where('id', $v['inviter_id'])
                ->find();
            $list[$k]['inviter_phone']    = $inviter['phone'];
            $list[$k]['inviter_username'] = $inviter['username'];

            // 查询被邀请人信息
            if ($v['trustee_id'] == 0) {
                $trusteeUser = Db::name('user')->where('phone', $v['trustee_phone'])->find();
                if ($trusteeUser) {
                    $list[$k]['trustee_phone']    = $trusteeUser['phone'];
                    $list[$k]['trustee_username'] = $trusteeUser['username'];
                } else {
                    $list[$k]['trustee_phone']    = $v['trustee_phone'];
                    $list[$k]['trustee_username'] = $v['trustee_phone'];
                }
            } else {
                $trustee = Db::name('trustee')
                    ->where('id', $v['trustee_id'])
                    ->find();
                $trusteeUser = Db::name('user')
                    ->where('id', $trustee['user_id'])
                    ->find();
                $list[$k]['amount'] = $cnyModel
                    ->convertSymbolToCny($trustee['symbol'], $v['amount'], 2);
                $list[$k]['trustee_phone']    = $trusteeUser['phone'];
                $list[$k]['trustee_username'] = $trusteeUser['username'];
            }

            // 格式化时间
            $list[$k]['amount']      = bcadd($list[$k]['amount'], '0', 2);
            $list[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
            unset($list[$k]['inviter_id']);
            unset($list[$k]['trustee_id']);
        }

        return resultArray(['data' => [
            'total' => $total,
            'list'  => $list,
        ]]);
    }
}
