<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/20 0020
 * Time: 下午 2:58
 */

namespace app\admin\controller;


use phpDocumentor\Reflection\Types\Array_;
use think\Db;

class News extends ApiCommon
{
    public function publish(){

        $param = $this->param;

        $title = $param['title'];
        $type = $param['type'];
        $content = $param['content'];
        $display_time = $param['display_timestamp'];
        $image_uri = $param['image_uri'];

        if (empty($title) || empty($type) || empty($content) || empty($display_time) || empty($image_uri))
            return resultArray(['error' => "缺少参数"]);
        $data = array(
            'title' => $title,
            'type' => $type,
            'content' => $content,
            'index_img' => $image_uri,
            'display_time' => $display_time,
            'update_time' => time(),
            'create_time' => time(),
            'status' => 0,
        );

        Db::name('news')->insert($data);

        return resultArray(['data' => '发布成功']);
    }

    public function update(){

        $param = $this->param;

        $id = $param['id'];
        $title = $param['title'];
        $content = $param['content'];
        $display_time = $param['display_timestamp'];
        $image_uri = $param['image_uri'];

        if (empty($id) || empty($title) || empty($content) || empty($display_time) || empty($image_uri))
            return resultArray(['error' => "缺少参数"]);
        $data = array(
            'id' => $id,
            'title' => $title,
            'content' => $content,
            'index_img' => $image_uri,
            'display_time' => $display_time,
            'update_time' => time()
        );

        Db::name('news')->update($data);

        return resultArray(['data' => '修改成功']);
    }

    public function getArticles(){
        $param = $this->param;

        $page = empty($param['page']) ?  1 : $param['page'];
        $page_size = empty($param['pageSize']) ? $this->pageSize : $param['pageSize'];
        $type = empty($param['type']) ? 'news': $param['type'];

        $where = ['type' => $type];
        $count = Db::name('news')
            ->where($where)
            ->order('id desc')
            ->count();

        $newsList = Db::name('news')
            ->where($where)
            ->order('id desc')
            ->page($page, $page_size)
            ->select();

        return resultArray(['data' => ['newsList' => $newsList, 'count' => $count]]);
    }

    public function getArticle() {
        $id = $this->param['id'];
        if (empty($id)){
            return resultArray(['error' => '参数不能为空']);
        }

        $where = array(
            'id' => $id
        );
        $news = Db::name('news')->where($where)->find();
        if (empty($news)){
            return resultArray(['error' => '资讯不存在']);
        }

        return resultArray(['data' => $news]);
    }

    public function modifyNewsStatus() {
        $id = $this->param['id'];
        if (empty($id)){
            return resultArray(['error' => '参数不能为空']);
        }

        $news = Db::name('news')->where('id', $id)->find();
        if (empty($news)){
            return resultArray(['error' => '资讯不存在']);
        }

        $status = $news['status'];
        if ($status == 0) {
            $status = 1;
        } else {
            $status = 0;
        }

        Db::name('news')->where('id', $id)->update(['status' => $status]);
        return resultArray(['data' => ['status' => $status , 'desc' => '更新文章状态成功']]);
    }

    /**
     * 获取工单列表
     *
     * @return \think\Response
     */
    public function getFeedbacks()
    {
        $page = $this->param['page'] ?: 1;
        $limit = $this->param['limit'] ?: config('paginate.list_rows');

        $map   = ['a.pid' => 0];
        $total = Db::name('feedback')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->where($map)
            ->count();

        $list = Db::name('feedback')
            ->alias('a')
            ->join('t_user b', 'a.user_id = b.id')
            ->field('a.id,a.content,a.create_time,a.evidence,a.type,b.username, b.phone')
            ->where($map)
            ->order('a.status,id desc')
            ->page($page, $limit)
            ->select();
        return resultArray(['data' => [
            'list' => $list,
            'count' => $total
        ]]);
    }

    /**
     * 获取工单详情
     *
     * @return \think\Response
     */
    public function getFeedbackDetail()
    {
        $fbId     = $this->param['id'];
        $map      = [
            'id'      => $fbId
        ];
        $feedback = Db::name('feedback')->where($map)->find();
        if (!$feedback) {
            return resultArray(['error' => '工单不存在']);
        }

        Db::name('feedback')->where('pid', $fbId)->update(['status' => 1]);
        $list = Db::name('feedback')
            ->field('pid, user_id, content,create_time,type,evidence')
            ->where('id', '=', $feedback['id'])
            ->whereOr('pid', '=', $feedback['id'])
            ->order('id asc')
            ->select();

        $username = '';
        if (count($list) > 0) {
            $username = Db::name('user')->where('id', '=', $list[0]['user_id'])->value('username');
        }

        array_walk($list, function(&$item) use($username){
            if ($item['type'] == '1') {
                $item['username'] = $username;
            }
        });
        return resultArray(['data' => $list]);
    }

    /**
     * 工单留言
     *
     * @return \think\Response
     */
    public function replyFeedback()
    {
        $param    = $this->param;

        if ( !is_numeric($param['id']) || empty($param['content'])) {
            return resultArray(['error' => '参数错误']);
        }

        $user_id = Db::name('feedback')->where('pid', '=', $param['id'])->value('user_id');

        $data = array(
            'user_id'     => $user_id,
            'content'     => $param['content'],
            'pid'         => $param['id'],
            'create_time' => time(),
            'type'        => 0
        );

        $fid = Db::name('feedback')->insertGetId($data);
        return resultArray(['data' => $data]);
    }
}