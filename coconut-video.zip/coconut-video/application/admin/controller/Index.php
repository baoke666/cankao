<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/4 0004
 * Time: 下午 10:59
 */

namespace app\admin\controller;

use think\Db;
use app\common\library\Token;

class Index extends ApiCommon
{
    /**
     * 获取新的token
     */
    public function refreshToken(){
        $old = $this->param['token'];
        if (empty($old))
            return resultArray(['error' => "用户未登录"]);
        if (!Token::check($old))
            return resultArray(['error' => "用户登录已失效"]);
        return resultArray(['data' => Token::refresh($old)]);
    }

    /**
     * 获取菜单导航和菜单权限，树形结构
     */
    public function getMenuTreeList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId(), "tree")]);
    }

    /**
     * 获取菜单导航和菜单权限，列表结构
     */
    public function getMenuList(){
        $menuModel = model('AuthRule');
        return resultArray(['data' => $menuModel->getUserAuthRules( $this->getUserId())]);
    }

    /**修改管理员密码
     * @return array
     */
    public function setInfo()
    {
        $adminModel = model('Admin');
        $param = $this->param;
        $old_pwd = $param['oldPaw'];
        $new_pwd = $param['newPaw'];

        $data = $adminModel->setInfo($this->getUserId(), $old_pwd, $new_pwd);
        if (!$data) {
            return resultArray(['error' => $adminModel->getError()]);
        }
        return resultArray(['data' => $data]);
    }

    /**获取滚动消息
     * @return array
     */
    public function getRollingNotice()
    {
        $data = array();
        $newC = Db::name('user_certificate')
            ->where(['status' => 'pend'])
            ->count();
        if ($newC) {
            array_push($data, ['type' => 'certificate', 'content' => '有新的实名认证申请']);
        }
        $newF = Db::name('feedback')
            ->where('type', '=', '1')
            ->where('status', '=', '0')
            ->count();
        if ($newF) {
            array_push($data, ['type' => 'feedback', 'content' => '有新的用户工单']);
        }
        return resultArray(['data' => $data]);
    }
}