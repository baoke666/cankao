<?php
// +----------------------------------------------------------------------
// | Description: 系统用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Trustee extends ApiCommon
{
    public function config()
    {
        return resultArray(['data' => Db::name('trustee_config')->select()]);
    }

    public function update(){

        $param = $this->param;

        $data = array(
            'id' => $param['id'],
            'symbol' => $param['symbol'],
            'income_rate_min' => $param['income_rate_min'],
            'income_rate_max' => $param['income_rate_max'],
            'update_time' => time()
        );

        $result = $this->validate($data, 'Trustee');
        if (true !== $result) {
            return resultArray(['error' => $result]);
        }

        Db::name('trustee_config')->update($data);
        return resultArray(['data' => '修改成功']);
    }

    // 分页查询提币记录
    public function getList()
    {
        $symbol  = $this->param['symbol'];
        $phone   = $this->param['phone'];
        $orderid = $this->param['orderid'];
        $type    = $this->param['type'];
        $status  = $this->param['status'];

        $page = $this->param['page'] ?: 1;
        $size = $this->param['limit'] ?: config('paginate.list_rows');
        if ($page < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = array();
        if ($phone) {
            $user = model('\app\index\model\User')->where('phone', $phone)->find();
            if ($user) {
                $map['user_id'] = $user->id;
            } else {
                $map['user_id'] = -1;
            }
        }
        if ($orderid) {
            $map['orderid'] = $orderid;
        }
        if ($symbol) {
            $map['symbol'] = $symbol;
        }
        if ($type) {
            $map['type'] = $type;
        }
        if (strlen($status) > 0) {
            $map['status'] = ['in', explode(',', $status)];
        }

        $limit = (($page - 1) * $size) . ',' . $size;
        $total = Db::name('trustee')
            ->where($map)
            ->count();
        $list = Db::name('trustee')
            ->where($map)
            ->order('id desc')
            ->limit($limit)
            ->column('id');
        foreach ($list as $k => $v) {
            $detail = model('\app\index\model\Trustee')->getDetail($v);
            if ($detail['data']) {
                $data   = $detail['data']->toArray();
                $user   = Db::name('user')->find($data['user_id']);
                $detail = array_merge($data, ['phone' => $user['phone'], 'username' => $user['username']]);
            }
            $list[$k] = $detail;
            unset($list[$k]['period']);
            unset($list[$k]['income_rate']);
            unset($list[$k]['user_id']);
        }
        return resultArray(['data' => [
            'total' => $total,
            'list'  => $list,
        ]]);
    }

    // 查询提币详情
    public function getDetail()
    {
        $detail = model('\app\index\model\Trustee')->getDetail($this->param['id']);
        if ($detail['data']) {
            $data = $detail['data']->toArray();
            $user = Db::name('user')->find($data['user_id']);
            unset($data['period']);
            unset($data['income_rate']);
            unset($data['user_id']);
            $detail['data'] = array_merge($data, ['phone' => $user['phone'], 'username' => $user['username']]);
        }
        return resultArray($detail);
    }
}
 