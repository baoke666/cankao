<?php
// +----------------------------------------------------------------------
// | Description: Api基础类，验证权限
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Config;
use think\Request;
use think\Db;
use app\common\adapter\AuthAdapter;
use app\common\controller\Common;


class ApiCommon extends Common
{
    public function _initialize()
    {
        parent::_initialize();

        $userId = $this->getUserId();

        if (!$userId) {
            header('Content-Type:application/json; charset=utf-8');
            exit(json_encode(['code'=>101, 'error'=>'登录已失效']));
        }

        // 检查账号有效性
        $map['id'] = $userId;
        $map['status'] = 'normal';
        if (!Db::name('admin')->where($map)->value('id')) {
            header('Content-Type:application/json; charset=utf-8');
            exit(json_encode(['code'=>103, 'error'=>'账号已被删除或禁用']));   
        }

//        $authAdapter = new AuthAdapter($authKey);
//        $request = Request::instance();
//        $ruleName = $request->module().'-'.$request->controller() .'-'.$request->action();
//        if (!$authAdapter->checkLogin($ruleName, $cache['userInfo']['id'])) {
//            header('Content-Type:application/json; charset=utf-8');
//            exit(json_encode(['code'=>102,'error'=>'没有权限']));
//        }
        //$GLOBALS['userInfo'] = $userInfo;
    }

    protected function getUserId(){
        $header = Request::instance()->header();
        $token = $header['authkey'];
        $prefix = Config::get('token.prefix');
        $tokenItem = cache($prefix.$token);
        if ($tokenItem)
            return $tokenItem['user_id'];
        return false;
    }
}
