<?php
// +----------------------------------------------------------------------
// | Description: 提币记录
// +----------------------------------------------------------------------
// | Author: ligugouo <641785852@qq.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Translate extends ApiCommon
{
	// 分页查询提币记录
    public function getList()
    {
        $symbol  = $this->param['symbol'];
        $phone   = $this->param['phone'];
        $orderid = $this->param['orderid'];

        $page = $this->param['page'] ?: 1;
        $size = $this->param['limit'] ?: config('paginate.list_rows');
        if ($page < 0) {
            return resultArray(['error' => '参数错误']);
        }

        $map = array();
        if ($phone) {
        	$user = model('\app\index\model\User')->where('phone', $phone)->find();
        	if ($user) {
        		$map['user_id'] = $user->id;
        	} else {
        		$map['user_id'] = -1;
        	}
        }
        if ($orderid) {
        	$map['orderid'] = $orderid;
        }
        if ($symbol) {
        	$map['symbol'] = $symbol;
        }

        $limit = (($page - 1) * $size) . ',' . $size;
        $total = Db::name('translate')
            ->where($map)
            ->count();
        $list = Db::name('translate')
            ->field('id,user_id,orderid,amount,trans_amount,symbol,trans_to,fee,create_time')
            ->where($map)
            ->order('id desc')
            ->limit($limit)
            ->select();
        array_walk($list, function (&$item) {
        	$user = Db::name('user')->find($item['user_id']);
            $item = array_merge($item, [
                'amount'      => format_symbol_amount($item['amount'], 5),
                'trans_amount'      => format_symbol_amount($item['trans_amount'], 5),
                'title'       => strtoupper($item['symbol']) . '转换为' . strtoupper($item['trans_to']),
                'create_time' => date('Y-m-d H:i:s', $item['create_time']),
                'username'    => $user['username'],
                'phone'       => $user['phone'],
            ]);
        });
        return resultArray(['data' => [
            'total' => $total,
            'list'  => $list,
        ]]);
    }

    // 查询提币详情
    public function getDetail()
    {
        $record = Db::name('translate')->find($this->param['id']);
        if (!$record) {
            return resultArray(['error' => '找不到记录']);
        }
        $user = Db::name('user')->find($record['user_id']);
        unset($record['user_id']);
        $record['username']     = $user['username'];
        $record['phone']        = $user['phone'];
        $record['title']        = strtoupper($record['symbol']) . '转换为' . strtoupper($record['trans_to']);
        $record['amount']       = format_symbol_amount($record['amount'], 8);
        $record['create_time']  = date('Y-m-d H:i:s', $record['create_time']);
        $record['trans_amount'] = format_symbol_amount($record['trans_amount'], 8);

        return resultArray(['data' => $record]);
    }
}
