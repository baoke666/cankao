<?php
// +----------------------------------------------------------------------
// | Description: 系统用户
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\admin\controller;

use think\Db;

class Users extends ApiCommon
{

    public function index()
    {
        $param = $this->param;
        $username = $param['username'];
        $phone = $param['phone'];
        $inviter_phone = $param['inviterPhone'];
        $page = empty($param['page']) ? 1 : $param['page'];
        $limit = empty($param['limit']) ? $this->pageSize : $param['limit'];

        $where = [];
        if (!empty($username))
            $where['a.username'] = $username;
        if (!empty($phone))
            $where['a.phone'] = $phone;
        if (!empty($inviter_phone))
            $where['b.phone'] = $inviter_phone;

        $count = Db::name('user')
            ->alias('a')
            ->join('t_user b', 'a.inviter_id = b.id', 'left')
            ->where($where)
            ->order('a.id desc')
            ->count();

        $userList = Db::name('user')
            ->alias('a')
            ->join('t_user b', 'a.inviter_id = b.id', 'left')
            ->field('a.id, a.username, a.invite_code, a.phone, a.head, b.phone as inviter_phone, a.realname,a.zfbname, a.card, a.card_address,a.address,a.paicoin,a.activationcode,a.create_time, a.last_login_time, a.status')
            ->where($where)
            ->order('a.id desc')
            ->page($page, $limit)
            ->select();

        return resultArray(['data' => ['userList' => $userList, 'count' => $count]]);
    }

    /**
     * 冻结/解冻用户
     * @return array
     */
    public function disabled()
    {
        $param = $this->param;
        $user_id = $param['userId'];

        $user = Db::name('user')->where('id', $user_id)->find();
        if (empty($user))
            return resultArray(['error' => '用户不存在']);

        if ($user['status'] == 1)
            $status = 0;
        else if ($user['status'] == 0)
            $status = 1;
        else
            $status = $user['status'];

        Db::name('user')->where('id', $user_id)->update(['status' => $status]);
        return resultArray(['data' => ['status' => $status , 'desc' => '更新用户状态成功']]);
    }

    public function userRecharge(){
        $param = $this->param;
        $coin = $param['coin'];
        $code = $param['code'];
        $userid = $param['id'];

        if (empty($userid)) return resultArray(['error' => '参数错误']);
        if (empty($coin)) $coin = 0;
        if (empty($code)) $code = 0;

        $user = Db::name('user')->where('id', $userid)->find();
        if (empty($user)) return resultArray(['error' => '当前用户不存在']);
        Db::name('user')->where('id', $userid)->update(['paicoin' => $user['paicoin'] + $coin, 'activationcode' => $user['activationcode'] + $code]);

        return resultArray(['data' => '充值成功']);
    }

    public function verifyUserCard() {
        $param = $this->param;
        $id = $param['id'];
        $type = $param['type'];
        $remark = $param['remark'];

        if (empty($id) || empty($type)) {
            return resultArray(['error' => '缺少参数']);
        }

        if ($type == 'success')
            $remark = '';

        Db::name('user_certificate')->where('id', $id)->update(['status' => $type, 'remark' => $remark, 'update_time' => time()]);
        return resultArray(['data' => ['status' => $type , 'remark' => $remark , 'desc' => '更新用户状态成功']]);
    }

    public function save()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->createData($param);
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '添加成功']);
    }

    public function update()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->updateDataById($param, $param['id']);
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '编辑成功']);
    }

    public function delete()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->delDataById($param['id']);       
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '删除成功']);    
    }

    public function deletes()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->delDatas($param['ids']);  
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '删除成功']); 
    }

    public function enables()
    {
        $userModel = model('User');
        $param = $this->param;
        $data = $userModel->enableDatas($param['ids'], $param['status']);  
        if (!$data) {
            return resultArray(['error' => $userModel->getError()]);
        } 
        return resultArray(['data' => '操作成功']);         
    }
    
}
 