<?php
// +----------------------------------------------------------------------
// | Description: 规则
// +----------------------------------------------------------------------
// | Author: linchuangbin <linchuangbin@honraytech.com>
// +----------------------------------------------------------------------

namespace app\admin\model;

use app\admin\model\Common;
use think\Db;

class AuthRule extends Common
{
    /**获取所有菜单和按钮权限列表
     * @param string $user_id 管理员用户编号
     * @param string $type 'tree' 树形展表述
     * @return array
     */
	public function getUserAuthRules($user_id, $type = '')
	{
	    $roles = Db::name('admin_role') -> where('uid', $user_id)->find();
        if (empty($roles)){
            $this -> error = "当前用户没有分配角色";
            return false;
        }
        $role_auth = Db::name('role_auth') -> where('id', $roles['role_id'])->find();
        if (empty($role_auth) || empty($role_auth['rules'])) {
            $this -> error = "用户当前角色没有分配权限";
            return false;
        }
        $rule_string = $role_auth['rules'];
        if ($rule_string == '*')
            $condition = '';
        else
            $condition['id'] = ['in', $rule_string];

		$cat = new \com\Category('auth_rule', array('id', 'pid', 'name', 'title', 'ismenu', 'weigh', 'icon'));
		$data = $cat->getList($condition, 0, 'weigh asc');
		// 若type为tree，则返回树状结构
		if ($type == 'tree') {
			foreach ($data as $k => $v) {
				$data[$k]['check'] = false;
			}
			$tree = new \com\Tree();
			$data = $tree->list_to_tree($data, 'id', 'pid', 'child', 0, true, array('pid'));
		}
		
		return $data;
	}

}